/**
 * Referral tracking utilities
 */

const REFERRAL_CODE_KEY = 'snova_referral_code';
const REFERRAL_EXPIRY_KEY = 'snova_referral_expiry';
const REFERRAL_EXPIRY_DAYS = 30;

/**
 * Capture referral code from URL
 */
export const captureReferralCode = (): string | null => {
  const params = new URLSearchParams(window.location.search);
  const refCode = params.get('ref');

  if (refCode) {
    // Store in localStorage with expiry
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + REFERRAL_EXPIRY_DAYS);
    
    localStorage.setItem(REFERRAL_CODE_KEY, refCode);
    localStorage.setItem(REFERRAL_EXPIRY_KEY, expiryDate.toISOString());
    
    // Clean URL (remove ref parameter)
    const newUrl = new URL(window.location.href);
    newUrl.searchParams.delete('ref');
    window.history.replaceState({}, document.title, newUrl.toString());
    
    return refCode;
  }

  return null;
};

/**
 * Get stored referral code
 */
export const getReferralCode = (): string | null => {
  const code = localStorage.getItem(REFERRAL_CODE_KEY);
  const expiry = localStorage.getItem(REFERRAL_EXPIRY_KEY);

  if (!code || !expiry) {
    return null;
  }

  // Check if expired
  const expiryDate = new Date(expiry);
  if (new Date() > expiryDate) {
    clearReferralCode();
    return null;
  }

  return code;
};

/**
 * Clear referral code from storage
 */
export const clearReferralCode = (): void => {
  localStorage.removeItem(REFERRAL_CODE_KEY);
  localStorage.removeItem(REFERRAL_EXPIRY_KEY);
};

/**
 * Check if referral code is valid by calling backend
 */
export const validateReferralCode = async (code: string): Promise<boolean> => {
  try {
    const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';
    const response = await fetch(`${API_URL}/api/registrations/verify-referral/${code}`);
    const data = await response.json();
    return data.success && data.valid;
  } catch (error) {
    console.error('Failed to validate referral code:', error);
    return false;
  }
};
