import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import LandingPage from './landingpage/LandingPage';
import AdminDashboardLayout from './admin/pages/AdminDashboardLayout';
import ModuleDetails from './pages/ModuleDetails';
import UserDashboard from './pages/StudentDashboard';
import InfluencerDashboard from './pages/InfluencerDashboard';
import NotFound from './pages/NotFound';
import { useEffect, useState } from 'react';
import { auth } from './firebase';
import { onAuthStateChanged, type User } from 'firebase/auth';
import { captureReferralCode } from './utils/referralTracking';

// UserProtectedRoute
const UserProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user: User | null) => {
      setIsAuthenticated(!!user);
    });
    return () => unsubscribe();
  }, []);

  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[var(--color-primary-bg)]">
        <div className="w-12 h-12 border-4 border-brand-blue border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    // Navigate back to home if not logged in (they should use the modal)
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};

// AdminProtectedRoute
const AdminProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const [authState, setAuthState] = useState<'loading' | 'admin' | 'notAdmin' | 'notAuthenticated'>('loading');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user: User | null) => {
      if (user) {
        try {
          // Get user profile from Firestore to check role
          const token = await user.getIdToken();
          const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
          const response = await fetch(`${apiUrl}/api/auth/profile`, {
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });

          if (response.ok) {
            const data = await response.json();
            if (data.data?.role === 'admin') {
              setAuthState('admin');
            } else {
              setAuthState('notAdmin');
            }
          } else {
            setAuthState('notAdmin');
          }
        } catch (error) {
          console.error("Error fetching user profile", error);
          setAuthState('notAdmin');
        }
      } else {
        // User is not authenticated at all
        setAuthState('notAuthenticated');
      }
    });

    return () => unsubscribe();
  }, []);

  if (authState === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[var(--color-primary-bg)]">
        <div className="w-12 h-12 border-4 border-brand-blue border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  // If user is not authenticated, redirect to home (landing page)
  if (authState === 'notAuthenticated') {
    return <Navigate to="/" replace />;
  }

  // If user is authenticated but not admin, show 404
  if (authState === 'notAdmin') {
    return <Navigate to="/404" replace />;
  }

  return <>{children}</>;
};

function App() {
  // Capture referral code on app load
  useEffect(() => {
    captureReferralCode();
  }, []);

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />

        {/* Protected Module Details */}
        <Route
          path="/curriculum/:moduleId"
          element={
            <UserProtectedRoute>
              <ModuleDetails />
            </UserProtectedRoute>
          }
        />

        {/* User Dashboard */}
        <Route
          path="/dashboard"
          element={
            <UserProtectedRoute>
              <UserDashboard />
            </UserProtectedRoute>
          }
        />

        {/* Influencer Dashboard */}
        <Route
          path="/influencer-dashboard"
          element={
            <UserProtectedRoute>
              <InfluencerDashboard />
            </UserProtectedRoute>
          }
        />

        {/* Hidden Admin Route */}
        <Route
          path="/management-dashboard-x92f-snova"
          element={
            <AdminProtectedRoute>
              <AdminDashboardLayout />
            </AdminProtectedRoute>
          }
        />

        {/* Catch all 404 */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

