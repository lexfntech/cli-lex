import { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  FiBook,
  FiClock,
  FiLayers,
  FiTag,
  FiEdit3,
  FiTrash2,
  FiPlus,
  FiPlayCircle,
  FiCheckCircle,
  FiSettings,
  FiCode,
  FiX,
  FiArrowUp,
  FiArrowDown,
  FiAlertCircle,
  FiAward
} from "react-icons/fi";
import type { AppDispatch, RootState } from "../../store";
import {
  fetchCourses,
  createCourse,
  updateCourse,
  deleteCourse,
  type Course,
  type Module
} from "../../store/courseSlice";

const CourseManagementPage = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { courses } = useSelector((state: RootState) => state.course);

  const [selectedCourseId, setSelectedCourseId] = useState("");
  const [selectedModuleId, setSelectedModuleId] = useState("");

  // Modals & Action States
  const [showAddCourseModal, setShowAddCourseModal] = useState(false);
  const [showEditCourseModal, setShowEditCourseModal] = useState(false);
  const [showAddModuleModal, setShowAddModuleModal] = useState(false);
  const [showEditModuleModal, setShowEditModuleModal] = useState(false);
  const [showAddLessonModal, setShowAddLessonModal] = useState(false);

  // Form States - Course
  const [courseForm, setCourseForm] = useState({
    title: "",
    description: "",
    price: "",
    duration: "",
    level: "Beginner",
    features: [] as string[],
    newFeature: "",
    tags: [] as string[],
    newTag: ""
  });

  // Form States - Module
  const [moduleForm, setModuleForm] = useState({
    title: "",
    outcome: "",
    tools: [] as string[],
    newTool: "",
    practical: [] as string[],
    newPractical: ""
  });

  // Form States - Lesson
  const [newLessonTitle, setNewLessonTitle] = useState("");
  const [newModuleTitle, setNewModuleTitle] = useState("");

  // Sync Indicator
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<"idle" | "success" | "error">("idle");

  useEffect(() => {
    dispatch(fetchCourses());
  }, [dispatch]);

  // Set default selected course ID
  useEffect(() => {
    if (courses.length > 0 && !selectedCourseId) {
      setSelectedCourseId(courses[0].id);
    }
  }, [courses, selectedCourseId]);

  // Active course reference
  const activeCourse = useMemo(() => {
    return courses.find(c => c.id === selectedCourseId) || courses[0] || null;
  }, [courses, selectedCourseId]);

  // Set default selected module ID
  useEffect(() => {
    if (activeCourse && activeCourse.modules.length > 0 && !selectedModuleId) {
      setSelectedModuleId(activeCourse.modules[0].id);
    }
  }, [activeCourse, selectedModuleId]);

  // Selected module reference
  const selectedModule = useMemo(() => {
    if (!activeCourse) return null;
    return activeCourse.modules.find(m => m.id === selectedModuleId) || activeCourse.modules[0] || null;
  }, [activeCourse, selectedModuleId]);

  // Populate course edit form when opening modal
  const openEditCourse = () => {
    if (!activeCourse) return;
    setCourseForm({
      title: activeCourse.title,
      description: activeCourse.description || "",
      price: activeCourse.price.toString(),
      duration: activeCourse.duration.toString(),
      level: activeCourse.level || "Beginner",
      features: [...(activeCourse.features || [])],
      newFeature: "",
      tags: [...(activeCourse.tags || [])],
      newTag: ""
    });
    setShowEditCourseModal(true);
  };

  // Populate module edit form when opening modal
  const openEditModule = () => {
    if (!selectedModule) return;
    setModuleForm({
      title: selectedModule.title,
      outcome: selectedModule.outcome || "",
      tools: [...(selectedModule.tools || [])],
      newTool: "",
      practical: [...(selectedModule.practical || [])],
      newPractical: ""
    });
    setShowEditModuleModal(true);
  };

  // Trigger Firestore Sync
  const syncCourseToDatabase = async (updatedCourse: Course) => {
    setIsSyncing(true);
    setSyncStatus("idle");
    try {
      await dispatch(updateCourse({ id: updatedCourse.id, courseData: updatedCourse })).unwrap();
      setSyncStatus("success");
    } catch (err) {
      console.error("Firestore sync failed:", err);
      setSyncStatus("error");
    } finally {
      setTimeout(() => setIsSyncing(false), 800);
    }
  };

  // Create Course Action
  const handleCreateCourse = async () => {
    if (!courseForm.title.trim()) return;
    try {
      const courseId = `course_${Date.now()}`;
      const newCourse: Partial<Course> = {
        id: courseId,
        title: courseForm.title.trim(),
        description: courseForm.description.trim(),
        price: Number(courseForm.price) || 0,
        duration: courseForm.duration.trim() || "10",
        level: courseForm.level,
        features: courseForm.features,
        tags: courseForm.tags,
        modules: [],
        isActive: true
      };
      const created = await dispatch(createCourse(newCourse)).unwrap();
      setSelectedCourseId(created.id);
      setShowAddCourseModal(false);
      // Reset form
      setCourseForm({
        title: "",
        description: "",
        price: "",
        duration: "",
        level: "Beginner",
        features: [],
        newFeature: "",
        tags: [],
        newTag: ""
      });
    } catch (err: any) {
      const errorMsg = typeof err === 'string' ? err : (err?.message || JSON.stringify(err));
      alert("Failed to create course: " + errorMsg);
    }
  };

  // Edit Course Details Action
  const handleUpdateCourseDetails = async () => {
    if (!activeCourse) return;
    const updated: Course = {
      ...activeCourse,
      title: courseForm.title.trim(),
      description: courseForm.description.trim(),
      price: Number(courseForm.price) || 0,
      duration: courseForm.duration.trim(),
      level: courseForm.level,
      features: courseForm.features,
      tags: courseForm.tags
    };
    await syncCourseToDatabase(updated);
    setShowEditCourseModal(false);
  };

  // Delete active course
  const handleDeleteActiveCourse = async () => {
    if (!activeCourse) return;
    if (!confirm(`Are you absolutely sure you want to delete course "${activeCourse.title}"? This cannot be undone.`)) return;

    try {
      await dispatch(deleteCourse(activeCourse.id)).unwrap();
      setSelectedCourseId("");
      setSelectedModuleId("");
    } catch (err: any) {
      const errorMsg = typeof err === 'string' ? err : (err?.message || JSON.stringify(err));
      alert("Failed to delete course: " + errorMsg);
    }
  };

  // Add Module Action
  const handleAddModule = async () => {
    if (!activeCourse || !newModuleTitle.trim()) return;
    
    const nextIndex = activeCourse.modules.length + 1;
    const newModuleObj: Module = {
      id: `mod_${Date.now()}`,
      title: `MODULE ${nextIndex} — ${newModuleTitle.trim()}`,
      lessons: [],
      outcome: "Master the concepts of this module."
    };

    const updated: Course = {
      ...activeCourse,
      modules: [...activeCourse.modules, newModuleObj]
    };

    await syncCourseToDatabase(updated);
    setSelectedModuleId(newModuleObj.id);
    setNewModuleTitle("");
    setShowAddModuleModal(false);
  };

  // Edit Module Action
  const handleUpdateModule = async () => {
    if (!activeCourse || !selectedModule) return;

    const updatedModules = activeCourse.modules.map(m => {
      if (m.id === selectedModule.id) {
        return {
          ...m,
          title: moduleForm.title.trim(),
          outcome: moduleForm.outcome.trim(),
          tools: moduleForm.tools,
          practical: moduleForm.practical
        };
      }
      return m;
    });

    const updated: Course = {
      ...activeCourse,
      modules: updatedModules
    };

    await syncCourseToDatabase(updated);
    setShowEditModuleModal(false);
  };

  // Delete Selected Module
  const handleDeleteModule = async (moduleId: string) => {
    if (!activeCourse) return;
    if (!confirm("Are you sure you want to delete this module and all its lessons?")) return;

    const updatedModules = activeCourse.modules.filter(m => m.id !== moduleId);
    
    // Recalculate prefix sequence (e.g. MODULE 1, MODULE 2)
    const sequentialModules = updatedModules.map((m, idx) => {
      const parts = m.title.split(/——?|—/);
      const nameOnly = parts.length > 1 ? parts.slice(1).join("—").trim() : m.title;
      return {
        ...m,
        title: `MODULE ${idx + 1} — ${nameOnly}`
      };
    });

    const updated: Course = {
      ...activeCourse,
      modules: sequentialModules
    };

    await syncCourseToDatabase(updated);
    if (selectedModuleId === moduleId) {
      setSelectedModuleId(sequentialModules.length > 0 ? sequentialModules[0].id : "");
    }
  };

  // Shift Module Order (Reordering)
  const moveModule = async (index: number, direction: 'up' | 'down') => {
    if (!activeCourse) return;
    const list = [...activeCourse.modules];
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= list.length) return;

    // Swap
    const temp = list[index];
    list[index] = list[targetIdx];
    list[targetIdx] = temp;

    // Recalculate title indexes
    const sequentialModules = list.map((m, idx) => {
      const parts = m.title.split(/——?|—/);
      const nameOnly = parts.length > 1 ? parts.slice(1).join("—").trim() : m.title;
      return {
        ...m,
        title: `MODULE ${idx + 1} — ${nameOnly}`
      };
    });

    const updated: Course = {
      ...activeCourse,
      modules: sequentialModules
    };

    await syncCourseToDatabase(updated);
  };

  // Add Lesson Action
  const handleAddLesson = async () => {
    if (!activeCourse || !selectedModuleId || !newLessonTitle.trim()) return;

    const updatedModules = activeCourse.modules.map(m => {
      if (m.id === selectedModuleId) {
        return {
          ...m,
          lessons: [...(m.lessons || []), newLessonTitle.trim()]
        };
      }
      return m;
    });

    const updated: Course = {
      ...activeCourse,
      modules: updatedModules
    };

    await syncCourseToDatabase(updated);
    setNewLessonTitle("");
    setShowAddLessonModal(false);
  };

  // Delete Lesson Action
  const handleDeleteLesson = async (lessonIndex: number) => {
    if (!activeCourse || !selectedModuleId) return;

    const updatedModules = activeCourse.modules.map(m => {
      if (m.id === selectedModuleId) {
        const lessons = [...(m.lessons || [])];
        lessons.splice(lessonIndex, 1);
        return { ...m, lessons };
      }
      return m;
    });

    const updated: Course = {
      ...activeCourse,
      modules: updatedModules
    };

    await syncCourseToDatabase(updated);
  };

  // Move Lesson Order
  const moveLesson = async (lessonIndex: number, direction: 'up' | 'down') => {
    if (!activeCourse || !selectedModule) return;
    const targetIndex = direction === 'up' ? lessonIndex - 1 : lessonIndex + 1;
    if (targetIndex < 0 || targetIndex >= selectedModule.lessons.length) return;

    const updatedModules = activeCourse.modules.map(m => {
      if (m.id === selectedModule.id) {
        const lessons = [...m.lessons];
        const temp = lessons[lessonIndex];
        lessons[lessonIndex] = lessons[targetIndex];
        lessons[targetIndex] = temp;
        return { ...m, lessons };
      }
      return m;
    });

    const updated: Course = {
      ...activeCourse,
      modules: updatedModules
    };

    await syncCourseToDatabase(updated);
  };

  // Outcome statistics
  const totalLessons = useMemo(() => {
    if (!activeCourse) return 0;
    return activeCourse.modules.reduce((sum, m) => sum + (m.lessons?.length || 0), 0);
  }, [activeCourse]);

  const totalPracticals = useMemo(() => {
    if (!activeCourse) return 0;
    return activeCourse.modules.reduce((sum, m) => sum + (m.practical?.length || 0), 0);
  }, [activeCourse]);

  return (
    <div className="space-y-8 text-slate-200 animate-fade-in">
      
      {/* Dynamic Selector Header */}
      <div className="rounded-2xl border border-white/5 bg-[#090909] p-6 shadow-xl relative">
        <div className="absolute top-4 right-4 flex items-center gap-2">
          {isSyncing && (
            <span className="flex items-center gap-1.5 text-[9px] font-mono font-bold text-[var(--color-icy-cyan)] uppercase animate-pulse">
              <span className="h-1.5 w-1.5 rounded-full bg-[var(--color-icy-cyan)] animate-ping" />
              Syncing to Cloud...
            </span>
          )}
          {!isSyncing && syncStatus === "success" && (
            <span className="text-[9px] font-mono font-bold text-emerald-400 uppercase flex items-center gap-1">
              <FiCheckCircle /> Synced
            </span>
          )}
          {!isSyncing && syncStatus === "error" && (
            <span className="text-[9px] font-mono font-bold text-rose-400 uppercase flex items-center gap-1">
              <FiAlertCircle /> Sync Fail
            </span>
          )}
        </div>

        <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 rounded-full bg-white/3 border border-white/5 px-2.5 py-0.5 text-[9px] font-bold font-mono tracking-widest text-[var(--color-icy-cyan)] uppercase">
              <FiBook /> Syllabus Workspace
            </div>
            <h1 className="text-lg font-black text-white uppercase tracking-tight">
              Curriculum & Catalog Builder
            </h1>
            <p className="text-[11px] text-slate-400 font-medium">
              Configure course metadata, manage modules outline, and deploy lessons directly to the platform database.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {courses.length > 0 && (
              <select
                value={selectedCourseId}
                onChange={(e) => {
                  setSelectedCourseId(e.target.value);
                  setSelectedModuleId("");
                }}
                className="bg-[#121212] border border-white/5 rounded-xl px-3 py-2 text-xs font-bold text-white outline-none cursor-pointer focus:border-white/10"
              >
                {courses.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.title.substring(0, 32)}...
                  </option>
                ))}
              </select>
            )}

            <button
              onClick={() => setShowAddCourseModal(true)}
              className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[var(--color-brand-blue-alt)] to-[var(--color-brand-blue)] px-4 py-2.5 text-xs font-bold text-white uppercase tracking-wider transition-all shadow-md shadow-blue-500/10 cursor-pointer"
            >
              <FiPlus /> New Course
            </button>

            {activeCourse && (
              <>
                <button
                  onClick={openEditCourse}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-white/2 border border-white/5 px-3 py-2.5 text-xs font-bold text-slate-300 hover:bg-white/5 cursor-pointer"
                >
                  <FiEdit3 /> Course Settings
                </button>
                <button
                  onClick={handleDeleteActiveCourse}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-red-500/10 border border-red-500/20 px-3 py-2.5 text-xs font-bold text-red-400 hover:bg-red-500/20 cursor-pointer"
                >
                  <FiTrash2 /> Delete
                </button>
              </>
            )}
          </div>
        </div>

        {/* 5 Course KPI Cards */}
        {activeCourse && (
          <div className="grid gap-4 grid-cols-1 sm:grid-cols-3 xl:grid-cols-5 border-t border-white/5 mt-6 pt-6">
            <StatCard
              label="Selected ID"
              value={activeCourse.id}
              icon={<FiBook className="text-slate-300" />}
            />
            <StatCard
              label="Pricing Details"
              value={Number(activeCourse.price) > 0 ? `₹${activeCourse.price}` : "Free"}
              icon={<FiTag className="text-slate-300" />}
            />
            <StatCard
              label="Course Duration"
              value={`${activeCourse.duration} Hours`}
              icon={<FiClock className="text-slate-300" />}
            />
            <StatCard
              label="Module Catalog"
              value={`${activeCourse.modules.length} Modules`}
              subtitle={`${totalLessons} Lectures`}
              icon={<FiLayers className="text-slate-300" />}
            />
            <StatCard
              label="Lab Practicals"
              value={`${totalPracticals} Experiments`}
              subtitle="Applied Hacking"
              icon={<FiCode className="text-slate-300" />}
            />
          </div>
        )}
      </div>

      {activeCourse ? (
        <div className="grid gap-6 xl:grid-cols-[1fr_1.1fr]">
          
          {/* Left Side: Modules Index Outline */}
          <div className="rounded-2xl border border-white/5 bg-[#090909] p-6 shadow-xl flex flex-col justify-between">
            <div>
              <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h2 className="text-xs font-bold uppercase tracking-[0.25em] text-slate-500 font-mono">Modules Index</h2>
                  <p className="text-[10px] text-slate-400 mt-0.5">Reorder outline sequence or edit modules.</p>
                </div>
                <button
                  onClick={() => setShowAddModuleModal(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/2 border border-white/5 text-[9px] font-bold uppercase tracking-wider text-slate-300 hover:bg-white/5 transition-colors cursor-pointer"
                >
                  <FiPlus /> New Module
                </button>
              </div>

              {/* Module cards container */}
              <div className="space-y-3.5 max-h-[620px] overflow-y-auto pr-1">
                {activeCourse.modules.map((module, idx) => {
                  const isSelected = selectedModuleId === module.id;
                  const itemsCount = (module.lessons?.length || 0) + (module.practical?.length || 0);
                  
                  return (
                    <div
                      key={module.id}
                      onClick={() => setSelectedModuleId(module.id)}
                      className={`w-full rounded-xl border p-4 text-left transition-all flex items-center justify-between gap-3 cursor-pointer group relative ${
                        isSelected 
                          ? "border-white/10 bg-white/4 shadow-lg border-l-2 border-l-[var(--color-brand-blue)]" 
                          : "border-white/5 bg-[#0c0c0c] hover:border-white/10 hover:bg-white/2"
                      }`}
                    >
                      <div className="flex items-center gap-3.5 flex-1 min-w-0">
                        {/* Reordering Controls */}
                        <div className="flex flex-col gap-1 flex-shrink-0 opacity-40 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={(e) => { e.stopPropagation(); moveModule(idx, 'up'); }}
                            disabled={idx === 0}
                            className="p-0.5 hover:bg-white/5 rounded text-slate-400 hover:text-white disabled:opacity-20"
                          >
                            <FiArrowUp className="text-[10px]" />
                          </button>
                          <button
                            onClick={(e) => { e.stopPropagation(); moveModule(idx, 'down'); }}
                            disabled={idx === activeCourse.modules.length - 1}
                            className="p-0.5 hover:bg-white/5 rounded text-slate-400 hover:text-white disabled:opacity-20"
                          >
                            <FiArrowDown className="text-[10px]" />
                          </button>
                        </div>

                        {/* Module number circle */}
                        <div className={`w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center text-[10px] font-black font-mono border ${
                          isSelected ? "bg-white text-black border-white" : "bg-white/2 text-slate-400 border-white/5"
                        }`}>
                          {idx + 1}
                        </div>

                        <div className="min-w-0">
                          <div className="text-[8px] font-mono text-slate-500 font-bold uppercase tracking-wider">{module.id}</div>
                          <h3 className="text-xs font-bold text-slate-200 truncate mt-0.5 group-hover:text-white">
                            {module.title.replace(/^MODULE \d+\s*——?\s*/i, "")}
                          </h3>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="rounded-full border border-white/5 bg-white/2 px-2.5 py-0.5 text-[8px] font-bold text-slate-400 tracking-wide">
                          {itemsCount} Items
                        </span>
                        <button
                          onClick={(e) => { e.stopPropagation(); handleDeleteModule(module.id); }}
                          className="p-1 hover:bg-rose-500/10 rounded text-rose-400 opacity-0 group-hover:opacity-100 transition-all cursor-pointer"
                        >
                          <FiTrash2 className="text-[10px]" />
                        </button>
                      </div>
                    </div>
                  );
                })}

                {activeCourse.modules.length === 0 && (
                  <div className="rounded-xl border border-dashed border-white/5 p-8 text-center text-xs text-slate-500">
                    No curriculum modules defined. Add a module to start.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Side: Selected Module Details Workspace */}
          <div className="rounded-2xl border border-white/5 bg-[#090909] p-6 shadow-xl flex flex-col justify-between">
            {selectedModule ? (
              <div className="space-y-6">
                
                {/* Module Details Header inside workspace */}
                <div className="flex items-start justify-between border-b border-white/5 pb-4">
                  <div>
                    <div className="text-[8px] font-bold uppercase tracking-widest text-slate-500 font-mono">
                      Module Workspace ({selectedModule.id})
                    </div>
                    <h2 className="mt-1 text-sm font-black text-white uppercase tracking-wide">
                      {selectedModule.title}
                    </h2>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => setShowAddLessonModal(true)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-gradient-to-r from-[var(--color-brand-blue-alt)] to-[var(--color-brand-blue)] text-white text-[9px] font-bold uppercase tracking-wider transition-colors hover:brightness-110 cursor-pointer"
                    >
                      <FiPlus /> Add Lecture
                    </button>
                    <button 
                      onClick={openEditModule}
                      className="p-2 border border-white/5 rounded-lg bg-white/2 hover:bg-white/5 text-slate-300 cursor-pointer"
                      title="Edit Outcomes & Details"
                    >
                      <FiSettings className="text-xs" />
                    </button>
                  </div>
                </div>

                {/* Learning Outcome */}
                {selectedModule.outcome && (
                  <div className="rounded-xl border border-indigo-500/15 bg-indigo-500/3 p-4 text-[11px] text-indigo-300 flex items-start gap-3">
                    <FiAward className="text-sm mt-0.5 text-indigo-400 flex-shrink-0" />
                    <div>
                      <strong className="block text-indigo-200 font-bold mb-0.5 uppercase tracking-wider text-[9px] font-mono">Target Learning Outcome</strong>
                      {selectedModule.outcome}
                    </div>
                  </div>
                )}

                {/* Granular content */}
                <div className="space-y-6">
                  
                  {/* Lectures List */}
                  <div>
                    <h3 className="text-[9px] font-bold uppercase tracking-widest text-slate-500 font-mono mb-2.5 pl-0.5">
                      Lectures & Videos ({selectedModule.lessons?.length || 0})
                    </h3>
                    
                    <div className="space-y-2.5 max-h-[300px] overflow-y-auto">
                      {selectedModule.lessons && selectedModule.lessons.map((lesson, idx) => (
                        <div
                          key={idx}
                          className="flex items-center justify-between p-3.5 rounded-xl border border-white/5 bg-white/2 hover:bg-white/4 transition-all text-xs text-slate-300 group"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            {/* Reordering indicators */}
                            <div className="flex flex-col gap-0.5 opacity-20 group-hover:opacity-100 transition-opacity">
                              <button
                                onClick={() => moveLesson(idx, 'up')}
                                disabled={idx === 0}
                                className="text-[10px] hover:text-white disabled:opacity-20"
                              >
                                ▲
                              </button>
                              <button
                                onClick={() => moveLesson(idx, 'down')}
                                disabled={idx === selectedModule.lessons.length - 1}
                                className="text-[10px] hover:text-white disabled:opacity-20"
                              >
                                ▼
                              </button>
                            </div>
                            <FiPlayCircle className="text-slate-500 flex-shrink-0 text-sm" />
                            
                            <span className="font-semibold text-slate-200 truncate">
                              {idx + 1}. {lesson}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[8px] font-bold border border-emerald-500/20 bg-emerald-500/5 text-emerald-400 font-mono uppercase">
                              Active
                            </span>
                            <button
                              onClick={() => handleDeleteLesson(idx)}
                              className="p-1 hover:bg-rose-500/10 rounded text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                              title="Delete Lecture"
                            >
                              <FiTrash2 className="text-[10px]" />
                            </button>
                          </div>
                        </div>
                      ))}

                      {(!selectedModule.lessons || selectedModule.lessons.length === 0) && (
                        <div className="text-center py-6 text-slate-500 text-[10px] border border-dashed border-white/5 rounded-xl">
                          No lectures listed. Add a lecture using the button above.
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Practical labs */}
                  {selectedModule.practical && selectedModule.practical.length > 0 && (
                    <div>
                      <h3 className="text-[9px] font-bold uppercase tracking-widest text-slate-500 font-mono mb-2 pl-0.5">
                        Lab Experiments
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {selectedModule.practical.map((item) => (
                          <span
                            key={item}
                            className="rounded-lg border border-teal-500/15 bg-teal-500/5 px-2.5 py-1.5 text-[10px] text-teal-300 font-bold font-mono tracking-wide"
                          >
                            🧪 {item}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Tools */}
                  {selectedModule.tools && selectedModule.tools.length > 0 && (
                    <div>
                      <h3 className="text-[9px] font-bold uppercase tracking-widest text-slate-500 font-mono mb-2 pl-0.5">
                        Required Stack Tools
                      </h3>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedModule.tools.map((item) => (
                          <span
                            key={item}
                            className="rounded-lg border border-white/5 bg-white/2 px-2.5 py-1 text-[10px] text-slate-300 font-bold font-mono"
                          >
                            🛠️ {item}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                </div>

              </div>
            ) : (
              <div className="flex min-h-[360px] items-center justify-center rounded-2xl border border-dashed border-white/5 text-xs text-slate-500 font-mono">
                Select or create a module to configure outline curriculum details.
              </div>
            )}
          </div>

        </div>
      ) : (
        <div className="rounded-2xl border border-dashed border-white/5 bg-[#090909] p-12 text-center shadow-xl">
          <FiBook className="text-4xl text-slate-600 mb-4 mx-auto" />
          <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-2">No Courses Defined</h3>
          <p className="text-xs text-slate-400 mb-5 max-w-sm mx-auto">
            You don't have any courses configured in your Firestore database catalog.
          </p>
          <button
            onClick={() => setShowAddCourseModal(true)}
            className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[var(--color-brand-blue-alt)] to-[var(--color-brand-blue)] px-4 py-2.5 text-xs font-bold text-white uppercase tracking-wider cursor-pointer"
          >
            <FiPlus /> Initialize First Course
          </button>
        </div>
      )}

      {/* Add Course Modal */}
      {showAddCourseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowAddCourseModal(false)}></div>
          <div className="relative w-full max-w-lg border border-white/5 bg-[#0a0a0a] rounded-2xl shadow-2xl p-6 overflow-y-auto max-h-[90vh]">
            <div className="flex items-center justify-between mb-6 border-b border-white/5 pb-4">
              <h3 className="text-xs font-black text-white uppercase tracking-widest font-mono">Create Learning Path</h3>
              <button onClick={() => setShowAddCourseModal(false)} className="p-1 hover:bg-white/5 rounded text-slate-400 cursor-pointer">
                <FiX />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Course Title</label>
                <input
                  type="text"
                  value={courseForm.title}
                  onChange={(e) => setCourseForm({ ...courseForm, title: e.target.value })}
                  placeholder="e.g. Cybersecurity & Bug Bounty Mastery"
                  className="w-full rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                />
              </div>

              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Description</label>
                <textarea
                  value={courseForm.description}
                  onChange={(e) => setCourseForm({ ...courseForm, description: e.target.value })}
                  placeholder="Summarize course goals..."
                  rows={3}
                  className="w-full rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10 resize-none"
                />
              </div>

              <div className="grid gap-4 grid-cols-3">
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Price (INR)</label>
                  <input
                    type="number"
                    value={courseForm.price}
                    onChange={(e) => setCourseForm({ ...courseForm, price: e.target.value })}
                    placeholder="1599"
                    className="w-full rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                  />
                </div>
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Duration (Hours)</label>
                  <input
                    type="text"
                    value={courseForm.duration}
                    onChange={(e) => setCourseForm({ ...courseForm, duration: e.target.value })}
                    placeholder="25"
                    className="w-full rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                  />
                </div>
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Level</label>
                  <select
                    value={courseForm.level}
                    onChange={(e) => setCourseForm({ ...courseForm, level: e.target.value })}
                    className="w-full rounded-xl border border-white/5 bg-[#121212] px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>
                </div>
              </div>

              {/* Tags Section */}
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Catalog Tags</label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={courseForm.newTag}
                    onChange={(e) => setCourseForm({ ...courseForm, newTag: e.target.value })}
                    placeholder="e.g. Pentesting"
                    className="flex-1 rounded-xl border border-white/5 bg-white/2 px-3.5 py-2 text-xs outline-none text-white focus:border-white/10"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!courseForm.newTag.trim()) return;
                      setCourseForm({
                        ...courseForm,
                        tags: [...courseForm.tags, courseForm.newTag.trim()],
                        newTag: ""
                      });
                    }}
                    className="px-3.5 py-2 rounded-xl bg-white/5 text-xs font-bold text-slate-200 border border-white/5 hover:bg-white/10"
                  >
                    Add
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {courseForm.tags.map(t => (
                    <span key={t} className="inline-flex items-center gap-1 rounded-lg bg-white/3 border border-white/5 px-2.5 py-1 text-[10px] font-mono">
                      {t}
                      <button
                        type="button"
                        onClick={() => setCourseForm({ ...courseForm, tags: courseForm.tags.filter(tag => tag !== t) })}
                        className="text-rose-400 hover:text-white"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-white/5">
                <button
                  type="button"
                  onClick={() => setShowAddCourseModal(false)}
                  className="flex-1 px-4 py-2.5 bg-white/2 hover:bg-white/5 border border-white/5 text-slate-300 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCreateCourse}
                  disabled={!courseForm.title.trim()}
                  className="flex-1 px-4 py-2.5 bg-gradient-to-r from-[var(--color-brand-blue-alt)] to-[var(--color-brand-blue)] text-white rounded-xl text-xs font-bold uppercase tracking-wider disabled:opacity-30 cursor-pointer"
                >
                  Initialize Path
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Course Settings Modal */}
      {showEditCourseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowEditCourseModal(false)}></div>
          <div className="relative w-full max-w-lg border border-white/5 bg-[#0a0a0a] rounded-2xl shadow-2xl p-6 overflow-y-auto max-h-[90vh]">
            <div className="flex items-center justify-between mb-6 border-b border-white/5 pb-4">
              <h3 className="text-xs font-black text-white uppercase tracking-widest font-mono">Edit Course Settings</h3>
              <button onClick={() => setShowEditCourseModal(false)} className="p-1 hover:bg-white/5 rounded text-slate-400 cursor-pointer">
                <FiX />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Course Title</label>
                <input
                  type="text"
                  value={courseForm.title}
                  onChange={(e) => setCourseForm({ ...courseForm, title: e.target.value })}
                  className="w-full rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                />
              </div>

              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Description</label>
                <textarea
                  value={courseForm.description}
                  onChange={(e) => setCourseForm({ ...courseForm, description: e.target.value })}
                  rows={3}
                  className="w-full rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10 resize-none"
                />
              </div>

              <div className="grid gap-4 grid-cols-3">
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Price (INR)</label>
                  <input
                    type="number"
                    value={courseForm.price}
                    onChange={(e) => setCourseForm({ ...courseForm, price: e.target.value })}
                    className="w-full rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                  />
                </div>
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Duration (Hours)</label>
                  <input
                    type="text"
                    value={courseForm.duration}
                    onChange={(e) => setCourseForm({ ...courseForm, duration: e.target.value })}
                    className="w-full rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                  />
                </div>
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Level</label>
                  <select
                    value={courseForm.level}
                    onChange={(e) => setCourseForm({ ...courseForm, level: e.target.value })}
                    className="w-full rounded-xl border border-white/5 bg-[#121212] px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>
                </div>
              </div>

              {/* Tags Section */}
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Catalog Tags</label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={courseForm.newTag}
                    onChange={(e) => setCourseForm({ ...courseForm, newTag: e.target.value })}
                    placeholder="Add tag"
                    className="flex-1 rounded-xl border border-white/5 bg-white/2 px-3.5 py-2 text-xs outline-none text-white focus:border-white/10"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!courseForm.newTag.trim()) return;
                      setCourseForm({
                        ...courseForm,
                        tags: [...courseForm.tags, courseForm.newTag.trim()],
                        newTag: ""
                      });
                    }}
                    className="px-3.5 py-2 rounded-xl bg-white/5 text-xs font-bold text-slate-200 border border-white/5 hover:bg-white/10"
                  >
                    Add
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {courseForm.tags.map(t => (
                    <span key={t} className="inline-flex items-center gap-1 rounded-lg bg-white/3 border border-white/5 px-2.5 py-1 text-[10px] font-mono">
                      {t}
                      <button
                        type="button"
                        onClick={() => setCourseForm({ ...courseForm, tags: courseForm.tags.filter(tag => tag !== t) })}
                        className="text-rose-400 hover:text-white"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              {/* Features list */}
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Features Outline</label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={courseForm.newFeature}
                    onChange={(e) => setCourseForm({ ...courseForm, newFeature: e.target.value })}
                    placeholder="e.g. Mostly practical labs"
                    className="flex-1 rounded-xl border border-white/5 bg-white/2 px-3.5 py-2 text-xs outline-none text-white focus:border-white/10"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!courseForm.newFeature.trim()) return;
                      setCourseForm({
                        ...courseForm,
                        features: [...courseForm.features, courseForm.newFeature.trim()],
                        newFeature: ""
                      });
                    }}
                    className="px-3.5 py-2 rounded-xl bg-white/5 text-xs font-bold text-slate-200 border border-white/5 hover:bg-white/10"
                  >
                    Add
                  </button>
                </div>
                <div className="space-y-1.5">
                  {courseForm.features.map(f => (
                    <div key={f} className="flex items-center justify-between bg-white/3 border border-white/5 rounded-lg p-2.5 text-[10px] font-mono text-slate-300">
                      <span>✓ {f}</span>
                      <button
                        type="button"
                        onClick={() => setCourseForm({ ...courseForm, features: courseForm.features.filter(feature => feature !== f) })}
                        className="text-rose-400 hover:text-white"
                      >
                        Delete
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-white/5">
                <button
                  type="button"
                  onClick={() => setShowEditCourseModal(false)}
                  className="flex-1 px-4 py-2.5 bg-white/2 hover:bg-white/5 border border-white/5 text-slate-300 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleUpdateCourseDetails}
                  disabled={!courseForm.title.trim()}
                  className="flex-1 px-4 py-2.5 bg-gradient-to-r from-[var(--color-brand-blue-alt)] to-[var(--color-brand-blue)] text-white rounded-xl text-xs font-bold uppercase tracking-wider disabled:opacity-30 cursor-pointer"
                >
                  Save Settings
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Module Modal */}
      {showAddModuleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowAddModuleModal(false)}></div>
          <div className="relative w-full max-w-md border border-white/5 bg-[#0a0a0a] rounded-2xl shadow-2xl p-6">
            <div className="flex items-center justify-between mb-4 border-b border-white/5 pb-3">
              <h3 className="text-xs font-black text-white uppercase tracking-widest font-mono">Create Module Segment</h3>
              <button onClick={() => setShowAddModuleModal(false)} className="p-1 hover:bg-white/5 rounded text-slate-400 cursor-pointer">
                <FiX />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Module Name</label>
                <input
                  type="text"
                  value={newModuleTitle}
                  onChange={(e) => setNewModuleTitle(e.target.value)}
                  placeholder="e.g. Linux & Hacker Environment Setup"
                  className="w-full rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModuleModal(false)}
                  className="flex-1 px-4 py-2.5 bg-white/2 hover:bg-white/5 border border-white/5 text-slate-350 rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddModule}
                  disabled={!newModuleTitle.trim()}
                  className="flex-1 px-4 py-2.5 bg-gradient-to-r from-[var(--color-brand-blue-alt)] to-[var(--color-brand-blue)] text-white rounded-xl text-xs font-bold uppercase tracking-wider disabled:opacity-30 cursor-pointer"
                >
                  Create Segment
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Module Outlines Modal */}
      {showEditModuleModal && selectedModule && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowEditModuleModal(false)}></div>
          <div className="relative w-full max-w-lg border border-white/5 bg-[#0a0a0a] rounded-2xl shadow-2xl p-6 overflow-y-auto max-h-[90vh]">
            <div className="flex items-center justify-between mb-5 border-b border-white/5 pb-3">
              <h3 className="text-xs font-black text-white uppercase tracking-widest font-mono">Configure Module details</h3>
              <button onClick={() => setShowEditModuleModal(false)} className="p-1 hover:bg-white/5 rounded text-slate-400 cursor-pointer">
                <FiX />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Module Name</label>
                <input
                  type="text"
                  value={moduleForm.title}
                  onChange={(e) => setModuleForm({ ...moduleForm, title: e.target.value })}
                  className="w-full rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                />
              </div>

              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Target Learning Outcome</label>
                <textarea
                  value={moduleForm.outcome}
                  onChange={(e) => setModuleForm({ ...moduleForm, outcome: e.target.value })}
                  rows={2}
                  placeholder="Student learns..."
                  className="w-full rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10 resize-none"
                />
              </div>

              {/* Tools Tags */}
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Required Tools Stack</label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={moduleForm.newTool}
                    onChange={(e) => setModuleForm({ ...moduleForm, newTool: e.target.value })}
                    placeholder="e.g. Burp Suite"
                    className="flex-1 rounded-xl border border-white/5 bg-white/2 px-3.5 py-2 text-xs outline-none text-white focus:border-white/10"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!moduleForm.newTool.trim()) return;
                      setModuleForm({
                        ...moduleForm,
                        tools: [...moduleForm.tools, moduleForm.newTool.trim()],
                        newTool: ""
                      });
                    }}
                    className="px-3.5 py-2 rounded-xl bg-white/5 text-xs font-bold text-slate-200 border border-white/5 hover:bg-white/10"
                  >
                    Add
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {moduleForm.tools.map(t => (
                    <span key={t} className="inline-flex items-center gap-1 rounded-lg bg-white/3 border border-white/5 px-2.5 py-1 text-[10px] font-mono">
                      {t}
                      <button
                        type="button"
                        onClick={() => setModuleForm({ ...moduleForm, tools: moduleForm.tools.filter(tool => tool !== t) })}
                        className="text-rose-400 hover:text-white text-xs ml-1"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              {/* Practical Labs */}
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Lab Experiments</label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={moduleForm.newPractical}
                    onChange={(e) => setModuleForm({ ...moduleForm, newPractical: e.target.value })}
                    placeholder="e.g. Exploiting Horizontal IDOR"
                    className="flex-1 rounded-xl border border-white/5 bg-white/2 px-3.5 py-2 text-xs outline-none text-white focus:border-white/10"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!moduleForm.newPractical.trim()) return;
                      setModuleForm({
                        ...moduleForm,
                        practical: [...moduleForm.practical, moduleForm.newPractical.trim()],
                        newPractical: ""
                      });
                    }}
                    className="px-3.5 py-2 rounded-xl bg-white/5 text-xs font-bold text-slate-200 border border-white/5 hover:bg-white/10"
                  >
                    Add
                  </button>
                </div>
                <div className="space-y-1.5">
                  {moduleForm.practical.map(p => (
                    <div key={p} className="flex items-center justify-between bg-white/3 border border-white/5 rounded-lg p-2.5 text-[10px] font-mono text-slate-300">
                      <span>🧪 {p}</span>
                      <button
                        type="button"
                        onClick={() => setModuleForm({ ...moduleForm, practical: moduleForm.practical.filter(prac => prac !== p) })}
                        className="text-rose-400 hover:text-white"
                      >
                        Delete
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-white/5">
                <button
                  type="button"
                  onClick={() => setShowEditModuleModal(false)}
                  className="flex-1 px-4 py-2.5 bg-white/2 hover:bg-white/5 border border-white/5 text-slate-300 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleUpdateModule}
                  disabled={!moduleForm.title.trim()}
                  className="flex-1 px-4 py-2.5 bg-gradient-to-r from-[var(--color-brand-blue-alt)] to-[var(--color-brand-blue)] text-white rounded-xl text-xs font-bold uppercase tracking-wider disabled:opacity-30 cursor-pointer"
                >
                  Apply Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Lesson Modal */}
      {showAddLessonModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowAddLessonModal(false)}></div>
          <div className="relative w-full max-w-md border border-white/5 bg-[#0a0a0a] rounded-2xl shadow-2xl p-6">
            <div className="flex items-center justify-between mb-4 border-b border-white/5 pb-3">
              <h3 className="text-xs font-black text-white uppercase tracking-widest font-mono">Add Lecture to Module</h3>
              <button onClick={() => setShowAddLessonModal(false)} className="p-1 hover:bg-white/5 rounded text-slate-400 cursor-pointer">
                <FiX />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono font-mono">Lecture Title</label>
                <input
                  type="text"
                  value={newLessonTitle}
                  onChange={(e) => setNewLessonTitle(e.target.value)}
                  placeholder="e.g. Cross-Origin Resource Sharing (CORS) Attacks"
                  className="w-full rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddLessonModal(false)}
                  className="flex-1 px-4 py-2.5 bg-white/2 hover:bg-white/5 border border-white/5 text-slate-350 rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddLesson}
                  disabled={!newLessonTitle.trim()}
                  className="flex-1 px-4 py-2.5 bg-gradient-to-r from-[var(--color-brand-blue-alt)] to-[var(--color-brand-blue)] text-white rounded-xl text-xs font-bold uppercase tracking-wider disabled:opacity-30 cursor-pointer"
                >
                  Save Lecture
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

// Stat summary helper card
const StatCard = ({
  label,
  value,
  subtitle,
  icon,
}: {
  label: string;
  value: string;
  subtitle?: string;
  icon: React.ReactNode;
}) => (
  <div className="rounded-xl border border-white/5 bg-white/2 p-4 shadow-md flex items-start gap-3.5">
    <div className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-[#111] border border-white/5 flex-shrink-0 text-sm shadow-md">
      {icon}
    </div>
    <div className="min-w-0">
      <div className="text-[8px] font-bold uppercase tracking-wider text-slate-500 leading-none font-mono">
        {label}
      </div>
      <div className="mt-1.5 text-xs font-black text-white leading-snug truncate">
        {value}
      </div>
      {subtitle && (
        <div className="text-[9px] text-slate-500 mt-0.5 font-medium leading-none">
          {subtitle}
        </div>
      )}
    </div>
  </div>
);

export default CourseManagementPage;
