import { useEffect, useMemo, useState } from "react";
import {
  FiTag,
  FiPlus,
  FiCheck,
  FiCopy,
  FiTrash2,
  FiRefreshCw,
  FiCalendar,
  FiX,
  FiEdit2,
  FiSearch,
  FiDollarSign,
  FiCheckCircle
} from "react-icons/fi";
import { auth } from "../../firebase";

type Coupon = {
  id: string;
  code: string;
  discount_type: "percentage" | "flat";
  value: number;
  max_usage: number;
  current_usage: number;
  is_active: boolean;
};

const CouponManagementPage = () => {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  
  const [form, setForm] = useState({
    code: "",
    type: "percentage",
    value: "",
    usageLimit: "",
  });
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [sortBy, setSortBy] = useState("newest");

  useEffect(() => {
    fetchCoupons();
  }, []);

  const fetchCoupons = async () => {
    setLoading(true);
    try {
      const user = auth.currentUser;
      if (!user) return;
      
      const token = await user.getIdToken();
      const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3001";
      
      const response = await fetch(`${API_URL}/api/coupons`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.ok) {
        const data = await response.json();
        setCoupons(data.data || []);
      }
    } catch (error) {
      console.error("Error fetching coupons:", error);
    } finally {
      setLoading(false);
    }
  };

  const addCoupon = async () => {
    if (!form.code.trim() || !form.value.trim() || !form.usageLimit.trim()) return;

    try {
      const user = auth.currentUser;
      if (!user) return;

      const token = await user.getIdToken();
      const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3001";
      
      const response = await fetch(`${API_URL}/api/coupons`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          code: form.code.trim().toUpperCase(),
          discount_type: form.type,
          value: Number(form.value),
          max_usage: Number(form.usageLimit)
        })
      });

      if (response.ok) {
        fetchCoupons();
        setForm({ code: "", type: "percentage", value: "", usageLimit: "" });
        setShowAddModal(false);
      } else {
        const errData = await response.json();
        alert(errData.error || "Failed to create coupon");
      }
    } catch (error) {
      console.error("Error creating coupon:", error);
    }
  };

  const toggleStatus = async (code: string, currentStatus: boolean) => {
    try {
      const user = auth.currentUser;
      if (!user) return;

      const token = await user.getIdToken();
      const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3001";
      
      const response = await fetch(`${API_URL}/api/coupons/${code}/status`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ is_active: !currentStatus })
      });

      if (response.ok) {
        fetchCoupons();
      }
    } catch (error) {
      console.error("Error toggling coupon status:", error);
    }
  };

  const deleteCoupon = async (code: string) => {
    if (!confirm(`Are you sure you want to delete coupon ${code}?`)) return;

    try {
      const user = auth.currentUser;
      if (!user) return;

      const token = await user.getIdToken();
      const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3001";
      
      const response = await fetch(`${API_URL}/api/coupons/${code}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` }
      });

      if (response.ok) {
        fetchCoupons();
      }
    } catch (error) {
      console.error("Error deleting coupon:", error);
    }
  };

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const totalCoupons = coupons.length;
  const activeCoupons = coupons.filter(c => c.is_active).length;
  const usedCoupons = coupons.reduce((sum, c) => sum + (c.current_usage || 0), 0);
  const totalDiscountGiven = useMemo(() => {
    return coupons.reduce((sum, c) => {
      if (c.discount_type === "flat") {
        return sum + (c.value * (c.current_usage || 0));
      } else {
        return sum + (c.value * 100 * (c.current_usage || 0)); // estimate
      }
    }, 0);
  }, [coupons]);

  const filteredCoupons = useMemo(() => {
    let result = coupons;
    const query = searchQuery.trim().toLowerCase();
    if (query) {
      result = result.filter((coupon) =>
        coupon.code.toLowerCase().includes(query)
      );
    }
    if (statusFilter === "active") {
      result = result.filter((c) => c.is_active);
    } else if (statusFilter === "paused") {
      result = result.filter((c) => !c.is_active);
    }
    if (typeFilter === "percentage") {
      result = result.filter((c) => c.discount_type === "percentage");
    } else if (typeFilter === "flat") {
      result = result.filter((c) => c.discount_type === "flat");
    }
    return result;
  }, [coupons, searchQuery, statusFilter, typeFilter]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="space-y-8 animate-fade-in text-slate-200">
      
      {/* Header Panel */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-xl font-black text-white uppercase tracking-tight">Campaign Promos</h1>
          <p className="text-[11px] text-slate-400 font-medium mt-0.5">Deploy and configure discount codes for learning paths.</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={fetchCoupons}
            className="inline-flex items-center gap-1.5 rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs font-bold text-slate-300 hover:bg-white/5"
          >
            <FiRefreshCw className={loading ? "animate-spin text-[var(--color-icy-cyan)]" : ""} /> Sync List
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[var(--color-brand-blue-alt)] to-[var(--color-brand-blue)] px-4 py-2.5 text-xs font-bold text-white uppercase tracking-wider transition-colors cursor-pointer shadow-md shadow-blue-500/10"
          >
            <FiPlus className="text-sm" /> Issue Coupon
          </button>
        </div>
      </div>

      {/* Coupons KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <StatSummaryCard
          icon={<FiTag className="text-indigo-400" />}
          iconBg="bg-indigo-500/10 border-indigo-500/20"
          label="Total Coupons"
          value={totalCoupons.toString()}
          subtitle="All created keys"
        />
        <StatSummaryCard
          icon={<FiCheckCircle className="text-emerald-400" />}
          iconBg="bg-emerald-500/10 border-emerald-500/20"
          label="Active Coupons"
          value={activeCoupons.toString()}
          subtitle="Currently usable"
        />
        <StatSummaryCard
          icon={<FiCalendar className="text-amber-400" />}
          iconBg="bg-amber-500/10 border-amber-500/20"
          label="Usage Volume"
          value={usedCoupons.toString()}
          subtitle="Total checkout claims"
        />
        <StatSummaryCard
          icon={<FiDollarSign className="text-violet-400" />}
          iconBg="bg-violet-500/10 border-violet-500/20"
          label="Total Forgiven"
          value={formatCurrency(totalDiscountGiven)}
          subtitle="Platform deductions"
        />
      </div>

      {/* Filters & Table Database Panel */}
      <div className="rounded-2xl border border-white/5 bg-[#090909] p-6 shadow-xl">
        <div className="flex flex-col gap-4 md:flex-row md:items-center justify-between mb-6">
          <div className="flex flex-wrap items-center gap-3 flex-1">
            <div className="relative w-full md:w-64">
              <FiSearch className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm" />
              <input
                type="text"
                placeholder="Search codes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-xl border border-white/5 bg-white/2 pl-9 pr-4 py-2 text-xs outline-none text-white focus:border-white/10 placeholder:text-slate-500"
              />
            </div>
            
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="rounded-xl border border-white/5 bg-[#121212] px-3.5 py-2 text-xs outline-none text-slate-300 focus:border-white/10"
            >
              <option value="all">All Status</option>
              <option value="active">Active Only</option>
              <option value="paused">Paused Only</option>
            </select>

            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="rounded-xl border border-white/5 bg-[#121212] px-3.5 py-2 text-xs outline-none text-slate-300 focus:border-white/10"
            >
              <option value="all">All Types</option>
              <option value="percentage">Percentage Share</option>
              <option value="flat">Fixed Credit</option>
            </select>
          </div>

          <div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="rounded-xl border border-white/5 bg-[#121212] px-3.5 py-2 text-xs outline-none text-white focus:border-white/10 font-bold"
            >
              <option value="newest">Sort: Newest</option>
              <option value="oldest">Sort: Oldest</option>
            </select>
          </div>
        </div>

        {/* Database Table */}
        {loading && coupons.length === 0 ? (
          <div className="flex justify-center items-center py-20">
            <div className="w-8 h-8 border-2 border-[var(--color-brand-blue)] border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[850px]">
              <thead>
                <tr className="border-b border-white/5 bg-white/1 text-[9px] font-bold uppercase tracking-widest text-slate-500 font-mono">
                  <th className="p-4">Coupon Code</th>
                  <th className="p-4">Calculation Type</th>
                  <th className="p-4">Discount Magnitude</th>
                  <th className="p-4">Scope</th>
                  <th className="p-4">Usage Progress</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/3">
                {filteredCoupons.map((coupon, idx) => {
                  const usagePct = coupon.max_usage > 0 ? (coupon.current_usage / coupon.max_usage) * 100 : 0;
                  const colors = [
                    "bg-indigo-500/10 text-indigo-400 border-indigo-500/20",
                    "bg-sky-500/10 text-sky-400 border-sky-500/20",
                    "bg-violet-500/10 text-violet-400 border-violet-500/20",
                    "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                  ];
                  const colorClass = colors[idx % colors.length];

                  return (
                    <tr key={coupon.id} className="hover:bg-white/1 transition-colors text-xs text-slate-300">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <code className={`px-2.5 py-1 rounded-lg border text-xs font-mono font-black shadow-md ${colorClass}`}>
                            {coupon.code}
                          </code>
                        </div>
                      </td>
                      <td className="p-4 capitalize text-slate-400">{coupon.discount_type}</td>
                      <td className="p-4 font-extrabold text-white">
                        {coupon.discount_type === "percentage" ? `${coupon.value}% Share` : `₹${coupon.value}`}
                      </td>
                      <td className="p-4 text-slate-500 font-mono text-[10px]">ALL_CATALOG</td>
                      <td className="p-4">
                        <div className="w-28">
                          <div className="flex justify-between text-[9px] text-slate-500 mb-1 font-mono">
                            <span>{coupon.current_usage} / {coupon.max_usage}</span>
                            <span>{Math.round(usagePct)}%</span>
                          </div>
                          <div className="w-full bg-white/5 rounded-full h-1 overflow-hidden">
                            <div className="bg-[var(--color-brand-blue)] h-1 rounded-full" style={{ width: `${Math.min(usagePct, 100)}%` }}></div>
                          </div>
                        </div>
                      </td>
                      <td className="p-4">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[9px] font-bold border ${
                          coupon.is_active
                            ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                            : "bg-amber-500/10 text-amber-400 border-amber-500/20"
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${coupon.is_active ? "bg-emerald-500" : "bg-amber-500"}`}></span>
                          {coupon.is_active ? "Active" : "Paused"}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => toggleStatus(coupon.id, coupon.is_active)}
                            className="p-2 hover:bg-white/5 border border-white/5 rounded-lg transition-colors text-slate-400 hover:text-white"
                            title="Toggle Status"
                          >
                            <FiEdit2 className="text-xs" />
                          </button>
                          <button
                            onClick={() => handleCopyCode(coupon.code)}
                            className="p-2 hover:bg-white/5 border border-white/5 rounded-lg transition-colors text-slate-400 hover:text-white"
                            title="Copy code"
                          >
                            {copiedCode === coupon.code ? (
                              <FiCheck className="text-emerald-400 text-xs" />
                            ) : (
                              <FiCopy className="text-xs" />
                            )}
                          </button>
                          <button
                            onClick={() => deleteCoupon(coupon.id)}
                            className="p-2 hover:bg-rose-500/10 border border-white/5 rounded-lg transition-colors text-rose-400 hover:text-rose-300"
                            title="Delete"
                          >
                            <FiTrash2 className="text-xs" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {filteredCoupons.length === 0 && (
              <div className="text-center py-16 text-slate-500 text-xs border border-dashed border-white/5 rounded-2xl mt-4">
                No active coupon campaigns matching selections.
              </div>
            )}
          </div>
        )}
      </div>

      {/* Add Coupon Modal overlay */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowAddModal(false)}></div>
          <div className="relative w-full max-w-md border border-white/5 bg-[#0a0a0a] rounded-2xl shadow-2xl p-6">
            <div className="flex items-center justify-between mb-6 border-b border-white/5 pb-4">
              <h3 className="text-xs font-black text-white uppercase tracking-widest font-mono">Create Discount Campaign Key</h3>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setForm({ code: "", type: "percentage", value: "", usageLimit: "" });
                }}
                className="p-1 hover:bg-white/5 rounded text-slate-400 cursor-pointer"
              >
                <FiX />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Coupon Code</label>
                <input
                  type="text"
                  value={form.code}
                  onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
                  placeholder="e.g. WELCOME10"
                  className="w-full rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                />
              </div>
              
              <div className="grid gap-4 grid-cols-2">
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Type</label>
                  <select
                    value={form.type}
                    onChange={(e) => setForm({ ...form, type: e.target.value })}
                    className="w-full rounded-xl border border-white/5 bg-[#121212] px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                  >
                    <option value="percentage">Percentage share</option>
                    <option value="flat">Fixed INR credit</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Magnitude Value</label>
                  <input
                    type="number"
                    value={form.value}
                    onChange={(e) => setForm({ ...form, value: e.target.value })}
                    placeholder="e.g. 10"
                    className="w-full rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">Usage Cap limit</label>
                <input
                  type="number"
                  value={form.usageLimit}
                  onChange={(e) => setForm({ ...form, usageLimit: e.target.value })}
                  placeholder="e.g. 100"
                  className="w-full rounded-xl border border-white/5 bg-white/2 px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                />
              </div>

              <div className="flex gap-3 pt-4 border-t border-white/5">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setForm({ code: "", type: "percentage", value: "", usageLimit: "" });
                  }}
                  className="flex-1 px-4 py-2.5 bg-white/2 hover:bg-white/5 border border-white/5 text-slate-300 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={addCoupon}
                  disabled={!form.code || !form.value || !form.usageLimit}
                  className="flex-1 px-4 py-2.5 bg-gradient-to-r from-[var(--color-brand-blue-alt)] to-[var(--color-brand-blue)] text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-colors disabled:opacity-30 cursor-pointer"
                >
                  Deploy Campaign
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Stat Summary Helper Card
const StatSummaryCard = ({
  icon,
  iconBg,
  label,
  value,
  subtitle,
}: {
  icon: React.ReactNode;
  iconBg: string;
  label: string;
  value: string;
  subtitle: string;
}) => (
  <div className="bg-[#090909] border border-white/5 rounded-2xl p-5 shadow-xl hover:border-white/10 transition-all flex items-center gap-4">
    <div className={`w-10 h-10 rounded-xl ${iconBg} flex items-center justify-center text-lg flex-shrink-0 border shadow-md`}>
      {icon}
    </div>
    <div>
      <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono">{label}</div>
      <div className="text-lg font-black text-white mt-1 leading-none tracking-tight">{value}</div>
      <div className="text-[10px] text-slate-400 mt-1 font-medium">{subtitle}</div>
    </div>
  </div>
);

export default CouponManagementPage;
