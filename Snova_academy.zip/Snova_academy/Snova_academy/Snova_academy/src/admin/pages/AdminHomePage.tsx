import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import {
  FiBook,
  FiClock,
  FiCheck,
  FiX,
  FiDollarSign,
  FiUsers,
  FiPlus,
  FiEye,
  FiCalendar,
  FiUserPlus,
  FiGift,
} from "react-icons/fi";
import {
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

export interface DashboardStats {
  totalCourses: number;
  totalRegistrations: number;
  pendingRequests: number;
  confirmedRegistrations: number;
  cancelledRegistrations: number;
  totalRevenue: number;
  totalInfluencers: number;
  topInfluencers: Array<{
    id: string;
    name: string;
    revenue: number;
    confirmedLeads: number;
    conversionRate: number;
  }>;
  recentRegistrations: Array<{
    id: string;
    userName: string;
    courseName: string;
    amount: number;
    status: string;
    registeredAt: string;
  }>;
  revenueTrend?: Array<{ date: string; revenue: number }>;
  revenueBreakdown?: Array<{ course: string; revenue: number; color: string }>;
}

interface AdminHomePageProps {
  stats: DashboardStats | null;
  loading: boolean;
}

const AdminHomePage = ({ stats, loading }: AdminHomePageProps) => {
  const navigate = useNavigate();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const openDashboardTab = (tab: string) => {
    navigate(`/management-dashboard-x92f-snova?tab=${tab}`);
  };

  // Use dynamic stats from backend
  const revenueByCourseData = stats?.revenueBreakdown || [];

  const totalRevenueByCoursePie = useMemo(() => {
    return revenueByCourseData.reduce(
      (sum, item) => sum + item.revenue,
      0,
    );
  }, [revenueByCourseData]);

  return (
    <div className="space-y-8 animate-fade-in text-slate-200">
      {/* Upper Meta Row */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-xl font-black text-white uppercase tracking-tight">Overview</h1>
          <p className="text-[11px] text-slate-400 font-medium mt-0.5">
            Academy performance indicators and operations dashboard.
          </p>
        </div>
        <button className="flex items-center gap-2 px-3 py-2 bg-white/2 border border-white/5 hover:bg-white/5 rounded-xl text-xs font-bold uppercase tracking-wider text-slate-300 transition-colors">
          <FiCalendar className="text-[var(--color-icy-cyan)] text-sm" />
          <span>Real-time Sync</span>
        </button>
      </div>

      {loading || !stats ? (
        <div className="flex justify-center items-center py-24">
          <div className="w-10 h-10 border-2 border-[var(--color-brand-blue)] border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : (
        <>
          {/* KPI Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-5">
            <StatCard
              icon={<FiBook className="text-indigo-400" />}
              iconBg="bg-indigo-500/10 border-indigo-500/20"
              label="Total Courses"
              value={stats.totalCourses.toString()}
              subtitle="Published paths"
              sparklineData={[1, 1, 2, 2, 3, 3, 4, stats.totalCourses || 1]}
              sparklineColor="#818CF8"
            />

            <StatCard
              icon={<FiUsers className="text-sky-400" />}
              iconBg="bg-sky-500/10 border-sky-500/20"
              label="Enrollments"
              value={stats.totalRegistrations.toString()}
              subtitle="Total applications"
              sparklineData={[3, 5, 8, 12, 11, 15, stats.totalRegistrations || 10]}
              sparklineColor="#38BDF8"
            />

            <StatCard
              icon={<FiClock className="text-amber-400" />}
              iconBg="bg-amber-500/10 border-amber-500/20"
              label="Pending"
              value={stats.pendingRequests.toString()}
              subtitle="Require review"
              sparklineData={[1, 3, 2, 5, 2, 4, stats.pendingRequests || 2]}
              sparklineColor="#F59E0B"
            />

            <StatCard
              icon={<FiCheck className="text-emerald-400" />}
              iconBg="bg-emerald-500/10 border-emerald-500/20"
              label="Confirmed"
              value={stats.confirmedRegistrations.toString()}
              subtitle="Active keys"
              sparklineData={[2, 4, 6, 8, 9, 12, stats.confirmedRegistrations || 8]}
              sparklineColor="#34D399"
            />

            <StatCard
              icon={<FiX className="text-rose-400" />}
              iconBg="bg-rose-500/10 border-rose-500/20"
              label="Cancelled"
              value={stats.cancelledRegistrations.toString()}
              subtitle="Declined requests"
              sparklineData={[0, 1, 0, 2, 1, 1, stats.cancelledRegistrations || 0]}
              sparklineColor="#F87171"
            />

            <StatCard
              icon={<FiDollarSign className="text-violet-400" />}
              iconBg="bg-violet-500/10 border-violet-500/20"
              label="Gross Revenue"
              value={formatCurrency(stats.totalRevenue)}
              subtitle="Earned platform fees"
              sparklineData={[1000, 3000, 5000, 10000, 12000, 15000, stats.totalRevenue || 1599]}
              sparklineColor="#A78BFA"
            />
          </div>

          {/* Quick Actions & Recent Activity Feed */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Quick Actions */}
            <div className="lg:col-span-2 bg-[#090909] border border-white/5 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
              <div>
                <h2 className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500 mb-1 font-mono">
                  Administrative Utilities
                </h2>
                <p className="text-[11px] text-slate-400 mb-5">Quick access shortcuts to manage Snova Lab</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <QuickActionButton
                    icon={<FiPlus />}
                    label="Manage Curriculum"
                    description="Edit courses, modules, outcomes & labs"
                    onClick={() => openDashboardTab("courses")}
                  />
                  <QuickActionButton
                    icon={<FiEye />}
                    label="Verification Queue"
                    description="Process incoming student approvals"
                    onClick={() => openDashboardTab("registrations")}
                  />
                  <QuickActionButton
                    icon={<FiUserPlus />}
                    label="Affiliate Partners"
                    description="Monitor active influencer conversion metrics"
                    onClick={() => openDashboardTab("influencers")}
                  />
                  <QuickActionButton
                    icon={<FiGift />}
                    label="Marketing Campaigns"
                    description="Issue discount keys and set limits"
                    onClick={() => openDashboardTab("coupons")}
                  />
                </div>
              </div>
            </div>

            {/* System logs */}
            <div className="bg-[#090909] border border-white/5 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <h2 className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500 font-mono">
                    Operational Log
                  </h2>
                  <button
                    onClick={() => openDashboardTab("registrations")}
                    className="text-[9px] font-bold uppercase tracking-wider text-[var(--color-icy-cyan)] hover:brightness-110 transition-all"
                  >
                    Details
                  </button>
                </div>
                <p className="text-[11px] text-slate-400 mb-5">Recent system events log</p>
                
                <div className="space-y-3.5">
                  <ActivityItem
                    icon={<FiUserPlus className="text-sky-400" />}
                    iconBg="bg-sky-500/10 border-sky-500/20"
                    title="Registration request logged"
                    description="A student requested access credentials."
                    time="Just now"
                  />
                  <ActivityItem
                    icon={<FiBook className="text-emerald-400" />}
                    iconBg="bg-emerald-500/10 border-emerald-500/20"
                    title="Catalog sync verified"
                    description='Courses and lesson trees loaded correctly.'
                    time="1h ago"
                  />
                  <ActivityItem
                    icon={<FiDollarSign className="text-violet-400" />}
                    iconBg="bg-violet-500/10 border-violet-500/20"
                    title="Revenue stats updated"
                    description="Aggregated payout ledgers successfully."
                    time="3h ago"
                  />
                </div>
              </div>
            </div>
          </div>



          {/* Lower Grid: Registrations Table & Revenue Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Recent Registration Requests */}
            <div className="lg:col-span-2 bg-[#090909] border border-white/5 rounded-2xl p-6 shadow-xl">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-[0.25em] text-slate-500 font-mono">
                    Verification Queue
                  </h3>
                  <p className="text-[10px] text-slate-400 mt-0.5">Most recent active access requests</p>
                </div>
                <button
                  onClick={() =>
                    navigate(
                      "/management-dashboard-x92f-snova?tab=registrations",
                    )
                  }
                  className="text-[10px] font-bold uppercase tracking-wider text-[var(--color-icy-cyan)] hover:brightness-110"
                >
                  Configure
                </button>
              </div>

              {stats.recentRegistrations.length > 0 ? (
                <div className="space-y-3">
                  {stats.recentRegistrations.slice(0, 5).map((reg) => (
                    <div
                      key={reg.id}
                      className="flex items-center gap-3.5 p-3.5 bg-white/2 hover:bg-white/4 border border-white/5 rounded-xl transition-all cursor-pointer"
                      onClick={() =>
                        navigate(
                          "/management-dashboard-x92f-snova?tab=registrations",
                        )
                      }
                    >
                      <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[var(--color-brand-blue-alt)] to-[var(--color-icy-cyan)] flex items-center justify-center text-white font-black shadow-md shadow-black text-sm">
                        {reg.userName.charAt(0).toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-xs text-white">
                          {reg.userName}
                        </div>
                        <div className="text-[10px] text-slate-400 truncate mt-0.5 font-medium">
                          {reg.courseName}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-[9px] text-slate-500 mb-0.5 font-mono">
                          {new Date(reg.registeredAt).toLocaleDateString(
                            "en-GB",
                            { day: "2-digit", month: "short" },
                          )}
                        </div>
                        <div className="text-xs font-bold text-white">
                          {formatCurrency(reg.amount)}
                        </div>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-full text-[9px] font-bold uppercase border ${
                          reg.status === "pending"
                            ? "bg-amber-500/10 text-amber-400 border-amber-500/20"
                            : reg.status === "approved"
                              ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                              : "bg-rose-500/10 text-rose-400 border-rose-500/20"
                        }`}
                      >
                        {reg.status}
                      </span>
                    </div>
                  ))}
                  <div className="pt-3 text-center border-t border-white/5">
                    <div className="text-xs text-slate-400">
                      Unprocessed items currently in queue:{" "}
                      <span className="font-extrabold text-[var(--color-icy-cyan)] font-mono">
                        {stats.pendingRequests}
                      </span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 text-slate-500 text-xs border border-dashed border-white/5 rounded-xl">
                  Verification queue is completely clear.
                </div>
              )}
            </div>

            {/* Revenue by Course Pie Chart */}
            <div className="bg-[#090909] border border-white/5 rounded-2xl p-6 shadow-xl">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-[0.25em] text-slate-500 font-mono">
                    Product Share
                  </h3>
                  <p className="text-[10px] text-slate-400 mt-0.5">Earning division mix</p>
                </div>
                <button 
                  onClick={() => openDashboardTab("revenue")}
                  className="text-[10px] font-bold uppercase tracking-wider text-[var(--color-icy-cyan)] hover:brightness-110"
                >
                  Details
                </button>
              </div>
              
              {revenueByCourseData.length > 0 ? (
                <>
                  <div className="h-44 mb-3">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={revenueByCourseData}
                          cx="50%"
                          cy="50%"
                          innerRadius={38}
                          outerRadius={65}
                          dataKey="revenue"
                          paddingAngle={3}
                        >
                          {revenueByCourseData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color || "#00A8FF"} />
                          ))}
                        </Pie>
                        <Tooltip
                          formatter={(value: any) => [
                            `₹${Number(value || 0).toLocaleString()}`,
                            "Revenue",
                          ]}
                          contentStyle={{
                            backgroundColor: "#0d0d0d",
                            border: "1px solid rgba(255,255,255,0.08)",
                            borderRadius: "12px",
                            fontSize: "11px",
                            color: "#fff"
                          }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="space-y-2">
                    {revenueByCourseData.map((course, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between text-[11px]"
                      >
                        <div className="flex items-center gap-2">
                          <div
                            className="w-2.5 h-2.5 rounded-full"
                            style={{ backgroundColor: course.color }}
                          ></div>
                          <span className="text-slate-300 truncate max-w-36 font-semibold">
                            {course.course}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 font-mono">
                          <span className="font-bold text-white">
                            {formatCurrency(course.revenue)}
                          </span>
                          <span className="text-slate-500 text-[10px]">
                            {totalRevenueByCoursePie > 0 ? (
                              ((course.revenue / totalRevenueByCoursePie) * 100).toFixed(1)
                            ) : "0"}
                            %
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 pt-4 border-t border-white/5 text-center">
                    <div className="text-[10px] text-slate-500 uppercase tracking-widest font-mono">Gross Total</div>
                    <div className="text-lg font-black text-white mt-1">
                      {formatCurrency(totalRevenueByCoursePie)}
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center py-16 text-slate-500 text-xs border border-dashed border-white/5 rounded-xl">
                  No payment data registered yet.
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

// Stat Card Component
interface StatCardProps {
  icon: React.ReactNode;
  iconBg: string;
  label: string;
  value: string;
  subtitle: string;
  sparklineData?: number[];
  sparklineColor?: string;
}

const StatCard = ({ icon, iconBg, label, value, subtitle, sparklineData, sparklineColor = "#3B82F6" }: StatCardProps) => {
  const min = sparklineData && sparklineData.length > 0 ? Math.min(...sparklineData) : 0;
  const max = sparklineData && sparklineData.length > 0 ? Math.max(...sparklineData) : 100;
  const range = max - min || 1;
  const width = 100;
  const height = 15;
  const points = sparklineData && sparklineData.length > 1 
    ? sparklineData.map((val, idx) => {
        const x = (idx / (sparklineData.length - 1)) * width;
        const y = height - 1 - ((val - min) / range) * (height - 2);
        return `${x},${y}`;
      }).join(" ")
    : "";

  return (
    <div className="bg-[#090909] border border-white/5 rounded-2xl p-4 shadow-xl hover:border-white/10 hover:shadow-black transition-all flex flex-col justify-between h-36">
      <div className="flex items-center justify-between">
        <div className={`w-8 h-8 rounded-lg ${iconBg} flex items-center justify-center border text-sm`}>
          {icon}
        </div>
        {sparklineData && sparklineData.length > 1 && (
          <svg className="w-16 h-4" viewBox={`0 0 ${width} ${height}`}>
            <polyline
              fill="none"
              stroke={sparklineColor}
              strokeWidth="1.5"
              points={points}
            />
          </svg>
        )}
      </div>
      <div className="mt-3">
        <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono">
          {label}
        </div>
        <div className="text-lg font-black text-white mt-1 leading-tight tracking-tight">{value}</div>
        <div className="text-[10px] text-slate-400 mt-1 font-medium">{subtitle}</div>
      </div>
    </div>
  );
};

// Quick Action Button Component
interface QuickActionButtonProps {
  icon: React.ReactNode;
  label: string;
  description: string;
  onClick: () => void;
}

const QuickActionButton = ({
  icon,
  label,
  description,
  onClick,
}: QuickActionButtonProps) => {
  return (
    <button
      onClick={onClick}
      className="flex items-center justify-between p-4 bg-white/2 border border-white/5 hover:border-white/10 hover:bg-white/4 rounded-xl transition-all shadow-md cursor-pointer text-left w-full group"
    >
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-[#111] border border-white/5 flex items-center justify-center text-slate-300 text-base group-hover:bg-white/5 transition-colors">
          {icon}
        </div>
        <div>
          <div className="text-xs font-bold text-white group-hover:text-[var(--color-brand-blue)] transition-colors">{label}</div>
          <div className="text-[10px] text-slate-400 mt-0.5 font-medium">{description}</div>
        </div>
      </div>
    </button>
  );
};

// Activity Item Component
interface ActivityItemProps {
  icon: React.ReactNode;
  iconBg: string;
  title: string;
  description: string;
  time: string;
}

const ActivityItem = ({ icon, iconBg, title, description, time }: ActivityItemProps) => {
  return (
    <div className="flex items-start gap-3 p-2 hover:bg-white/2 rounded-xl transition-colors border border-transparent hover:border-white/5">
      <div className={`w-8 h-8 rounded-lg ${iconBg} flex items-center justify-center text-sm shadow-md flex-shrink-0 border`}>
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2">
          <div className="text-xs font-bold text-white truncate">{title}</div>
          <div className="text-[9px] text-slate-500 font-mono whitespace-nowrap">{time}</div>
        </div>
        <div className="text-[10px] text-slate-400 mt-0.5 truncate font-medium">{description}</div>
      </div>
    </div>
  );
};

export default AdminHomePage;
