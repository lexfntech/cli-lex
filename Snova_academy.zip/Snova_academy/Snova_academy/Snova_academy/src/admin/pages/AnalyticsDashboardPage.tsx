import {
  FiUsers,
  FiCheckCircle,
  FiAlertCircle,
  FiTrendingUp,
} from "react-icons/fi";

const funnel = [
  { label: "Platform Visitors", value: "12,400", pct: 100 },
  { label: "Acquired Leads", value: "4,860", pct: 39 },
  { label: "Submitted Registrations", value: "1,120", pct: 22 },
  { label: "Confirmed Enrolls", value: "682", pct: 61 },
];

const channels = [
  { name: "Organic Search Engines", value: 42 },
  { name: "Direct Browser Access", value: 24 },
  { name: "Instagram Referral Link", value: 18 },
  { name: "Influencer Custom Promo", value: 16 },
];

const AnalyticsDashboardPage = () => {
  return (
    <div className="space-y-6 text-slate-200 animate-fade-in">
      
      {/* Metric Cards Row */}
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard 
          label="Total Visitors" 
          value="12,400 Unique" 
          icon={<FiUsers />} 
          iconBg="bg-indigo-500/10 border-indigo-500/20 text-indigo-400"
        />
        <MetricCard 
          label="Conversion Ratio" 
          value="9.3% conversion" 
          icon={<FiTrendingUp />} 
          iconBg="bg-sky-500/10 border-sky-500/20 text-sky-400"
        />
        <MetricCard 
          label="Settled Enrolls" 
          value="682 Active Keys" 
          icon={<FiCheckCircle />} 
          iconBg="bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
        />
        <MetricCard 
          label="System Health Alerts" 
          value="0 Issues logged" 
          icon={<FiAlertCircle />} 
          iconBg="bg-rose-500/10 border-rose-500/20 text-rose-400"
        />
      </div>

      {/* Funnel & Traffic Grid */}
      <div className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
        {/* Conversion Funnel */}
        <div className="rounded-2xl border border-white/5 bg-[#090909] p-6 shadow-xl">
          <h2 className="text-xs font-bold uppercase tracking-[0.25em] text-slate-500 font-mono mb-6">
            Registration Funnel
          </h2>
          <div className="space-y-5">
            {funnel.map((step) => (
              <div key={step.label}>
                <div className="mb-2 flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-200">
                    {step.label}
                  </span>
                  <span className="font-mono text-slate-400">{step.value}</span>
                </div>
                <div className="h-2 rounded-full bg-white/5 overflow-hidden">
                  <div
                    className="h-2 rounded-full bg-gradient-to-r from-[var(--color-brand-blue-alt)] to-[var(--color-icy-cyan)] shadow-[0_0_8px_rgba(0,168,255,0.4)]"
                    style={{ width: `${step.pct}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Traffic Channels */}
        <div className="rounded-2xl border border-white/5 bg-[#090909] p-6 shadow-xl">
          <h2 className="text-xs font-bold uppercase tracking-[0.25em] text-slate-500 font-mono mb-6">
            Traffic Acquisition Sources
          </h2>
          <div className="space-y-4">
            {channels.map((channel) => (
              <div
                key={channel.name}
                className="rounded-xl border border-white/5 bg-white/2 p-3.5"
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-300">
                    {channel.name}
                  </span>
                  <span className="font-black text-white font-mono">
                    {channel.value}%
                  </span>
                </div>
                <div className="mt-2 h-1.5 rounded-full bg-white/5 overflow-hidden">
                  <div
                    className="h-1.5 rounded-full bg-[var(--color-brand-blue)]"
                    style={{ width: `${channel.value}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Action lists & Logs */}
      <div className="grid gap-6 xl:grid-cols-2">
        {/* Recent events */}
        <div className="rounded-2xl border border-white/5 bg-[#090909] p-6 shadow-xl">
          <h2 className="text-xs font-bold uppercase tracking-[0.25em] text-slate-500 font-mono mb-4">
            Recent Audit Activities
          </h2>
          <div className="space-y-3">
            {[
              "5 new registration requests verified & approved",
              "Coupon campaign code 'WELCOME10' usage hit 82 claims",
              "Admin updated 'Cybersecurity Mastery' module outcome targets",
              "Database catalog sync completed successfully",
            ].map((item) => (
              <div
                key={item}
                className="rounded-xl border border-white/5 bg-white/2 p-3.5 text-xs text-slate-300 font-medium"
              >
                ✓ {item}
              </div>
            ))}
          </div>
        </div>

        {/* Action Items */}
        <div className="rounded-2xl border border-white/5 bg-[#090909] p-6 shadow-xl">
          <h2 className="text-xs font-bold uppercase tracking-[0.25em] text-slate-500 font-mono mb-4">
            Required Actions
          </h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <ActionCard
              title="Verification Queue"
              text="Process 12 pending student registration requests."
            />
            <ActionCard
              title="Catalogs Audit"
              text="Map outcomes to cybersecurity labs."
            />
            <ActionCard
              title="Campaigns Audit"
              text="Refresh active discount promo validity dates."
            />
            <ActionCard
              title="Payouts Ledger"
              text="Reconcile influencer generating accounts."
            />
          </div>
        </div>
      </div>
    </div>
  );
};

const MetricCard = ({
  label,
  value,
  icon,
  iconBg,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  iconBg: string;
}) => (
  <div className="rounded-2xl border border-white/5 bg-[#090909] p-5 shadow-xl hover:border-white/10 transition-all">
    <div className={`mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl border ${iconBg} text-sm shadow-md`}>
      {icon}
    </div>
    <div className="text-[9px] font-bold uppercase tracking-widest text-slate-500 font-mono">
      {label}
    </div>
    <div className="mt-1 text-lg font-black text-white leading-none tracking-tight">{value}</div>
  </div>
);

const ActionCard = ({ title, text }: { title: string; text: string }) => (
  <div className="rounded-xl border border-white/5 bg-white/2 p-4 hover:border-white/10 transition-all">
    <div className="font-bold text-xs text-white">{title}</div>
    <div className="mt-1.5 text-[11px] text-slate-400 font-medium leading-relaxed">{text}</div>
  </div>
);

export default AnalyticsDashboardPage;
