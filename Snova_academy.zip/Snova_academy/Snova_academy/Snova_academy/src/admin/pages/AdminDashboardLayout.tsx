import { useEffect, useState, type ReactNode } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import {
  FiBell,
  FiBook,
  FiCalendar,
  FiClipboard,
  FiGrid,
  FiHome,
  FiLogOut,
  FiMenu,
  FiPackage,
  FiPieChart,
  FiSettings,
  FiShield,
  FiTag,
  FiTrendingUp,
  FiUserCheck,
  FiUsers,
  FiX,
} from "react-icons/fi";
import { auth } from "../../firebase";
import { signOut, onAuthStateChanged, type User } from "firebase/auth";
import AdminHomePage, { type DashboardStats } from "./AdminHomePage";
import AnalyticsDashboardPage from "./AnalyticsDashboardPage";
import CouponManagementPage from "./CouponManagementPage";
import CourseManagementPage from "./CourseManagementPage";
import RevenueDashboardPage from "./RevenueDashboardPage";
import InfluencerManagement from "../../components/InfluencerManagement";
import RegistrationManagement from "../../components/RegistrationManagement";
import UserManagement from "../components/UserManagement";

type TabType =
  | "home"
  | "registrations"
  | "confirmed-registrations"
  | "cancelled-registrations"
  | "influencers"
  | "users"
  | "courses"
  | "modules-lessons"
  | "coupons"
  | "revenue"
  | "analytics"
  | "notifications"
  | "settings";

type NavItem = {
  tab: TabType;
  label: string;
  icon: ReactNode;
  badge?: string;
};

type NavSection = {
  title: string;
  items: NavItem[];
};

type TabMeta = {
  group: string;
  title: string;
  description: string;
  accent: string;
  icon: ReactNode;
};

const navSections: NavSection[] = [
  {
    title: "Course Management",
    items: [
      { tab: "home", label: "Dashboard", icon: <FiHome /> },
      { tab: "courses", label: "Courses & Syllabus", icon: <FiBook /> },
    ],
  },
  {
    title: "Registrations",
    items: [
      {
        tab: "registrations",
        label: "Pending Requests",
        icon: <FiClipboard />,
        badge: "12",
      },
      {
        tab: "confirmed-registrations",
        label: "Confirmed Enrolls",
        icon: <FiUserCheck />,
      },
      {
        tab: "cancelled-registrations",
        label: "Cancelled Leads",
        icon: <FiX />,
      },
    ],
  },
  {
    title: "Partners",
    items: [
      { tab: "influencers", label: "Influencer Hub", icon: <FiTrendingUp /> },
    ],
  },
  {
    title: "Marketing",
    items: [{ tab: "coupons", label: "Discount Coupons", icon: <FiTag /> }],
  },
  {
    title: "Business Intel",
    items: [
      { tab: "revenue", label: "Revenue Dashboard", icon: <FiPieChart /> },
      { tab: "analytics", label: "Growth Analytics", icon: <FiTrendingUp /> },
    ],
  },
  {
    title: "System Control",
    items: [
      { tab: "notifications", label: "Notifications", icon: <FiBell /> },
      { tab: "settings", label: "Preferences", icon: <FiSettings /> },
    ],
  },
];

const validTabs: TabType[] = [
  "home",
  "registrations",
  "confirmed-registrations",
  "cancelled-registrations",
  "influencers",
  "users",
  "courses",
  "modules-lessons",
  "coupons",
  "revenue",
  "analytics",
  "notifications",
  "settings",
];

const tabMeta: Record<TabType, TabMeta> = {
  home: {
    group: "Core Platform",
    title: "Executive Dashboard",
    description: "Monitor registration funnels, platform revenue, and live influencer campaigns.",
    accent: "from-[var(--color-icy-cyan)] to-[var(--color-brand-blue)]",
    icon: <FiHome />,
  },
  registrations: {
    group: "Enrollments",
    title: "Pending Registrations",
    description: "Review student applications, verify credentials, and approve access keys.",
    accent: "from-amber-400 to-orange-500",
    icon: <FiClipboard />,
  },
  "confirmed-registrations": {
    group: "Enrollments",
    title: "Active Students",
    description: "Inspect confirmed registrations and track active curriculum progress.",
    accent: "from-emerald-400 to-teal-500",
    icon: <FiUserCheck />,
  },
  "cancelled-registrations": {
    group: "Enrollments",
    title: "Inactive Leads",
    description: "Review rejected registration requests and audit audit history trails.",
    accent: "from-rose-400 to-red-500",
    icon: <FiX />,
  },
  influencers: {
    group: "Partner Program",
    title: "Influencer Performance Hub",
    description: "Oversee affiliate tracking, custom referral keys, and payout calculations.",
    accent: "from-violet-400 to-fuchsia-500",
    icon: <FiTrendingUp />,
  },
  users: {
    group: "Accounts",
    title: "Identity Directory",
    description: "Manage global user profiles, role access levels, and security flags.",
    accent: "from-cyan-400 to-sky-500",
    icon: <FiUsers />,
  },
  courses: {
    group: "Curriculum Studio",
    title: "Course Catalog Workspace",
    description: "Create learning paths, adjust pricing configurations, and manage syllabus modules.",
    accent: "from-indigo-400 to-blue-500",
    icon: <FiBook />,
  },
  "modules-lessons": {
    group: "Curriculum Studio",
    title: "Modules & Lessons",
    description: "Edit granular module details, required hacking tools, and lesson outcome lists.",
    accent: "from-indigo-400 to-sky-500",
    icon: <FiGrid />,
  },
  coupons: {
    group: "Marketing Engine",
    title: "Discount Coupons Studio",
    description: "Configure discount codes, set usage caps, and deploy active campaigns.",
    accent: "from-amber-400 to-yellow-500",
    icon: <FiTag />,
  },
  revenue: {
    group: "Financial Intel",
    title: "Platform Revenue Monitor",
    description: "Audit incoming payments, coupon usage, and net-growth statistics.",
    accent: "from-emerald-400 to-lime-500",
    icon: <FiPieChart />,
  },
  analytics: {
    group: "Behavioral Intel",
    title: "Conversion Funnel Analytics",
    description: "Analyze user traffic sources, click-through rates, and conversion ratios.",
    accent: "from-violet-400 to-sky-500",
    icon: <FiTrendingUp />,
  },
  notifications: {
    group: "System Utilities",
    title: "System Alerts Center",
    description: "Read system logs, high-priority notifications, and action logs.",
    accent: "from-slate-400 to-slate-600",
    icon: <FiBell />,
  },
  settings: {
    group: "System Utilities",
    title: "Dashboard Preferences",
    description: "Configure administrative controls, security settings, and API variables.",
    accent: "from-slate-400 to-slate-700",
    icon: <FiSettings />,
  },
};

function normalizeTab(tabParam: string | null): TabType {
  if (tabParam === "modules-lessons") return "courses"; // combine them visually
  return validTabs.includes(tabParam as TabType)
    ? (tabParam as TabType)
    : "home";
}

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3001";

const AdminDashboardLayout = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const tabParam = searchParams.get("tab");
  const [activeTab, setActiveTab] = useState<TabType>(normalizeTab(tabParam));
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loadingStats, setLoadingStats] = useState<boolean>(true);

  useEffect(() => {
    let active = true;
    
    const fetchStats = async (user: User) => {
      try {
        setLoadingStats(true);
        const token = await user.getIdToken();
        const response = await fetch(`${API_URL}/api/admin/dashboard-stats`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (response.ok && active) {
          const data = await response.json();
          setStats(data.data);
        } else if (active) {
          console.error("Failed to fetch dashboard stats");
        }
      } catch (error) {
        console.error("Error fetching dashboard stats:", error);
      } finally {
        if (active) {
          setLoadingStats(false);
        }
      }
    };

    if (activeTab === "home") {
      const unsubscribe = onAuthStateChanged(auth, (user) => {
        if (user) {
          fetchStats(user);
        } else {
          setLoadingStats(false);
        }
      });
      return () => {
        active = false;
        unsubscribe();
      };
    }
  }, [activeTab]);

  useEffect(() => {
    setActiveTab(normalizeTab(tabParam));
  }, [tabParam]);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setTimeout(() => {
        navigate("/", { replace: true });
      }, 100);
    } catch (error) {
      console.error("Error signing out", error);
    }
  };

  const changeTab = (tab: TabType) => {
    setActiveTab(tab);
    setSearchParams({ tab });
    setIsSidebarOpen(false);
  };

  const activeMeta = tabMeta[activeTab];

  return (
    <div className="min-h-screen flex bg-[#030303] text-slate-100 font-sans selection:bg-[var(--color-brand-blue)]/30 selection:text-white">
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/80 backdrop-blur-sm lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Modern Premium Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-white/5 bg-[#090909] transform transition-transform duration-350 ease-[cubic-bezier(0.32,0.72,0,1)] lg:static lg:translate-x-0 ${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        }`}
      >
        {/* Brand Container */}
        <div className="border-b border-white/5 px-6 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-[var(--color-brand-blue-alt)] to-[var(--color-icy-cyan)] text-white shadow-[0_4px_12px_rgba(0,168,255,0.25)]">
              <FiShield className="text-lg" />
            </div>
            <div>
              <h1 className="text-sm font-black tracking-widest text-white uppercase font-sans">
                SNOVA LAB
              </h1>
              <p className="text-[9px] font-mono tracking-wider text-[var(--color-icy-cyan)] font-bold uppercase">
                ADMIN CONSOLE
              </p>
            </div>
          </div>
          <button
            className="text-slate-400 transition-colors hover:text-white lg:hidden"
            onClick={() => setIsSidebarOpen(false)}
            aria-label="Close sidebar"
          >
            <FiX className="text-lg" />
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 space-y-6 overflow-y-auto px-4 py-6 scrollbar-none">
          {navSections.map((section) => (
            <div key={section.title} className="space-y-1.5">
              <p className="px-3 text-[9px] font-bold uppercase tracking-[0.25em] text-slate-500 font-mono">
                {section.title}
              </p>
              <div className="space-y-0.5">
                {section.items.map((item) => (
                  <NavLink
                    key={item.tab}
                    icon={item.icon}
                    label={item.label}
                    active={activeTab === item.tab}
                    badge={item.badge}
                    onClick={() => changeTab(item.tab)}
                  />
                ))}
              </div>
            </div>
          ))}
        </nav>

        {/* Logout Container */}
        <div className="border-t border-white/5 p-4 bg-[#060606]">
          <button
            onClick={handleLogout}
            className="flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left text-xs font-bold uppercase tracking-widest text-slate-400 transition-all duration-300 hover:bg-red-500/10 hover:text-red-400"
          >
            <FiLogOut />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Workspace */}
      <div className="flex min-h-screen flex-1 flex-col overflow-x-hidden">
        {/* Sticky Glassmorphic Header */}
        <header className="sticky top-0 z-30 flex items-center justify-between gap-4 border-b border-white/5 bg-[#030303]/80 px-6 py-4 backdrop-blur-md">
          <button
            className="text-slate-100 lg:hidden hover:text-[var(--color-brand-blue)] transition-colors"
            onClick={() => setIsSidebarOpen(true)}
            aria-label="Open sidebar"
          >
            <FiMenu className="text-2xl" />
          </button>

          <div className="flex flex-1 items-center justify-end gap-4">
            <button className="hidden items-center gap-2 rounded-xl border border-white/5 bg-white/3 px-3 py-2 text-xs font-bold uppercase tracking-wider text-slate-300 transition-colors hover:bg-white/5 sm:flex">
              <FiCalendar className="text-[var(--color-icy-cyan)]" />
              <span>Session Data</span>
            </button>

            <button className="relative rounded-xl p-2 bg-white/3 border border-white/5 text-slate-300 transition-colors hover:bg-white/5">
              <FiBell className="text-base" />
              <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.6)] animate-pulse" />
            </button>

            <div className="h-6 w-px bg-white/5"></div>

            {/* Profile widget */}
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-tr from-[var(--color-brand-blue)] to-[var(--color-icy-cyan)] font-extrabold text-white shadow-[0_0_12px_rgba(0,168,255,0.2)] text-xs">
                A
              </div>
              <div className="hidden leading-tight md:block">
                <div className="text-xs font-black text-white uppercase tracking-wider">
                  Admin
                </div>
                <div className="text-[9px] font-bold text-slate-500 font-mono uppercase tracking-widest">
                  Super User
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Workspace Panels Container */}
        <main className="relative flex-1 bg-[#030303] p-6 lg:p-8">
          <div className="relative mx-auto flex w-full max-w-7xl flex-col gap-8">
            {/* Header Showcase Hero */}
            <section className="overflow-hidden rounded-2xl border border-white/5 bg-[#090909] relative shadow-[0_12px_40px_rgba(0,0,0,0.5)]">
              {/* Subtle accent glow */}
              <div className="absolute top-0 right-0 w-64 h-32 bg-gradient-to-br from-[var(--color-brand-blue)]/5 to-transparent blur-3xl pointer-events-none"></div>
              
              <div className="flex flex-col gap-5 px-6 py-6 lg:flex-row lg:items-center lg:justify-between relative z-10">
                <div className="flex items-start gap-4">
                  <div
                    className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#131313] border border-white/10 text-xl text-[var(--color-icy-cyan)] shadow-md shadow-black"
                  >
                    {activeMeta.icon}
                  </div>
                  <div className="space-y-1">
                    <div className="inline-flex items-center rounded-full bg-white/5 border border-white/5 px-2.5 py-0.5 text-[9px] font-bold font-mono tracking-widest text-[var(--color-icy-cyan)] uppercase">
                      {activeMeta.group}
                    </div>
                    <h2 className="text-lg md:text-xl font-black tracking-tight text-white uppercase">
                      {activeMeta.title}
                    </h2>
                    <p className="max-w-2xl text-[11px] text-slate-400 font-medium">
                      {activeMeta.description}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <div className="rounded-xl border border-white/5 bg-white/2 px-4 py-2">
                    <div className="text-[8px] font-bold uppercase tracking-widest text-slate-500 font-mono">
                      Current Panel
                    </div>
                    <div className="mt-0.5 text-xs font-black text-white capitalize font-mono tracking-wide">
                      {activeTab.replace(/-/g, " ")}
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Dynamic View Panel with fade-in */}
            <div className="relative animate-fade-in">
              {activeTab === "home" && (
                <AdminHomePage stats={stats} loading={loadingStats} />
              )}
              {activeTab === "registrations" && (
                <div className="bg-[#090909] border border-white/5 rounded-2xl p-6 shadow-xl">
                  <RegistrationManagement
                    initialStatusFilter="pending"
                    title="Registration Queue"
                    subtitle="Review and process new registrations from the dashboard queue."
                  />
                </div>
              )}
              {activeTab === "confirmed-registrations" && (
                <div className="bg-[#090909] border border-white/5 rounded-2xl p-6 shadow-xl">
                  <RegistrationManagement
                    initialStatusFilter="approved"
                    hideStatusTabs
                    title="Confirmed Registrations"
                    subtitle="All approved registrations and successful enrollments."
                  />
                </div>
              )}
              {activeTab === "cancelled-registrations" && (
                <div className="bg-[#090909] border border-white/5 rounded-2xl p-6 shadow-xl">
                  <RegistrationManagement
                    initialStatusFilter="rejected"
                    hideStatusTabs
                    title="Cancelled Leads Archive"
                    subtitle="Rejected registrations and their review history."
                  />
                </div>
              )}
              {activeTab === "influencers" && (
                <div className="bg-[#090909] border border-white/5 rounded-2xl p-6 shadow-xl">
                  <InfluencerManagement />
                </div>
              )}
              {activeTab === "users" && (
                <div className="bg-[#090909] border border-white/5 rounded-2xl p-6 shadow-xl">
                  <UserManagement />
                </div>
              )}
              {activeTab === "courses" && <CourseManagementPage />}
              {activeTab === "coupons" && <CouponManagementPage />}
              {activeTab === "revenue" && <RevenueDashboardPage />}
              {activeTab === "analytics" && <AnalyticsDashboardPage />}
              {activeTab === "notifications" && (
                <SectionPlaceholder
                  title="System Notifications"
                  description="Review admin alerts, registration updates, and system logs in real time."
                  actionLabel="Mark All Read"
                />
              )}
              {activeTab === "settings" && (
                <SectionPlaceholder
                  title="System Preferences"
                  description="Manage platform configurations, admin access controls, and Firebase credentials."
                  actionLabel="Save Configuration"
                />
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

interface NavLinkProps {
  icon: ReactNode;
  label: string;
  active: boolean;
  badge?: string;
  onClick: () => void;
}

const NavLink = ({ icon, label, active, badge, onClick }: NavLinkProps) => {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-left text-xs font-bold transition-all duration-300 cursor-pointer ${
        active 
          ? "bg-white/5 border border-white/10 text-white shadow-lg shadow-black/30 border-l-2 border-l-[var(--color-brand-blue)]" 
          : "text-slate-400 border border-transparent hover:bg-white/2 hover:text-slate-200"
      }`}
    >
      <span className={`text-sm ${active ? "text-[var(--color-brand-blue)]" : ""}`}>{icon}</span>
      <span className="flex-1 font-sans tracking-wide">{label}</span>
      {badge && (
        <span className="rounded-full bg-rose-500/10 border border-rose-500/20 px-2 py-0.5 text-[8px] font-extrabold font-mono text-rose-400">
          {badge}
        </span>
      )}
    </button>
  );
};

interface SectionPlaceholderProps {
  title: string;
  description: string;
  actionLabel: string;
}

const SectionPlaceholder = ({
  title,
  description,
  actionLabel,
}: SectionPlaceholderProps) => {
  return (
    <div className="flex min-h-[50vh] items-center justify-center rounded-2xl border border-white/5 bg-[#090909] p-8 shadow-xl sm:p-12 text-slate-100">
      <div className="max-w-md space-y-5 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-white/3 border border-white/5 text-slate-400">
          <FiPackage className="text-2xl" />
        </div>
        <div>
          <h2 className="text-xl font-black tracking-tight text-white uppercase sm:text-2xl">
            {title}
          </h2>
          <p className="mt-2 text-xs text-slate-400 leading-relaxed">{description}</p>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button className="rounded-xl bg-gradient-to-r from-[var(--color-brand-blue-alt)] to-[var(--color-brand-blue)] px-5 py-3 text-xs font-bold uppercase tracking-wider text-white hover:brightness-110 transition-all shadow-md shadow-blue-500/10">
            {actionLabel}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboardLayout;
