import React from "react";
import {
  FiBookOpen,
  FiCheckCircle,
  FiClock,
  FiTrendingUp,
} from "react-icons/fi";

/* ---------------- TYPES ---------------- */

type FlowItem = {
  label: string;
  value: string;
  pct: number;
};

type ChannelItem = {
  name: string;
  value: number;
};

type MetricCardProps = {
  label: string;
  value: string;
  icon: React.ReactNode;
  iconBg: string;
};

type ActionCardProps = {
  title: string;
  text: string;
};

/* ---------------- DATA ---------------- */

const learningFlow: FlowItem[] = [
  { label: "Courses Enrolled", value: "6", pct: 100 },
  { label: "Active Learning", value: "5", pct: 85 },
  { label: "Modules Completed", value: "18", pct: 65 },
  { label: "Assignments Submitted", value: "9", pct: 40 },
];

const learningSources: ChannelItem[] = [
  { name: "Video Lectures", value: 45 },
  { name: "Assignments", value: 25 },
  { name: "Reading Materials", value: 20 },
  { name: "Practice Tests", value: 10 },
];

/* ---------------- PAGE ---------------- */

const StudentDashboardPage: React.FC = () => {
  return (
    <div className="space-y-6 text-slate-200">

      {/* Metric Cards */}
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">

        <MetricCard
          label="Enrolled Courses"
          value="6 Active Courses"
          icon={<FiBookOpen />}
          iconBg="bg-indigo-500/10 border-indigo-500/20 text-indigo-400"
        />

        <MetricCard
          label="Completed Modules"
          value="18 Modules Done"
          icon={<FiCheckCircle />}
          iconBg="bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
        />

        <MetricCard
          label="Pending Tasks"
          value="3 Assignments Due"
          icon={<FiClock />}
          iconBg="bg-rose-500/10 border-rose-500/20 text-rose-400"
        />

        <MetricCard
          label="Overall Progress"
          value="72% Learning Done"
          icon={<FiTrendingUp />}
          iconBg="bg-sky-500/10 border-sky-500/20 text-sky-400"
        />
      </div>

      {/* Progress + Sources */}
      <div className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">

        {/* Learning Flow */}
        <div className="rounded-2xl border border-white/10 bg-[#090909] p-6 shadow-xl">
          <h2 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-6">
            Learning Progress Tracker
          </h2>

          <div className="space-y-5">
            {learningFlow.map((step) => (
              <div key={step.label}>
                <div className="mb-2 flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-200">
                    {step.label}
                  </span>
                  <span className="font-mono text-slate-400">
                    {step.value}
                  </span>
                </div>

                <div className="h-2 rounded-full bg-white/5 overflow-hidden">
                  <div
                    className="h-2 rounded-full bg-gradient-to-r from-indigo-500 to-cyan-400"
                    style={{ width: `${step.pct}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Learning Sources */}
        <div className="rounded-2xl border border-white/10 bg-[#090909] p-6 shadow-xl">
          <h2 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-6">
            Learning Breakdown
          </h2>

          <div className="space-y-4">
            {learningSources.map((item) => (
              <div
                key={item.name}
                className="rounded-xl border border-white/10 bg-white/5 p-3.5"
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-300">
                    {item.name}
                  </span>
                  <span className="font-black text-white font-mono">
                    {item.value}%
                  </span>
                </div>

                <div className="mt-2 h-1.5 rounded-full bg-white/5 overflow-hidden">
                  <div
                    className="h-1.5 rounded-full bg-indigo-500"
                    style={{ width: `${item.value}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Activity + Tasks */}
      <div className="grid gap-6 xl:grid-cols-2">

        {/* Activity */}
        <div className="rounded-2xl border border-white/10 bg-[#090909] p-6 shadow-xl">
          <h2 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-4">
            Recent Learning Activity
          </h2>

          <div className="space-y-3">
            {[
              "Completed React State Management module",
              "Scored 85% in JavaScript Quiz",
              "Submitted Assignment: CSS Layouts",
              "Joined Full Stack Study Group",
            ].map((item) => (
              <div
                key={item}
                className="rounded-xl border border-white/10 bg-white/5 p-3.5 text-xs text-slate-300"
              >
                ✓ {item}
              </div>
            ))}
          </div>
        </div>

        {/* Tasks */}
        <div className="rounded-2xl border border-white/10 bg-[#090909] p-6 shadow-xl">
          <h2 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-4">
            Your Tasks
          </h2>

          <div className="grid gap-4 sm:grid-cols-2">
            <ActionCard
              title="Complete Assignment"
              text="Submit React project before deadline"
            />
            <ActionCard
              title="Watch Lectures"
              text="Finish backend module videos"
            />
            <ActionCard
              title="Practice Test"
              text="Attempt JavaScript mock test"
            />
            <ActionCard
              title="Revise Notes"
              text="Review Module 2 concepts"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

/* ---------------- COMPONENTS ---------------- */

const MetricCard: React.FC<MetricCardProps> = ({
  label,
  value,
  icon,
  iconBg,
}) => {
  return (
    <div className="rounded-2xl border border-white/10 bg-[#090909] p-5 shadow-xl hover:border-white/20 transition">
      <div
        className={`mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl border ${iconBg}`}
      >
        {icon}
      </div>

      <div className="text-[10px] font-bold uppercase tracking-widest text-slate-500">
        {label}
      </div>

      <div className="mt-1 text-lg font-black text-white">
        {value}
      </div>
    </div>
  );
};

const ActionCard: React.FC<ActionCardProps> = ({ title, text }) => {
  return (
    <div className="rounded-xl border border-white/10 bg-white/5 p-4 hover:border-white/20 transition">
      <div className="font-bold text-xs text-white">{title}</div>
      <div className="mt-1.5 text-[11px] text-slate-400">
        {text}
      </div>
    </div>
  );
};

export default StudentDashboardPage;