import {
  FiCalendar,
  FiDollarSign,
  FiTrendingUp,
  FiPieChart,
} from "react-icons/fi";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
} from "recharts";

const revenueTrend = [
  { day: "Mon", revenue: 96000 },
  { day: "Tue", revenue: 108000 },
  { day: "Wed", revenue: 115000 },
  { day: "Thu", revenue: 123000 },
  { day: "Fri", revenue: 119000 },
  { day: "Sat", revenue: 132000 },
  { day: "Sun", revenue: 141000 },
];

const revenueBreakdown = [
  { name: "Cybersecurity Mastery", value: 456000, color: "#38BDF8" },
  { name: "Introduction to Ethical Hacking", value: 245000, color: "#818CF8" },
  { name: "Advanced Web Pentesting", value: 145000, color: "#34D399" },
  { name: "Bug Bounty Methodologies", value: 110300, color: "#F59E0B" },
];

const RevenueDashboardPage = () => {
  const totalRevenue = revenueBreakdown.reduce(
    (sum, item) => sum + item.value,
    0,
  );

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="space-y-6 text-slate-200 animate-fade-in">
      
      {/* Metric Cards Grid */}
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          label="Total Revenue"
          value={formatCurrency(totalRevenue)}
          icon={<FiDollarSign />}
          iconBg="bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
        />
        <MetricCard 
          label="Month Growth" 
          value="+22.8%" 
          icon={<FiTrendingUp />} 
          iconBg="bg-sky-500/10 border-sky-500/20 text-sky-400"
        />
        <MetricCard
          label="Flagship Volume"
          value="Cybersecurity Mastery"
          icon={<FiPieChart />}
          iconBg="bg-indigo-500/10 border-indigo-500/20 text-indigo-400"
        />
        <MetricCard 
          label="Active Coupons" 
          value="4 Active" 
          icon={<FiCalendar />} 
          iconBg="bg-amber-500/10 border-amber-500/20 text-amber-400"
        />
      </div>

      {/* Double Column Chart Section */}
      <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        {/* Line Chart */}
        <div className="rounded-2xl border border-white/5 bg-[#090909] p-6 shadow-xl">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h2 className="text-xs font-bold uppercase tracking-[0.25em] text-slate-500 font-mono">
                Weekly Revenue Velocity
              </h2>
              <p className="text-[10px] text-slate-400 mt-0.5">
                Real-time transaction aggregate timeline profile.
              </p>
            </div>
            <div className="text-[9px] font-bold uppercase tracking-wider text-[var(--color-icy-cyan)] px-2.5 py-1 bg-white/3 border border-white/5 rounded-lg">
              Live Monitor
            </div>
          </div>
          
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={revenueTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.03)" />
                <XAxis 
                  dataKey="day" 
                  stroke="#475569" 
                  style={{ fontSize: "10px", fontFamily: "var(--font-mono)" }}
                />
                <YAxis 
                  stroke="#475569" 
                  style={{ fontSize: "10px", fontFamily: "var(--font-mono)" }}
                  tickFormatter={(val) => `₹${val/1000}k`}
                />
                <Tooltip
                  formatter={(value: any) => [
                    `₹${Number(value || 0).toLocaleString()}`,
                    "Gross Earning",
                  ]}
                  contentStyle={{
                    backgroundColor: "#0d0d0d",
                    border: "1px solid rgba(255,255,255,0.08)",
                    borderRadius: "12px",
                    fontSize: "11px",
                    color: "#fff"
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="revenue"
                  stroke="#38BDF8"
                  strokeWidth={2}
                  dot={{ fill: "#38BDF8", r: 3 }}
                  activeDot={{ r: 5, strokeWidth: 0 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pie Chart */}
        <div className="rounded-2xl border border-white/5 bg-[#090909] p-6 shadow-xl">
          <h2 className="text-xs font-bold uppercase tracking-[0.25em] text-slate-500 font-mono mb-6">
            Earning Share division
          </h2>
          
          <div className="h-52 mb-4">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={revenueBreakdown}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={42}
                  outerRadius={75}
                  paddingAngle={3}
                >
                  {revenueBreakdown.map((entry) => (
                    <Cell key={entry.name} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value: any) => [
                    `₹${Number(value || 0).toLocaleString()}`,
                    "Earnings",
                  ]}
                  contentStyle={{
                    backgroundColor: "#0d0d0d",
                    border: "1px solid rgba(255,255,255,0.08)",
                    borderRadius: "12px",
                    fontSize: "11px",
                    color: "#fff"
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          <div className="space-y-2.5">
            {revenueBreakdown.map((course) => (
              <div
                key={course.name}
                className="flex items-center justify-between gap-4 text-[11px]"
              >
                <div className="flex items-center gap-2">
                  <span
                    className="h-2.5 w-2.5 rounded-full"
                    style={{ backgroundColor: course.color }}
                  />
                  <span className="text-slate-300 font-semibold truncate max-w-40">{course.name}</span>
                </div>
                <div className="flex items-center gap-2 font-mono">
                  <span className="font-bold text-white">{formatCurrency(course.value)}</span>
                  <span className="text-slate-500 text-[10px]">
                    {Math.round((course.value / totalRevenue) * 100)}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Net Summary Blocks */}
      <div className="rounded-2xl border border-white/5 bg-[#090909] p-6 shadow-xl">
        <h2 className="text-xs font-bold uppercase tracking-[0.25em] text-slate-500 font-mono mb-4">Financial Ledger Summary</h2>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <SummaryRow label="Gross Platform Revenue" value={formatCurrency(totalRevenue)} />
          <SummaryRow label="Discounts & Refunds" value="₹12,000" />
          <SummaryRow label="Net Settled Revenue" value={formatCurrency(totalRevenue - 12000)} />
          <SummaryRow label="Enrollment conversions" value="112 Enrolls" />
        </div>
      </div>
    </div>
  );
};

const MetricCard = ({
  label,
  value,
  icon,
  iconBg
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  iconBg: string;
}) => (
  <div className="rounded-2xl border border-white/5 bg-[#090909] p-5 shadow-xl hover:border-white/10 hover:shadow-black transition-all">
    <div className={`mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl border ${iconBg}`}>
      {icon}
    </div>
    <div className="text-[9px] font-bold uppercase tracking-widest text-slate-500 font-mono">
      {label}
    </div>
    <div className="mt-1 text-lg font-black text-white leading-none tracking-tight">{value}</div>
  </div>
);

const SummaryRow = ({ label, value }: { label: string; value: string }) => (
  <div className="rounded-xl border border-white/5 bg-white/2 p-4">
    <div className="text-[8px] font-bold uppercase tracking-widest text-slate-500 font-mono">
      {label}
    </div>
    <div className="mt-1.5 text-xs font-bold text-white">{value}</div>
  </div>
);

export default RevenueDashboardPage;
