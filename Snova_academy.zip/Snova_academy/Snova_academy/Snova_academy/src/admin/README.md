# Admin Module Structure

This folder contains all admin-related components, pages, and utilities for the Snova Academy Admin Dashboard.

## Folder Structure

```
admin/
├── components/           # Reusable admin components
│   └── UserManagement.tsx
├── pages/               # Admin page components
│   ├── AdminDashboardLayout.tsx  # Main admin layout with sidebar
│   └── AdminHomePage.tsx         # Dashboard homepage with KPIs
├── store/               # Admin-specific Redux slices (if needed)
└── utils/               # Admin utility functions
```

## Pages

### AdminDashboardLayout.tsx
- Main layout wrapper for all admin pages
- Contains sidebar navigation with tabs:
  - Dashboard (Home)
  - Registrations
  - Influencers
  - Users
- Sign out functionality
- URL-based tab routing (`?tab=home|registrations|influencers|users`)

### AdminHomePage.tsx
- Dashboard homepage showing KPI cards:
  - Total Courses
  - Total Registration Requests
  - Pending Requests
  - Confirmed Registrations
  - Cancelled Registrations
  - Total Revenue
  - Total Influencers
- Quick action buttons for common tasks
- Top performing influencers section
- Recent registration requests section

## Components

### UserManagement.tsx
- Displays all users in a table
- Search functionality
- Shows user role badges (admin, influencer, student)
- User registration dates

## Integration

The admin dashboard is integrated into the main app via:
- **Route**: `/management-dashboard-x92f-snova`
- **Protection**: AdminProtectedRoute (requires admin role in Firestore)
- **Entry Point**: `src/App.tsx`

## Backend API

Admin dashboard uses the following endpoints:
- `GET /api/admin/dashboard-stats` - Fetch all dashboard statistics
- `GET /api/auth/users` - Fetch all users

## Usage

Import admin components from the admin folder:
```tsx
import AdminDashboardLayout from './admin/pages/AdminDashboardLayout';
import AdminHomePage from './admin/pages/AdminHomePage';
import UserManagement from './admin/components/UserManagement';
```

## Future Additions

According to PRD, these features will be added:
- Course Management (Add/Edit/Delete courses)
- Coupon Management (Create/Edit/Disable coupons)
- Revenue Dashboard with charts
- Notification system
- Advanced analytics
