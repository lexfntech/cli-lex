import { createSlice, createAsyncThunk, type PayloadAction } from '@reduxjs/toolkit';
import { auth } from '../firebase';

export interface Registration {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  userPhone?: string;
  courseId: string;
  courseName: string;
  coursePrice: number;
  couponUsed: string | null;
  status: 'pending' | 'approved' | 'rejected';
  progress: {
    completedModules: string[];
  };
  referralSource: string | null;
  influencerId: string | null;
  referralCode: string | null;
  registeredAt: string;
  updatedAt: string;
  approvedAt?: string;
  approvedBy?: string;
  rejectedAt?: string;
  rejectedBy?: string;
  rejectionReason?: string;
}

interface RegistrationState {
  registrations: Registration[];
  userRegistrations: Registration[];
  loading: boolean;
  error: string | null;
  selectedRegistration: Registration | null;
}

const initialState: RegistrationState = {
  registrations: [],
  userRegistrations: [],
  loading: false,
  error: null,
  selectedRegistration: null,
};

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';

// Helper function to get auth token
const getAuthToken = async () => {
  const user = auth.currentUser;
  if (!user) throw new Error('Not authenticated');
  return await user.getIdToken();
};

// Async thunks
export const fetchRegistrations = createAsyncThunk(
  'registration/fetchAll',
  async (filters: { status?: string; courseId?: string; limit?: number } = {}) => {
    const token = await getAuthToken();
    const params = new URLSearchParams(filters as any);
    const response = await fetch(`${API_URL}/api/registrations?${params}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to fetch registrations');
    const data = await response.json();
    return data.data;
  }
);

export const fetchUserRegistrations = createAsyncThunk(
  'registration/fetchUserRegistrations',
  async () => {
    const token = await getAuthToken();
    const response = await fetch(`${API_URL}/api/registrations/my-registrations`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to fetch user registrations');
    const data = await response.json();
    return data.data;
  }
);

export const fetchRegistrationById = createAsyncThunk(
  'registration/fetchById',
  async (id: string) => {
    const token = await getAuthToken();
    const response = await fetch(`${API_URL}/api/registrations/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to fetch registration');
    const data = await response.json();
    return data.data;
  }
);

export const createRegistration = createAsyncThunk(
  'registration/create',
  async (payload: {
    userId: string;
    userName: string;
    userEmail: string;
    userPhone?: string;
    courseId: string;
    courseName: string;
    coursePrice: number;
    couponUsed?: string;
    referralCode?: string;
  }) => {
    const token = await getAuthToken();
    const response = await fetch(`${API_URL}/api/registrations`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to create registration');
    }
    const data = await response.json();
    return data.data;
  }
);

export const approveRegistration = createAsyncThunk(
  'registration/approve',
  async ({ id, revenueAmount }: { id: string; revenueAmount?: number }) => {
    const token = await getAuthToken();
    const response = await fetch(`${API_URL}/api/registrations/${id}/approve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ revenueAmount }),
    });
    if (!response.ok) throw new Error('Failed to approve registration');
    const data = await response.json();
    return data.data;
  }
);

export const rejectRegistration = createAsyncThunk(
  'registration/reject',
  async ({ id, reason }: { id: string; reason?: string }) => {
    const token = await getAuthToken();
    const response = await fetch(`${API_URL}/api/registrations/${id}/reject`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ reason }),
    });
    if (!response.ok) throw new Error('Failed to reject registration');
    const data = await response.json();
    return data.data;
  }
);

export const deleteRegistration = createAsyncThunk(
  'registration/delete',
  async (id: string) => {
    const token = await getAuthToken();
    const response = await fetch(`${API_URL}/api/registrations/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to delete registration');
    return id;
  }
);

// Slice
const registrationSlice = createSlice({
  name: 'registration',
  initialState,
  reducers: {
    setSelectedRegistration: (state, action: PayloadAction<Registration | null>) => {
      state.selectedRegistration = action.payload;
    },
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch all
      .addCase(fetchRegistrations.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchRegistrations.fulfilled, (state, action) => {
        state.loading = false;
        state.registrations = action.payload;
      })
      .addCase(fetchRegistrations.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || 'Failed to fetch registrations';
      })
      // Fetch user registrations
      .addCase(fetchUserRegistrations.fulfilled, (state, action) => {
        state.userRegistrations = action.payload;
      })
      // Fetch by ID
      .addCase(fetchRegistrationById.fulfilled, (state, action) => {
        state.selectedRegistration = action.payload;
      })
      // Create
      .addCase(createRegistration.fulfilled, (state, action) => {
        state.registrations.unshift(action.payload);
        state.userRegistrations.unshift(action.payload);
      })
      // Approve
      .addCase(approveRegistration.fulfilled, (state, action) => {
        const index = state.registrations.findIndex((r) => r.id === action.payload.id);
        if (index !== -1) {
          state.registrations[index] = action.payload;
        }
        if (state.selectedRegistration?.id === action.payload.id) {
          state.selectedRegistration = action.payload;
        }
      })
      // Reject
      .addCase(rejectRegistration.fulfilled, (state, action) => {
        const index = state.registrations.findIndex((r) => r.id === action.payload.id);
        if (index !== -1) {
          state.registrations[index] = action.payload;
        }
        if (state.selectedRegistration?.id === action.payload.id) {
          state.selectedRegistration = action.payload;
        }
      })
      // Delete
      .addCase(deleteRegistration.fulfilled, (state, action) => {
        state.registrations = state.registrations.filter((r) => r.id !== action.payload);
      });
  },
});

export const { setSelectedRegistration, clearError } = registrationSlice.actions;
export default registrationSlice.reducer;
