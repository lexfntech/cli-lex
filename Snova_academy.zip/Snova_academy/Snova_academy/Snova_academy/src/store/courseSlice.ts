import { createSlice, createAsyncThunk, type PayloadAction } from '@reduxjs/toolkit';
import { auth } from '../firebase';

export interface Lesson {
  title: string;
}

export interface Module {
  id: string;
  title: string;
  lessons: string[];
  outcome?: string;
  practical?: string[];
  tools?: string[];
  subModules?: { title: string; lessons: string[]; practical?: string[]; tools?: string[] }[];
}

export interface Course {
  id: string;
  title: string;
  description: string;
  price: string | number;
  duration: string | number;
  level: string;
  tags: string[];
  features: string[];
  modules: Module[];
  bonusResources?: string[];
  isActive?: boolean;
}

interface CourseState {
  courses: Course[];
  currentCourse: Course | null;
  loading: boolean;
  error: string | null;
}

const initialState: CourseState = {
  courses: [],
  currentCourse: null,
  loading: false,
  error: null
};

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';

// Helper function to get auth token (optional for public endpoints)
const getOptionalAuthToken = async () => {
  const user = auth.currentUser;
  if (!user) return null;
  return await user.getIdToken();
};

const getAuthToken = async () => {
  const user = auth.currentUser;
  if (!user) throw new Error('Not authenticated');
  return await user.getIdToken();
};

// Async thunks
export const fetchCourses = createAsyncThunk(
  'course/fetchAll',
  async () => {
    const token = await getOptionalAuthToken();
    const headers: HeadersInit = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${API_URL}/api/courses`, { headers });
    if (!response.ok) throw new Error('Failed to fetch courses');
    const data = await response.json();
    return data.data;
  }
);

export const fetchCourseById = createAsyncThunk(
  'course/fetchById',
  async (id: string) => {
    const token = await getOptionalAuthToken();
    const headers: HeadersInit = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    const response = await fetch(`${API_URL}/api/courses/${id}`, { headers });
    if (!response.ok) throw new Error('Failed to fetch course');
    const data = await response.json();
    return data.data;
  }
);

export const createCourse = createAsyncThunk<Course, Partial<Course>, { rejectValue: string }>(
  'course/create',
  async (courseData: Partial<Course>, { rejectWithValue }) => {
    try {
      const token = await getAuthToken();
      const response = await fetch(`${API_URL}/api/courses`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(courseData),
      });
      if (!response.ok) {
        const error = await response.json();
        return rejectWithValue(error.error || 'Failed to create course');
      }
      const data = await response.json();
      return data.data;
    } catch (err: any) {
      return rejectWithValue(err.message || 'Failed to create course');
    }
  }
);

export const updateCourse = createAsyncThunk<Course, { id: string; courseData: Partial<Course> }, { rejectValue: string }>(
  'course/update',
  async ({ id, courseData }: { id: string; courseData: Partial<Course> }, { rejectWithValue }) => {
    try {
      const token = await getAuthToken();
      const response = await fetch(`${API_URL}/api/courses/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(courseData),
      });
      if (!response.ok) {
        const error = await response.json();
        return rejectWithValue(error.error || 'Failed to update course');
      }
      const data = await response.json();
      return data.data;
    } catch (err: any) {
      return rejectWithValue(err.message || 'Failed to update course');
    }
  }
);

export const deleteCourse = createAsyncThunk<string, string, { rejectValue: string }>(
  'course/delete',
  async (id: string, { rejectWithValue }) => {
    try {
      const token = await getAuthToken();
      const response = await fetch(`${API_URL}/api/courses/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!response.ok) {
        const error = await response.json();
        return rejectWithValue(error.error || 'Failed to delete course');
      }
      return id;
    } catch (err: any) {
      return rejectWithValue(err.message || 'Failed to delete course');
    }
  }
);

const courseSlice = createSlice({
  name: 'course',
  initialState,
  reducers: {
    setCourse: (state, action: PayloadAction<Course>) => {
      state.currentCourse = action.payload;
    },
    clearCourseError: (state) => {
      state.error = null;
    }
  },
  extraReducers: (builder) => {
    builder
      // Fetch all
      .addCase(fetchCourses.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchCourses.fulfilled, (state, action: PayloadAction<Course[]>) => {
        state.loading = false;
        state.courses = action.payload;
        // Auto-select first active course if none is set yet
        if (!state.currentCourse && action.payload.length > 0) {
          state.currentCourse = action.payload.find(c => c.isActive !== false) || action.payload[0];
        } else if (state.currentCourse) {
          // Sync currentCourse if it is in the list
          const updated = action.payload.find(c => c.id === state.currentCourse?.id);
          if (updated) state.currentCourse = updated;
        }
      })
      .addCase(fetchCourses.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || 'Failed to fetch courses';
      })
      // Fetch by ID
      .addCase(fetchCourseById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchCourseById.fulfilled, (state, action: PayloadAction<Course>) => {
        state.loading = false;
        state.currentCourse = action.payload;
      })
      .addCase(fetchCourseById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || 'Failed to fetch course';
      })
      // Create
      .addCase(createCourse.fulfilled, (state, action: PayloadAction<Course>) => {
        state.courses.push(action.payload);
        if (!state.currentCourse) {
          state.currentCourse = action.payload;
        }
      })
      // Update
      .addCase(updateCourse.fulfilled, (state, action: PayloadAction<Course>) => {
        const index = state.courses.findIndex(c => c.id === action.payload.id);
        if (index !== -1) {
          state.courses[index] = action.payload;
        }
        if (state.currentCourse?.id === action.payload.id) {
          state.currentCourse = action.payload;
        }
      })
      // Delete
      .addCase(deleteCourse.fulfilled, (state, action: PayloadAction<string>) => {
        state.courses = state.courses.filter(c => c.id !== action.payload);
        if (state.currentCourse?.id === action.payload) {
          state.currentCourse = state.courses.length > 0 ? state.courses[0] : null;
        }
      });
  }
});

export const { setCourse, clearCourseError } = courseSlice.actions;
export default courseSlice.reducer;
