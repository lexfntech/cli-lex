import { configureStore } from '@reduxjs/toolkit';
import courseReducer from './courseSlice';
import influencerReducer from './influencerSlice';
import registrationReducer from './registrationSlice';

export const store = configureStore({
  reducer: {
    course: courseReducer,
    influencer: influencerReducer,
    registration: registrationReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
