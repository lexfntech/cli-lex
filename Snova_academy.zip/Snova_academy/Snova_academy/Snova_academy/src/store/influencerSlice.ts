import { createSlice, createAsyncThunk, type PayloadAction } from '@reduxjs/toolkit';
import { auth } from '../firebase';

export interface Influencer {
  id: string;
  firebaseUid: string;
  name: string;
  email: string;
  phone: string;
  username: string;
  role: string;
  referralCode: string;
  referralLink: string;
  status: 'active' | 'inactive' | 'deleted';
  totalLeads: number;
  confirmedLeads: number;
  revenueGenerated: number;
  createdAt: string;
  updatedAt: string;
}

export interface InfluencerAnalytics {
  totalInfluencers: number;
  totalLeads: number;
  confirmedLeads: number;
  totalRevenue: number;
  topInfluencers: Influencer[];
}

interface InfluencerState {
  influencers: Influencer[];
  analytics: InfluencerAnalytics | null;
  loading: boolean;
  error: string | null;
  selectedInfluencer: Influencer | null;
}

const initialState: InfluencerState = {
  influencers: [],
  analytics: null,
  loading: false,
  error: null,
  selectedInfluencer: null,
};

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';

// Helper function to get auth token
const getAuthToken = async () => {
  const user = auth.currentUser;
  if (!user) throw new Error('Not authenticated');
  return await user.getIdToken();
};

// Async thunks
export const fetchInfluencers = createAsyncThunk(
  'influencer/fetchAll',
  async (filters: { status?: string; sortBy?: string } = {}) => {
    const token = await getAuthToken();
    const params = new URLSearchParams(filters as any);
    const response = await fetch(`${API_URL}/api/influencers?${params}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to fetch influencers');
    const data = await response.json();
    return data.data;
  }
);

export const fetchInfluencerById = createAsyncThunk(
  'influencer/fetchById',
  async (id: string) => {
    const token = await getAuthToken();
    const response = await fetch(`${API_URL}/api/influencers/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to fetch influencer');
    const data = await response.json();
    return data.data;
  }
);

export const createInfluencer = createAsyncThunk(
  'influencer/create',
  async (payload: {
    name: string;
    email: string;
    phone: string;
    username: string;
    password: string;
    status?: string;
  }) => {
    const token = await getAuthToken();
    const response = await fetch(`${API_URL}/api/influencers`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to create influencer');
    }
    const data = await response.json();
    return data.data;
  }
);

export const updateInfluencer = createAsyncThunk(
  'influencer/update',
  async ({ id, updates }: { id: string; updates: Partial<Influencer> }) => {
    const token = await getAuthToken();
    const response = await fetch(`${API_URL}/api/influencers/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(updates),
    });
    if (!response.ok) throw new Error('Failed to update influencer');
    const data = await response.json();
    return data.data;
  }
);

export const updateInfluencerStatus = createAsyncThunk(
  'influencer/updateStatus',
  async ({ id, status }: { id: string; status: 'active' | 'inactive' }) => {
    const token = await getAuthToken();
    const response = await fetch(`${API_URL}/api/influencers/${id}/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ status }),
    });
    if (!response.ok) throw new Error('Failed to update status');
    const data = await response.json();
    return data.data;
  }
);

export const deleteInfluencer = createAsyncThunk(
  'influencer/delete',
  async (id: string) => {
    const token = await getAuthToken();
    const response = await fetch(`${API_URL}/api/influencers/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to delete influencer');
    return id;
  }
);

export const fetchAnalytics = createAsyncThunk(
  'influencer/fetchAnalytics',
  async () => {
    const token = await getAuthToken();
    const response = await fetch(`${API_URL}/api/influencers/analytics`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('Failed to fetch analytics');
    const data = await response.json();
    return data.data;
  }
);

// Slice
const influencerSlice = createSlice({
  name: 'influencer',
  initialState,
  reducers: {
    setSelectedInfluencer: (state, action: PayloadAction<Influencer | null>) => {
      state.selectedInfluencer = action.payload;
    },
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch all
      .addCase(fetchInfluencers.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchInfluencers.fulfilled, (state, action) => {
        state.loading = false;
        state.influencers = action.payload;
      })
      .addCase(fetchInfluencers.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || 'Failed to fetch influencers';
      })
      // Fetch by ID
      .addCase(fetchInfluencerById.fulfilled, (state, action) => {
        state.selectedInfluencer = action.payload;
      })
      // Create
      .addCase(createInfluencer.fulfilled, (state, action) => {
        state.influencers.unshift(action.payload);
      })
      // Update
      .addCase(updateInfluencer.fulfilled, (state, action) => {
        const index = state.influencers.findIndex((i) => i.id === action.payload.id);
        if (index !== -1) {
          state.influencers[index] = action.payload;
        }
        if (state.selectedInfluencer?.id === action.payload.id) {
          state.selectedInfluencer = action.payload;
        }
      })
      // Update status
      .addCase(updateInfluencerStatus.fulfilled, (state, action) => {
        const index = state.influencers.findIndex((i) => i.id === action.payload.id);
        if (index !== -1) {
          state.influencers[index] = action.payload;
        }
      })
      // Delete
      .addCase(deleteInfluencer.fulfilled, (state, action) => {
        state.influencers = state.influencers.filter((i) => i.id !== action.payload);
      })
      // Analytics
      .addCase(fetchAnalytics.fulfilled, (state, action) => {
        state.analytics = action.payload;
      });
  },
});

export const { setSelectedInfluencer, clearError } = influencerSlice.actions;
export default influencerSlice.reducer;
