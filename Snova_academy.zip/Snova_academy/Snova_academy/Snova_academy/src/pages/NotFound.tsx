import { Link } from 'react-router-dom';

const NotFound = () => {
  return (
    <div className="min-h-screen bg-[var(--color-primary-bg)] flex flex-col items-center justify-center p-6 text-center text-white">
      <h1 className="text-8xl font-bold font-sans text-brand-blue-alt glow-shadow">404</h1>
      <p className="text-2xl mt-4 text-text-secondary">System Not Found.</p>
      <Link 
        to="/" 
        className="mt-8 px-6 py-3 bg-[var(--color-secondary-bg)] border border-[var(--color-text-secondary)] rounded-md text-sm uppercase tracking-widest hover:bg-[#1a2538] transition-colors"
      >
        Return to Base
      </Link>
    </div>
  );
};

export default NotFound;
