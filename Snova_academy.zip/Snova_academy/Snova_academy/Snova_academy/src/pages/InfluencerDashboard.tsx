import { useEffect, useState } from "react";
import { FiCheckCircle, FiCopy, FiTrendingUp, FiUsers, FiXCircle } from "react-icons/fi";

export default function App() {
    const [copied, setCopied] = useState(false);

    useEffect(() => {
        document.documentElement.removeAttribute("data-theme");
    }, []);

    const referralCode = "NANDZ01";
    const referralLink = `http://localhost:5173/?ref=${referralCode}`;

    const copyLink = async () => {
        await navigator.clipboard.writeText(referralLink);
        setCopied(true);

        setTimeout(() => {
            setCopied(false);
        }, 2000);
    };

    return (
        <div className="theme-root min-h-screen p-8 text-[var(--text-primary)]">
            <div className="hud-grid" />

            <div className="relative z-10 mx-auto max-w-7xl">
                <div className="mb-12">
                    <p className="text-xs uppercase tracking-[0.2em] text-[#D6A15D] font-bold">Influencer Portal</p>

                    <h1 className="mt-2 text-5xl font-black tracking-tight md:text-6xl">Dashboard</h1>

                    <p className="mt-3 text-[var(--text-secondary)]">Track your referrals, conversions and revenue.</p>
                </div>

                <div className="bezel-outer mb-10">
                    <div className="bezel-inner p-8">
                        <h2 className="mb-6 text-2xl font-bold">Referral Link</h2>

                        <div className="flex flex-col gap-4 md:flex-row">
                            <input
                                readOnly
                                value={referralLink}
                                className="flex-1 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-primary)] px-4 py-3 text-[var(--text-primary)] outline-none"
                            />

                            <button
                                onClick={copyLink}
                                className="magnetic-btn px-6 py-3 rounded-xl bg-[#B8793B] hover:bg-[#D6A15D] text-white font-bold transition-all duration-300"
                            >
                                <div className="flex items-center gap-2">
                                    <FiCopy />
                                    {copied ? "Copied!" : "Copy"}
                                </div>
                            </button>
                        </div>

                        <div className="mt-5">
                            <span className="text-[var(--text-secondary)]">Referral Code :</span>

                            <span className="ml-2 text-lg font-bold text-[#D6A15D]">{referralCode}</span>
                        </div>
                    </div>
                </div>

                <div className="mb-10 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
                    <div className="bezel-outer">
                        <div className="bezel-inner p-6">
                            <FiUsers size={34} className="text-[#D6A15D] mb-4" />

                            <h3 className="text-sm text-[var(--text-secondary)]">Total Leads</h3>

                            <p className="text-4xl font-black">24</p>
                        </div>
                    </div>

                    <div className="bezel-outer">
                        <div className="bezel-inner p-6">
                            <FiCheckCircle size={34} className="text-[#7EE787] mb-4" />

                            <h3 className="text-sm text-[var(--text-secondary)]">Confirmed</h3>

                            <p className="text-4xl font-black">16</p>
                        </div>
                    </div>

                    <div className="bezel-outer">
                        <div className="bezel-inner p-6">
                            <FiXCircle size={34} className="text-[#FF7B72] mb-4" />

                            <h3 className="text-sm text-[var(--text-secondary)]">Cancelled</h3>

                            <p className="text-4xl font-black">3</p>
                        </div>
                    </div>

                    <div className="bezel-outer">
                        <div className="bezel-inner p-6">
                            <FiTrendingUp size={34} className="text-[#D6A15D] mb-4" />

                            <h3 className="text-sm text-[var(--text-secondary)]">Revenue</h3>

                            <p className="text-4xl font-black">Rs 1.24L</p>
                        </div>
                    </div>
                </div>

                <div className="bezel-outer">
                    <div className="bezel-inner p-8">
                        <h2 className="mb-6 text-2xl font-bold">Referral Students</h2>

                        <div className="overflow-x-auto">
                            <table className="w-full text-left">
                                <thead className="border-b border-[var(--border-subtle)]">
                                    <tr>
                                        <th className="py-4">Student</th>
                                        <th>Course</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <tr className="border-b border-[var(--border-subtle)] hover:bg-white/[0.02]">
                                        <td className="py-5">Rahul</td>
                                        <td>Flutter Development</td>
                                        <td>
                                            <span className="px-3 py-1 rounded-full bg-[#3A2918] text-[#D6A15D] text-sm font-semibold">Pending</span>
                                        </td>
                                    </tr>

                                    <tr className="border-b border-[var(--border-subtle)] hover:bg-white/[0.02]">
                                        <td className="py-5">Priya</td>
                                        <td>React Masterclass</td>
                                        <td>
                                            <span className="px-3 py-1 rounded-full bg-[#1B2D1F] text-[#7EE787] text-sm font-semibold">Confirmed</span>
                                        </td>
                                    </tr>

                                    <tr className="hover:bg-white/[0.02]">
                                        <td className="py-5">Arun</td>
                                        <td>Cyber Security Basics</td>
                                        <td>
                                            <span className="px-3 py-1 rounded-full bg-[#3A1B1B] text-[#FF7B72] text-sm font-semibold">Cancelled</span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}