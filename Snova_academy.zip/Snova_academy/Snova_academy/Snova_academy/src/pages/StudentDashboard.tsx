import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth } from '../firebase';
import { signOut } from 'firebase/auth';
import {
  FiArrowLeft,
  FiClock,
  FiCheckCircle,
  FiXCircle,
  FiPlay,
  FiLogOut
} from 'react-icons/fi';
import gsap from 'gsap';
import { useDispatch, useSelector } from 'react-redux';
import type { AppDispatch, RootState } from '../store';
import { fetchCourses } from '../store/courseSlice';

const UserDashboard = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch<AppDispatch>();

  const [registrations, setRegistrations] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'my-courses' | 'requests'>('my-courses');

  const user = auth.currentUser;
  const course = useSelector((state: RootState) => state.course.currentCourse);

  // 🔥 FETCH DATA
  useEffect(() => {
    dispatch(fetchCourses());

    fetch("http://localhost:5000/api/registrations")
      .then(res => res.json())
      .then(data => setRegistrations(data))
      .catch(err => console.log(err));

  }, [dispatch]);

  // ✅ FILTER DATA
  const activeCourses = registrations.filter(
    reg => reg.status === 'confirmed'
  );

  const requestedCourses = registrations.filter(
    reg => reg.status === 'pending' || reg.status === 'cancelled'
  );

  // 🚀 ENTER LAB
  const handleEnterLab = () => {
    if (course?.modules && course.modules.length > 0) {
      for (const mod of course.modules) {
        const completed = localStorage.getItem(`module_${mod.id}`);
        if (!completed) {
          navigate(`/curriculum/${mod.id}`);
          return;
        }
      }
      navigate(`/curriculum/${course.modules[course.modules.length - 1].id}`);
      return;
    }

    navigate('/curriculum/mod_1');
  };

  // 🔐 LOGOUT
  const handleSignOut = async () => {
    try {
      await signOut(auth);
      navigate('/');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  // 🎬 ANIMATION
  useEffect(() => {
    gsap.fromTo(
      '.dashboard-item',
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, stagger: 0.1, duration: 0.6, ease: 'power2.out' }
    );
  }, [activeTab]);

  // 🎯 STATUS BADGE
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'confirmed':
        return (
          <span className="px-3 py-1 bg-green-500/10 text-green-400 border rounded-full text-xs flex items-center gap-1">
            <FiCheckCircle /> Approved
          </span>
        );
      case 'pending':
        return (
          <span className="px-3 py-1 bg-yellow-500/10 text-yellow-400 border rounded-full text-xs flex items-center gap-1">
            <FiClock /> Pending Review
          </span>
        );
      case 'cancelled':
        return (
          <span className="px-3 py-1 bg-red-500/10 text-red-400 border rounded-full text-xs flex items-center gap-1">
            <FiXCircle /> Rejected
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[var(--bg-primary)] text-[var(--text-primary)] font-sans relative overflow-hidden">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[var(--color-brand-blue)]/5 rounded-full blur-[120px] pointer-events-none"></div>

      {/* Nav */}
      <nav className="border-b border-[var(--glass-border)] bg-[var(--glass-bg)] px-8 py-4 flex justify-between items-center relative z-10">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/')}
            className="w-8 h-8 flex items-center justify-center rounded border border-[var(--glass-border)] hover:border-[var(--color-brand-blue)] hover:text-[var(--color-brand-blue)] transition-colors"
          >
            <FiArrowLeft />
          </button>
          <span className="text-xl font-bold font-mono text-[var(--text-primary)] tracking-tight">
            Operator Dashboard
          </span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-3 text-sm text-[var(--text-secondary)] bg-[var(--bg-secondary)] px-4 py-2 rounded border border-[var(--glass-border)]">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            {user?.email || 'Authenticated'}
          </div>
          <button
            onClick={handleSignOut}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-[var(--text-secondary)] hover:text-red-400 bg-[var(--bg-secondary)] border border-[var(--glass-border)] hover:border-red-400/30 rounded transition-all"
          >
            <FiLogOut />
            Sign Out
          </button>
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-6 py-12 relative z-10">
        <h1 className="text-3xl font-bold mb-8">Curriculum Access</h1>

        {/* Debug banner — course load status */}
        {course ? (
          <div className="mb-6 px-4 py-3 bg-green-500/10 border border-green-500/20 rounded-lg text-green-400 text-sm font-mono">
            ✅ Course: <strong>{course.title}</strong> — {course.modules?.length || 0} modules loaded.
          </div>
        ) : (
          <div className="mb-6 px-4 py-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg text-yellow-400 text-sm font-mono">
            ⚠️ Backend not connected — Enter Lab will use fallback module ID. Start your backend server to enable full progress tracking.
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b border-[var(--glass-border)] pb-px">
          <button
            onClick={() => setActiveTab('my-courses')}
            className={`pb-4 px-2 text-sm font-medium tracking-wide transition-colors relative ${activeTab === 'my-courses'
              ? 'text-[var(--color-brand-blue)]'
              : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
          >
            My Courses ({activeCourses.length})
            {activeTab === 'my-courses' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[var(--color-brand-blue)] shadow-[0_0_8px_var(--color-brand-blue)]"></div>
            )}
          </button>
          <button
            onClick={() => setActiveTab('requests')}
            className={`pb-4 px-2 text-sm font-medium tracking-wide transition-colors relative ${activeTab === 'requests'
              ? 'text-[var(--color-brand-blue)]'
              : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
          >
            Access Requests ({requestedCourses.length})
            {activeTab === 'requests' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[var(--color-brand-blue)] shadow-[0_0_8px_var(--color-brand-blue)]"></div>
            )}
          </button>
        </div>

        {/* Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

          {activeTab === 'my-courses' && (
            activeCourses.length > 0
              ? activeCourses.map((reg) => (
                <div key={reg.id} className="dashboard-item bezel-outer w-full">
                  <div className="bezel-inner p-6 flex flex-col h-full bg-[var(--bg-secondary)]">
                    <div className="flex justify-between items-start mb-6">
                      <div>
                        <div className="text-[10px] font-mono tracking-widest text-[var(--color-icy-cyan)] uppercase mb-2">
                          Registration: {reg.id}
                        </div>
                        <h3 className="text-xl font-bold text-[var(--text-primary)]">
                          {reg.courseName}
                        </h3>
                      </div>
                      {getStatusBadge(reg.status)}
                    </div>

                    <button
                      onClick={handleEnterLab}
                      className="flex items-center gap-2 text-sm bg-[var(--color-brand-blue)] text-white px-4 py-2 rounded hover:bg-[var(--color-brand-blue-alt)] transition-colors w-fit"
                    >
                      <FiPlay className="w-4 h-4" />
                      Enter Lab
                    </button>
                  </div>
                </div>
              ))
              : (
                <div className="col-span-full py-12 text-center text-[var(--text-secondary)] border border-dashed border-[var(--glass-border)] rounded-lg">
                  No active courses found. Request access to start learning.
                </div>
              )
          )}

          {activeTab === 'requests' && (
            requestedCourses.length > 0
              ? requestedCourses.map((reg) => (
                <div key={reg.id} className="dashboard-item bezel-outer w-full">
                  <div className="bezel-inner p-6 flex flex-col h-full bg-[var(--bg-primary)]">
                    <div className="flex justify-between items-start mb-6">
                      <div>
                        <div className="text-[10px] font-mono tracking-widest text-[var(--text-secondary)] uppercase mb-2">
                          Request ID: {reg.id}
                        </div>
                        <h3 className="text-lg font-bold text-[var(--text-primary)]">
                          {reg.courseName}
                        </h3>
                      </div>
                      {getStatusBadge(reg.status)}
                    </div>
                    <div className="mt-auto pt-4 border-t border-[var(--glass-border)]">
                      <div className="grid grid-cols-2 gap-4 text-xs text-[var(--text-secondary)] mb-2">
                        <div>
                          <span className="block opacity-50 mb-1">Requested On</span>
                          <span className="font-mono">
                            {new Date(reg.registeredAt).toLocaleDateString()}
                          </span>
                        </div>
                        <div>
                          <span className="block opacity-50 mb-1">Override Key</span>
                          <span className="font-mono">{reg.couponUsed || 'N/A'}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))
              : (
                <div className="col-span-full py-12 text-center text-[var(--text-secondary)] border border-dashed border-[var(--glass-border)] rounded-lg">
                  No pending requests.
                </div>
              )
          )}

        </div>
      </main>
    </div>
  );
};

export default UserDashboard;