import { useEffect, useRef, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import type { AppDispatch, RootState } from '../store';
import gsap from 'gsap';
import { FiArrowLeft, FiCheckCircle, FiTool, FiTerminal, FiAward, FiArrowRight } from 'react-icons/fi';
import { fetchCourses } from '../store/courseSlice';

const ModuleDetails = () => {
  const { moduleId } = useParams<{ moduleId: string }>();
  const navigate = useNavigate();
  const dispatch = useDispatch<AppDispatch>();
  const course = useSelector((state: RootState) => state.course.currentCourse);
  const containerRef = useRef<HTMLDivElement>(null);
  const [videoCompleted, setVideoCompleted] = useState(false);

  const videoUrl = "https://www.youtube.com/embed/OYdLN46JjNI";

  useEffect(() => {
    if (!course) {
      dispatch(fetchCourses());
    }
  }, [course, dispatch]);

  const activeModule = course?.modules.find(m => m.id === moduleId);

  const currentIndex = course?.modules.findIndex(m => m.id === moduleId) ?? -1;
  const isLastModule = course ? currentIndex === course.modules.length - 1 : false;

  const handleComplete = () => {
    localStorage.setItem(`module_${moduleId}`, "completed");
    setVideoCompleted(true);
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    if (!containerRef.current) return;
    gsap.fromTo(
      '.reveal-el',
      { y: 50, opacity: 0, scale: 0.98 },
      { y: 0, opacity: 1, scale: 1, duration: 1, stagger: 0.15, ease: 'power4.out' }
    );
  }, []);

  return (
    <div ref={containerRef} className="min-h-[100dvh] bg-[var(--bg-primary)] text-[var(--text-primary)] font-sans pb-32 pt-32 relative overflow-hidden transition-colors duration-700">
      <div className="absolute top-0 right-0 w-[50vw] h-[50vw] bg-[var(--color-brand-blue)] rounded-full blur-[200px] opacity-[0.05] pointer-events-none mix-blend-screen transition-opacity duration-700"></div>

      <div className="max-w-6xl mx-auto px-6 relative z-10">

        {/* Back Navigation */}
        <div className="reveal-el mb-12 flex justify-between items-center">
          <button
            onClick={() => navigate(-1)}
            className="group flex items-center text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors uppercase text-xs tracking-widest font-bold"
          >
            <div className="w-8 h-8 rounded-full border border-[var(--glass-border)] flex items-center justify-center mr-4 group-hover:bg-[var(--glass-bg)] group-hover:border-[var(--color-brand-blue)] transition-all duration-300">
              <FiArrowLeft className="text-lg transform group-hover:-translate-x-1 transition-transform duration-300" />
            </div>
            Back to Curriculum
          </button>
        </div>

        {/* Hero Card */}
        <div className="reveal-el flowing-border-wrapper mb-16">
          <div className="bezel-inner p-10 md:p-16 relative overflow-hidden min-h-[40vh] flex flex-col justify-end">
            <div className="absolute top-0 right-0 p-16 opacity-5 pointer-events-none text-[var(--text-primary)]">
              <FiTerminal size={240} />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-[var(--bg-primary)]/40 to-transparent pointer-events-none"></div>
            <div className="relative z-10 max-w-3xl">
              <span className="text-[var(--color-icy-cyan)] font-mono text-sm tracking-[0.2em] uppercase mb-6 block font-bold">
                {activeModule ? activeModule.title.split('—')[0]?.trim() : moduleId}
              </span>
              <h1 className="text-4xl md:text-7xl font-black mb-8 tracking-tighter leading-[1.05]">
                {activeModule
                  ? (activeModule.title.split('—')[1]?.trim() || activeModule.title)
                  : 'Module'}
              </h1>
              <p className="text-lg md:text-xl text-[var(--text-secondary)] font-medium max-w-2xl leading-relaxed">
                {activeModule?.outcome || "Dive deep into the technical foundations and master the core concepts required for this phase of your journey."}
              </p>
            </div>
          </div>
        </div>

        {/* Video Section */}
        <div className="reveal-el bezel-outer mb-10">
          <div className="bezel-inner p-6">
            <h2 className="text-2xl font-bold mb-6">Course Video</h2>
            <div className="relative w-full rounded-xl overflow-hidden" style={{ paddingTop: '56.25%' }}>
              <iframe
                className="absolute inset-0 w-full h-full rounded-xl"
                src={videoUrl}
                title="Course Video"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
            <div className="mt-6 flex gap-4">
              <button
                onClick={handleComplete}
                className="px-6 py-3 bg-green-600 text-white rounded-lg hover:opacity-90 transition-opacity"
              >
                ✅ Mark As Completed
              </button>
              <button
                onClick={() => navigate('/dashboard')}
                className="px-6 py-3 bg-[var(--color-brand-blue)] text-white rounded-lg hover:opacity-90 transition-opacity"
              >
                Back To Dashboard
              </button>
            </div>
          </div>
        </div>

        {/* Completion Banner */}
        {videoCompleted && (
          <div className="reveal-el bezel-outer mb-10">
            <div className="bezel-inner p-8 text-center">
              {isLastModule ? (
                <>
                  <h2 className="text-3xl font-bold text-green-500 mb-4">
                    🎉 Course Completed!
                  </h2>
                  <p className="text-[var(--text-secondary)] mb-6">
                    Congratulations! You have completed the entire course.
                  </p>
                  <button
                    onClick={() => navigate('/dashboard')}
                    className="px-6 py-3 bg-[var(--color-brand-blue)] text-white rounded-lg hover:opacity-80 transition-opacity"
                  >
                    Back To Dashboard
                  </button>
                </>
              ) : (
                <>
                  <h2 className="text-3xl font-bold text-green-500 mb-4">
                    🎉 Module Completed Successfully
                  </h2>
                  <p className="text-[var(--text-secondary)] mb-6">
                    Great job! Next module is now unlocked.
                  </p>
                  <div className="flex gap-4 justify-center">
                    <button
                      onClick={() => {
                        if (course) {
                          navigate(`/curriculum/${course.modules[currentIndex + 1].id}`);
                        }
                      }}
                      className="px-6 py-3 bg-green-600 text-white rounded-lg hover:opacity-90 transition-opacity"
                    >
                      Next Module →
                    </button>
                    <button
                      onClick={() => navigate('/dashboard')}
                      className="px-6 py-3 bg-[var(--color-brand-blue)] text-white rounded-lg hover:opacity-80 transition-opacity"
                    >
                      Dashboard
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        )}

        {/* Details Grid — only if module loaded */}
        {activeModule && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 reveal-el">

            {/* Left Column: Lessons */}
            <div className="lg:col-span-8 space-y-8">
              <div className="bezel-outer h-full">
                <div className="bezel-inner h-full p-8 md:p-12">
                  <div className="flex items-center justify-between mb-10 border-b border-[var(--glass-border)] pb-6">
                    <h2 className="text-sm uppercase tracking-[0.2em] text-[var(--text-primary)] font-bold flex items-center">
                      <FiCheckCircle className="mr-3 text-xl text-[var(--color-icy-cyan)]" />
                      Curriculum Path
                    </h2>
                    <span className="text-[var(--text-secondary)] font-mono text-xs tracking-widest">{activeModule.lessons.length} Modules</span>
                  </div>

                  {activeModule.lessons.length > 0 && (
                    <ul className="space-y-4">
                      {activeModule.lessons.map((lesson, i) => (
                        <li key={i} className="group flex items-center bg-[var(--glass-bg)] p-5 rounded-2xl border border-[var(--glass-border)] hover:border-[var(--color-brand-blue)]/50 transition-all duration-300 hover:shadow-[0_10px_30px_-10px_rgba(0,168,255,0.1)] hover:-translate-y-1">
                          <div className="w-10 h-10 rounded-full bg-[var(--bg-primary)] border border-[var(--glass-border)] flex items-center justify-center text-[var(--color-brand-blue)] font-mono text-xs font-bold mr-6 group-hover:bg-[var(--color-brand-blue)] group-hover:text-white transition-colors duration-300">
                            {(i + 1).toString().padStart(2, '0')}
                          </div>
                          <span className="text-[var(--text-primary)] font-medium text-lg">{lesson}</span>
                          <FiArrowRight className="ml-auto text-[var(--text-secondary)] opacity-0 group-hover:opacity-100 transform -translate-x-4 group-hover:translate-x-0 transition-all duration-300" />
                        </li>
                      ))}
                    </ul>
                  )}

                  {activeModule.subModules && activeModule.subModules.length > 0 && (
                    <div className="space-y-8 mt-12">
                      {activeModule.subModules.map((sub, i) => (
                        <div key={i} className="bg-[var(--glass-bg)] p-8 rounded-3xl border border-[var(--glass-border)] relative overflow-hidden">
                          <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-[var(--color-brand-blue)] to-[var(--color-icy-cyan)]"></div>
                          <h3 className="text-xl font-bold mb-6 tracking-tight text-[var(--text-primary)]">{sub.title}</h3>
                          <ul className="space-y-4">
                            {sub.lessons.map((lesson, j) => (
                              <li key={j} className="flex items-start text-[var(--text-secondary)] font-medium group">
                                <span className="text-[var(--color-icy-cyan)] mr-4 mt-1 transform group-hover:scale-150 transition-transform duration-300">✦</span>
                                <span className="group-hover:text-[var(--text-primary)] transition-colors duration-300">{lesson}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Right Column */}
            <div className="lg:col-span-4 flex flex-col gap-8">

              {activeModule.practical && (
                <div className="bezel-outer flowing-border-wrapper group hover:-translate-y-1 transition-transform duration-500">
                  <div className="bezel-inner p-8">
                    <h2 className="text-xs uppercase tracking-[0.2em] text-[var(--text-primary)] mb-6 font-bold flex items-center">
                      <FiTerminal className="mr-3 text-lg text-[var(--color-brand-blue)]" />
                      Practical Execution
                    </h2>
                    <ul className="space-y-4">
                      {activeModule.practical.map((prac, i) => (
                        <li key={i} className="text-sm text-[var(--text-secondary)] flex items-start group-hover:text-[var(--text-primary)] transition-colors duration-300">
                          <span className="text-[var(--color-brand-blue)] mr-3 font-bold mt-0.5">›_</span> {prac}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {activeModule.tools && (
                <div className="bezel-outer">
                  <div className="bezel-inner p-8">
                    <h2 className="text-xs uppercase tracking-[0.2em] text-[var(--text-primary)] mb-6 font-bold flex items-center">
                      <FiTool className="mr-3 text-lg text-[var(--text-secondary)]" />
                      Tech Stack
                    </h2>
                    <div className="flex flex-wrap gap-3">
                      {activeModule.tools.map((tool, i) => (
                        <span key={i} className="px-4 py-2 bg-[var(--glass-bg)] text-[var(--text-primary)] rounded-full border border-[var(--glass-border)] text-xs font-mono font-bold tracking-wider hover:border-[var(--color-brand-blue)] hover:text-[var(--color-brand-blue)] transition-colors duration-300 cursor-default">
                          {tool}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeModule.outcome && (
                <div className="bezel-outer">
                  <div className="bezel-inner p-8 relative overflow-hidden group">
                    <div className="absolute inset-0 bg-[var(--color-brand-blue)]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
                    <h2 className="text-xs uppercase tracking-[0.2em] text-[var(--text-primary)] mb-6 font-bold flex items-center">
                      <FiAward className="mr-3 text-lg text-[var(--color-icy-cyan)]" />
                      Module Outcome
                    </h2>
                    <p className="text-[var(--text-secondary)] italic text-sm leading-relaxed group-hover:text-[var(--text-primary)] transition-colors duration-300">
                      "{activeModule.outcome}"
                    </p>
                  </div>
                </div>
              )}

            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default ModuleDetails;