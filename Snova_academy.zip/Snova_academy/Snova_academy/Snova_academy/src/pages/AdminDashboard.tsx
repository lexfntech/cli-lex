import { useState, useEffect } from 'react';
import { FiUsers, FiClipboard, FiLogOut, FiSearch, FiShield, FiCalendar, FiTrendingUp } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';
import { auth } from '../firebase';
import { signOut } from 'firebase/auth';
import InfluencerManagement from '../components/InfluencerManagement';
import RegistrationManagement from '../components/RegistrationManagement';

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  createdAt: string;
  status?: string;
}

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState<'registrations' | 'influencers' | 'users'>('registrations');
  const [searchQuery, setSearchQuery] = useState('');
  const [users, setUsers] = useState<User[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await signOut(auth);
      // Wait a moment for auth state to fully clear
      setTimeout(() => {
        navigate('/', { replace: true });
      }, 100);
    } catch (error) {
      console.error("Error signing out", error);
    }
  };

  // Fetch users when Users tab is active
  useEffect(() => {
    if (activeTab === 'users') {
      fetchUsers();
    }
  }, [activeTab]);

  const fetchUsers = async () => {
    setLoadingUsers(true);
    try {
      const user = auth.currentUser;
      if (!user) return;

      const token = await user.getIdToken();
      const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';
      
      const response = await fetch(`${API_URL}/api/auth/users`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!response.ok) throw new Error('Failed to fetch users');
      
      const data = await response.json();
      setUsers(data.data || []);
    } catch (error) {
      console.error('Error fetching users:', error);
      setUsers([]);
    } finally {
      setLoadingUsers(false);
    }
  };

  const filteredUsers = users.filter(u =>
    u.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-[100dvh] bg-[var(--bg-primary)] text-[var(--text-primary)] font-sans selection:bg-[var(--color-brand-blue)] selection:text-white flex flex-col md:flex-row">

      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 border-b md:border-b-0 md:border-r border-[var(--glass-border)] bg-[var(--bg-secondary)] p-6 flex flex-col">
        <div className="flex items-center gap-3 mb-12">
          <div className="w-8 h-8 rounded-md bg-[var(--color-brand-blue)]/20 flex items-center justify-center border border-[var(--color-brand-blue)]">
            <FiShield className="text-[var(--color-brand-blue)] text-sm" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-widest uppercase text-[var(--text-primary)]">Snova Admin</h1>
            <p className="text-[10px] font-mono text-[var(--text-secondary)] uppercase">Administration</p>
          </div>
        </div>

        <nav className="flex flex-col gap-2 flex-grow">
          <button
            onClick={() => setActiveTab('registrations')}
            className={`flex items-center gap-3 px-4 py-3 rounded-lg text-xs font-bold tracking-wider uppercase transition-all duration-300 ${activeTab === 'registrations' ? 'bg-[var(--color-brand-blue)]/10 text-[var(--color-brand-blue)] border border-[var(--color-brand-blue)]/30' : 'text-[var(--text-secondary)] hover:bg-[var(--glass-bg)] hover:text-[var(--text-primary)] border border-transparent'}`}
          >
            <FiClipboard className="text-lg" />
            Registrations
          </button>
          <button
            onClick={() => setActiveTab('influencers')}
            className={`flex items-center gap-3 px-4 py-3 rounded-lg text-xs font-bold tracking-wider uppercase transition-all duration-300 ${activeTab === 'influencers' ? 'bg-[var(--color-brand-blue)]/10 text-[var(--color-brand-blue)] border border-[var(--color-brand-blue)]/30' : 'text-[var(--text-secondary)] hover:bg-[var(--glass-bg)] hover:text-[var(--text-primary)] border border-transparent'}`}
          >
            <FiTrendingUp className="text-lg" />
            Influencers
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`flex items-center gap-3 px-4 py-3 rounded-lg text-xs font-bold tracking-wider uppercase transition-all duration-300 ${activeTab === 'users' ? 'bg-[var(--color-brand-blue)]/10 text-[var(--color-brand-blue)] border border-[var(--color-brand-blue)]/30' : 'text-[var(--text-secondary)] hover:bg-[var(--glass-bg)] hover:text-[var(--text-primary)] border border-transparent'}`}
          >
            <FiUsers className="text-lg" />
            Users
          </button>
        </nav>

        <div className="mt-auto pt-8 border-t border-[var(--glass-border)]">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-4 py-3 w-full rounded-lg text-xs font-bold tracking-wider uppercase text-[var(--text-secondary)] hover:bg-red-500/10 hover:text-red-400 transition-colors"
          >
            <FiLogOut className="text-lg" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-6 md:p-10 overflow-y-auto">
        {/* Tab Content: Registrations */}
        {activeTab === 'registrations' && <RegistrationManagement />}

        {/* Tab Content: Influencers */}
        {activeTab === 'influencers' && <InfluencerManagement />}

        {/* Tab Content: Users */}
        {/* Tab Content: Users */}
        {activeTab === 'users' && (
          <>
            <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
              <div>
                <h2 className="text-2xl md:text-3xl font-black tracking-tight mb-2">User Management</h2>
                <p className="text-[var(--text-secondary)] text-sm">
                  View and manage all registered users on the platform.
                </p>
              </div>

              <div className="relative w-full md:w-72">
                <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-secondary)]" />
                <input
                  type="text"
                  placeholder="Search users..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[var(--bg-secondary)] border border-[var(--glass-border)] rounded-full py-3 pl-11 pr-4 text-sm focus:outline-none focus:border-[var(--color-brand-blue)] focus:ring-1 focus:ring-[var(--color-brand-blue)] transition-all placeholder-[var(--text-secondary)] text-[var(--text-primary)]"
                />
              </div>
            </header>

            {loadingUsers ? (
              <div className="flex justify-center items-center py-12">
                <div className="w-8 h-8 border-4 border-[var(--color-brand-blue)] border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : (
              <div className="bezel-outer overflow-hidden">
            <div className="bezel-inner bg-[var(--bg-secondary)] overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[600px]">
                <thead>
                  <tr className="border-b border-[var(--glass-border)] bg-[var(--glass-bg)]">
                    <th className="p-4 text-[10px] font-mono uppercase tracking-widest text-[var(--text-secondary)]">User</th>
                    <th className="p-4 text-[10px] font-mono uppercase tracking-widest text-[var(--text-secondary)]">Email</th>
                    <th className="p-4 text-[10px] font-mono uppercase tracking-widest text-[var(--text-secondary)]">Role</th>
                    <th className="p-4 text-[10px] font-mono uppercase tracking-widest text-[var(--text-secondary)]">Joined Date</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.length > 0 ? filteredUsers.map((user) => (
                    <tr key={user.id} className="border-b border-[var(--glass-border)] hover:bg-[var(--glass-bg)] transition-colors">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-[var(--glass-bg)] border border-[var(--glass-border)] flex items-center justify-center">
                            <span className="font-bold text-xs text-[var(--text-primary)]">{user.name.charAt(0)}</span>
                          </div>
                          <span className="font-bold text-sm text-[var(--text-primary)]">{user.name}</span>
                        </div>
                      </td>
                      <td className="p-4 text-sm text-[var(--text-secondary)]">{user.email}</td>
                      <td className="p-4">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-bold tracking-widest uppercase ${user.role === 'admin'
                            ? 'bg-[var(--color-brand-blue)]/20 text-[var(--color-brand-blue)] border border-[var(--color-brand-blue)]/30'
                            : 'bg-[var(--glass-bg)] text-[var(--text-secondary)] border border-[var(--glass-border)]'
                          }`}>
                          {user.role}
                        </span>
                      </td>
                      <td className="p-4 text-sm text-[var(--text-secondary)] flex items-center gap-2">
                        <FiCalendar className="text-[var(--color-icy-cyan)]" />
                        {user.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A'}
                      </td>
                    </tr>
                  )) : (
                    <tr>
                      <td colSpan={4} className="p-8 text-center text-[var(--text-secondary)] text-sm">No users found.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
            )}
          </>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;
