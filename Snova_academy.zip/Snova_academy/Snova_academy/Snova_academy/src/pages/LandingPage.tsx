import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import type { AppDispatch, RootState } from '../store';
import { auth } from '../firebase';
import { onAuthStateChanged, signOut, type User } from 'firebase/auth';
import RegistrationModal from '../components/RegistrationModal';
import CourseRegistrationModal from '../components/CourseRegistrationModal';
import Antigravity from '../../@/components/Antigravity';
import { FiArrowRight, FiArrowUpRight, FiTerminal } from 'react-icons/fi';
import gsap from 'gsap';
import ScrollTrigger from 'gsap/ScrollTrigger';
import { fetchCourses } from '../store/courseSlice';

gsap.registerPlugin(ScrollTrigger);

const LandingPage = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCourseRegistrationOpen, setIsCourseRegistrationOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null);
  const heroRef = useRef<HTMLDivElement>(null);
  const modulesRef = useRef<HTMLDivElement>(null);

  const dispatch = useDispatch<AppDispatch>();
  const course = useSelector((state: RootState) => state.course.currentCourse);
  const navigate = useNavigate();

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', 'light');
    dispatch(fetchCourses());
  }, [dispatch]);


  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);

      if (currentUser) {
        try {
          // Get user profile from Firestore to check role
          const token = await currentUser.getIdToken();
          const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
          const response = await fetch(`${apiUrl}/api/auth/profile`, {
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });

          if (response.ok) {
            const data = await response.json();
            const userProfile = data.data;

            console.log("User Profile:", userProfile);

            if (userProfile.role === "admin") {
              navigate("/management-dashboard-x92f-snova");
            } else if (userProfile.role === "student") {
              navigate("/dashboard");
            } else if (userProfile.role === "influencer") {
              navigate("/influencer-dashboard");
            }
          }
          else if (response.status === 404) {
            // User doesn't exist in Firestore - show registration modal
            setIsModalOpen(true);
          }
        } catch (error) {
          console.error('Error checking user profile:', error);
        }
      }
    });
    return () => unsubscribe();
  }, [navigate]);


  const handleModuleClick = (moduleId: string) => {
    if (auth.currentUser) {
      navigate(`/curriculum/${moduleId}`);
    } else {
      setIsModalOpen(true);
    }
  };

  // Hero Animation (Runs on mount)
  useEffect(() => {
    if (heroRef.current) {
      gsap.fromTo(heroRef.current.children,
        { opacity: 0, y: 40, filter: 'blur(10px)' },
        { opacity: 1, y: 0, filter: 'blur(0px)', duration: 1.2, stagger: 0.15, ease: "power4.out" }
      );
    }
  }, []);

  // Modules Animation (Runs when course is loaded)
  useEffect(() => {
    if (course && modulesRef.current) {
      gsap.fromTo(modulesRef.current.children,
        { opacity: 0, y: 60, scale: 0.95 },
        {
          opacity: 1,
          y: 0,
          scale: 1,
          stagger: 0.1,
          duration: 1.2,
          ease: "expo.out",
          scrollTrigger: {
            trigger: modulesRef.current,
            start: "top 85%",
          }
        }
      );
    }
  }, [course]);

  return (
    <div className="min-h-[100dvh] bg-[var(--bg-primary)] text-[var(--text-primary)] overflow-x-hidden font-sans transition-colors duration-700 relative">

      {/* The Fluid Island Nav */}
      <nav className="fixed top-6 left-1/2 -translate-x-1/2 z-50 bezel-inner border border-[var(--glass-border)] px-6 py-3 flex justify-between items-center w-[95%] max-w-5xl transition-all duration-700 hover:shadow-[0_20px_40px_var(--glass-shadow)] hover:scale-[1.01]">
        <div className="flex items-center gap-4 group cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <div className="w-8 h-8 rounded-full border border-[var(--glass-border)] flex items-center justify-center bg-[var(--glass-bg)] group-hover:bg-[var(--color-brand-blue)] transition-colors duration-500">
            <span className="text-[var(--color-brand-blue-alt)] group-hover:text-white font-bold font-mono text-sm transition-colors duration-500">S</span>
          </div>
          <span className="text-lg font-bold tracking-widest uppercase group-hover:text-[var(--color-brand-blue)] transition-colors duration-500">Snova Lab</span>
        </div>

        <div className="flex items-center gap-6">

          {user ? (
            <div className="flex items-center gap-3">
              <button
                onClick={async () => {
                  if (!user) return;

                  const token = await user.getIdToken();
                  const apiUrl = import.meta.env.VITE_API_URL || "http://localhost:3001";

                  const response = await fetch(`${apiUrl}/api/auth/profile`, {
                    headers: {
                      Authorization: `Bearer ${token}`,
                    },
                  });

                  if (response.ok) {
                    const data = await response.json();

                    if (data.data?.role === "admin") {
                      navigate("/management-dashboard-x92f-snova");
                    } else if (data.data?.role === "influencer") {
                      navigate("/influencer-dashboard");
                    } else {
                      navigate("/dashboard");
                    }
                  } else {
                    navigate("/dashboard");
                  }
                }}
                className="group px-6 py-2 rounded-full border border-[var(--color-brand-blue)]/30 text-[var(--color-brand-blue)] text-xs font-bold tracking-[0.1em] uppercase flex items-center gap-2 hover:bg-[var(--color-brand-blue)] hover:text-white transition-all duration-500"
              >
                Dashboard
              </button>
              <button
                onClick={async () => {
                  await signOut(auth);
                  navigate('/');
                }}
                className="group px-4 py-2 rounded-full border border-red-500/30 text-red-500 text-xs font-bold tracking-[0.1em] uppercase flex items-center gap-2 hover:bg-red-500 hover:text-white transition-all duration-500 "
              >
                Sign Out
              </button>
            </div>
          ) : (
            <button
              onClick={() => setIsModalOpen(true)}
              className="group px-6 py-2 rounded-full bg-[var(--text-primary)] text-[var(--bg-primary)] text-xs font-bold tracking-[0.1em] uppercase flex items-center gap-2 hover:bg-[var(--color-brand-blue)] hover:text-white transition-all duration-500 hover:scale-105 active:scale-95"
            >
              Access
              <div className="w-5 h-5 rounded-full bg-[var(--bg-primary)]/10 flex items-center justify-center group-hover:bg-white/20 transition-colors">
                <FiArrowRight className="text-sm transform group-hover:translate-x-[2px] transition-transform duration-300" />
              </div>
            </button>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-48 pb-40 px-6 flex flex-col items-center text-center relative overflow-hidden" ref={heroRef}>
        {/* Antigravity Background */}
        <div className="absolute inset-0 w-full h-full z-0 pointer-events-none opacity-40">
          <Antigravity
            count={140}
            magnetRadius={1}
            ringRadius={30}
            waveSpeed={0.4}
            waveAmplitude={5}
            particleSize={2}
            lerpSpeed={0.01}
            color="black"
            autoAnimate
            particleVariance={1}
            rotationSpeed={0.2}
            depthFactor={0}
            pulseSpeed={3}
            particleShape="capsule"
            fieldStrength={0}
          />
        </div>

        {/* Ambient background glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60vw] h-[60vh] bg-[var(--color-brand-blue)]/5 rounded-full blur-[150px] pointer-events-none mix-blend-screen z-0"></div>

        <h1 className="relative z-10 text-5xl md:text-8xl font-black mb-10 max-w-6xl leading-[0.95] tracking-tighter">
          Master Cyber Security.<br />
          <span className="text-transparent bg-clip-text bg-gradient-to-br from-[var(--color-icy-cyan-light)] via-[var(--color-icy-cyan)] to-[var(--color-brand-blue)]">
            Zero Friction.
          </span>
        </h1>

        <p className="relative z-10 text-lg md:text-2xl text-[var(--text-secondary)] max-w-2xl mb-16 font-medium tracking-tight">
          An elite, high-performance platform engineered to take you from basics to professional bug bounty hunter. No upfront payments. Just raw technical execution.
        </p>

        <div className="relative z-10 flex flex-col sm:flex-row items-center gap-6">
          <button
            onClick={() => setIsModalOpen(true)}
            className="magnetic-btn group relative px-8 py-4 rounded-full bg-[var(--text-primary)] text-[var(--bg-primary)] font-bold text-sm tracking-widest uppercase overflow-hidden shadow-[0_0_40px_rgba(112,208,255,0.1)] hover:shadow-[0_0_60px_rgba(112,208,255,0.2)]"
          >
            <span className="relative z-10 flex items-center gap-3">
              Start Hacking Now
              <div className="w-6 h-6 rounded-full bg-[var(--bg-primary)]/10 flex items-center justify-center group-hover:bg-white/20 transition-colors duration-300">
                <FiTerminal className="text-sm" />
              </div>
            </span>
          </button>

          <button
            onClick={() => {
              document.getElementById('curriculum')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="magnetic-btn px-8 py-4 rounded-full font-bold text-xs tracking-widest uppercase text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors border border-[var(--glass-border)] bg-transparent hover:bg-[var(--glass-bg)]"
          >
            Explore Curriculum
          </button>
        </div>
      </section>

      {/* Programs Section */}
      <section id="programs" className="py-32 px-6 max-w-7xl mx-auto relative z-10">
        <div className="flex flex-col items-center text-center mb-20">
          <div className="text-[10px] font-mono tracking-[0.2em] uppercase text-[var(--color-icy-cyan)] mb-4">The Pathway</div>
          <h2 className="text-4xl md:text-6xl font-black tracking-tighter hover:text-[var(--color-brand-blue)] transition-colors duration-500 cursor-default">Available Programs</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Active Course */}
          <div
            id="active-course-card"
            className={`bezel-outer group transition-all duration-[600ms] ${selectedCourse === 'course_1' ? 'ring-1 ring-[var(--color-brand-blue)] shadow-[0_0_40px_rgba(0,168,255,0.15)] col-span-1 md:col-span-2' : 'hover:-translate-y-2 hover:shadow-[0_30px_60px_-15px_rgba(0,168,255,0.2)] col-span-1'}`}
          >
            <div className="bezel-inner h-full p-10 flex flex-col justify-between relative bg-[var(--bg-secondary)] overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-brand-blue)]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none mix-blend-screen"></div>

              <div
                className="cursor-pointer"
                onClick={() => {
                  setSelectedCourse(prev => prev === 'course_1' ? null : 'course_1');
                  if (selectedCourse !== 'course_1') {
                    setTimeout(() => document.getElementById('active-course-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
                  }
                }}
              >
                <div className="text-[var(--color-icy-cyan)] text-xs font-mono font-bold tracking-[0.15em] mb-4 uppercase">
                  Flagship
                </div>
                <h3 className="text-4xl font-bold leading-[1.1] tracking-tight text-[var(--text-primary)] group-hover:text-[var(--color-brand-blue)] transition-colors duration-500 mb-4">
                  Cyber Security Mastery
                </h3>
                <p className="text-[var(--text-secondary)] text-sm md:text-base max-w-md">
                  From basic networking protocols to advanced active directory exploitation. A complete 12-module journey.
                </p>

                <div className="mt-8 flex justify-between items-center border-t border-[var(--glass-border)] pt-6">
                  <div className="flex items-center gap-4">
                    <span className="text-xs font-bold tracking-widest uppercase text-[var(--text-secondary)] group-hover:text-[var(--color-icy-cyan)] transition-colors duration-500">
                      {selectedCourse === 'course_1' ? 'Close Curriculum' : 'View Curriculum'}
                    </span>
                    {user && selectedCourse === 'course_1' && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setIsCourseRegistrationOpen(true);
                        }}
                        className="px-4 py-2 border border-[var(--color-brand-blue)] text-[var(--color-brand-blue)] text-[10px] font-bold uppercase tracking-widest rounded-full hover:bg-[var(--color-brand-blue)] hover:text-white transition-all duration-300"
                      >
                        Register Course
                      </button>
                    )}
                  </div>
                  <div className="w-10 h-10 rounded-full border border-[var(--glass-border)] flex items-center justify-center overflow-hidden bg-[var(--glass-bg)] relative group-hover:border-[var(--color-brand-blue)] transition-colors duration-500">
                    <FiArrowRight className={`text-xl text-[var(--text-primary)] transition-transform duration-500 ${selectedCourse === 'course_1' ? 'rotate-90 text-[var(--color-brand-blue)]' : ''}`} />
                  </div>
                </div>
              </div>

              {/* Modules List Inside the Card */}
              <div className={`transition-all duration-700 ease-[cubic-bezier(0.32,0.72,0,1)] ${selectedCourse === 'course_1' ? 'max-h-[2500px] opacity-100 mt-10' : 'max-h-0 opacity-0 overflow-hidden mt-0'}`}>
                {course ? (
                  <div className="relative border-t border-[var(--glass-border)] pt-10">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 relative z-10" ref={modulesRef}>
                      {course.modules.map((mod) => {
                        const [modLabel, modTitle] = mod.title.split('—');
                        return (
                          <div
                            key={mod.id}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleModuleClick(mod.id);
                            }}
                            className="group/mod p-6 border border-[var(--glass-border)] bg-[var(--glass-bg)] hover:bg-[var(--glass-bg-hover)] transition-all duration-300 cursor-pointer flex flex-col justify-between rounded-sm"
                          >
                            <div>
                              <div className="text-[var(--text-secondary)] text-[10px] font-mono tracking-widest mb-2 uppercase">
                                {modLabel.trim()}
                              </div>
                              <h4 className="text-lg font-bold text-[var(--text-primary)] group-hover/mod:text-[var(--color-brand-blue)] transition-colors">
                                {modTitle ? modTitle.trim() : mod.title}
                              </h4>
                            </div>
                            <div className="mt-4 flex justify-end">
                              <FiArrowUpRight className="text-lg text-[var(--text-secondary)] group-hover/mod:text-[var(--color-brand-blue)] transform group-hover/mod:translate-x-1 group-hover/mod:-translate-y-1 transition-all" />
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Scroll Lock Overlay inside the card */}
                    {!user && (
                      <div className="absolute bottom-0 left-0 right-0 h-[400px] bg-gradient-to-t from-[var(--bg-secondary)] via-[var(--bg-secondary)]/90 to-transparent z-20 flex items-end justify-center pb-10 pointer-events-none">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setIsModalOpen(true);
                          }}
                          className="pointer-events-auto magnetic-btn group relative px-8 py-4 rounded-full bg-[var(--text-primary)] text-[var(--bg-primary)] font-bold text-xs tracking-widest uppercase overflow-hidden hover:scale-105 transition-all duration-300 shadow-[0_0_30px_rgba(255,255,255,0.1)] hover:shadow-[0_0_50px_rgba(255,255,255,0.2)]"
                        >
                          <span className="relative z-10 flex items-center gap-3">
                            Login to Unlock Full Curriculum
                            <FiTerminal className="text-base" />
                          </span>
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-[var(--text-secondary)] font-mono text-sm tracking-widest uppercase text-center py-10">Initializing modules...</div>
                )}
              </div>
            </div>
          </div>

          {/* Coming Soon Course */}
          <div className="bezel-outer opacity-60 hover:opacity-100 transition-opacity duration-500 col-span-1">
            <div className="bezel-inner h-full p-10 flex flex-col justify-between relative bg-[var(--bg-secondary)] grayscale hover:grayscale-0 transition-all duration-500">
              <div>
                <div className="text-[var(--text-secondary)] text-xs font-mono font-bold tracking-[0.15em] mb-4 uppercase">
                  Masterclass
                </div>
                <h3 className="text-4xl font-bold leading-[1.1] tracking-tight text-[var(--text-primary)] mb-4">
                  Advanced Pentesting
                </h3>
                <p className="text-[var(--text-secondary)] text-sm md:text-base max-w-md">
                  Deep dive into zero-day research, exploit development, and highly secured enterprise environments.
                </p>
              </div>

              <div className="mt-12 flex justify-between items-center border-t border-[var(--glass-border)] pt-6">
                <span className="text-[10px] font-mono tracking-widest uppercase text-[var(--text-secondary)] px-4 py-2 border border-[var(--glass-border)] rounded-full">
                  Coming Soon
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 text-center text-[var(--text-secondary)] text-xs font-mono tracking-widest uppercase border-t border-[var(--glass-border)] mt-20 transition-colors duration-500">
        <p>&copy; {new Date().getFullYear()} Snova Tech. All rights reserved.</p>
      </footer>

      {/* Registration Modal */}
      <RegistrationModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />

      {/* Course Registration Modal */}
      <CourseRegistrationModal
        isOpen={isCourseRegistrationOpen}
        onClose={() => setIsCourseRegistrationOpen(false)}
        courseId={course?.id || "course_cybersecurity_001"}
        courseName={course?.title || "Cyber Security Mastery"}
      />
    </div>
  );
};

export default LandingPage;
