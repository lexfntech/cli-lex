import { useState, useEffect } from 'react';
import { FiX, FiTag, FiCheck, FiSend, FiLoader, FiShield } from 'react-icons/fi';
import { auth } from '../firebase';
import { useDispatch } from 'react-redux';
import { createRegistration } from '../store/registrationSlice';
import type { AppDispatch } from '../store';
import { getReferralCode } from '../utils/referralTracking';

interface CourseRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  courseId: string;
  courseName: string;
  coursePrice?: number;
}

const CourseRegistrationModal = ({ isOpen, onClose, courseId, courseName, coursePrice = 0 }: CourseRegistrationModalProps) => {
  const dispatch = useDispatch<AppDispatch>();
  const [couponCode, setCouponCode] = useState('');
  const [couponApplied, setCouponApplied] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  // Auto-populate email and user info from currently logged in user
  const currentUser = auth.currentUser;
  const userEmail = currentUser?.email || '';
  const userName = currentUser?.displayName || '';

  // Get referral code from storage
  const referralCode = getReferralCode();

  const [isValidatingCoupon, setIsValidatingCoupon] = useState(false);
  const [couponError, setCouponError] = useState('');

  // Reset state when modal opens
  useEffect(() => {
    if (isOpen) {
      setCouponCode('');
      setCouponApplied(false);
      setIsSubmitting(false);
      setSuccess(false);
      setError('');
      setCouponError('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return;
    setIsValidatingCoupon(true);
    setCouponError('');
    try {
      const user = auth.currentUser;
      if (!user) {
        setCouponError('You must be logged in to validate a coupon');
        return;
      }
      const token = await user.getIdToken();
      const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3001";
      
      const response = await fetch(`${API_URL}/api/coupons/validate/${couponCode.trim().toUpperCase()}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const resData = await response.json();
      if (!response.ok) {
        throw new Error(resData.error || 'Invalid coupon code');
      }

      setCouponApplied(true);
    } catch (err: any) {
      setCouponError(err.message || 'Failed to validate coupon');
      setCouponApplied(false);
    } finally {
      setIsValidatingCoupon(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentUser) {
      setError('You must be logged in to register');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      await dispatch(createRegistration({
        userId: currentUser.uid,
        userName,
        userEmail,
        courseId,
        courseName,
        coursePrice,
        couponUsed: couponApplied ? couponCode : undefined,
        referralCode: referralCode || undefined,
      })).unwrap();
      
      setSuccess(true);
      setTimeout(() => {
        onClose();
      }, 2500);
    } catch (err: any) {
      setError(err.message || 'Failed to submit registration');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-md transition-opacity"
        onClick={!isSubmitting ? onClose : undefined}
      ></div>

      {/* Modal Content */}
      <div className="relative w-full max-w-md transform transition-all animate-fade-in">
        <div className="bezel-outer shadow-[0_0_50px_rgba(0,168,255,0.15)]">
          <div className="bezel-inner bg-[var(--bg-secondary)] p-8 relative overflow-hidden">
            
            {/* Top accent glow */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[var(--color-brand-blue)] to-transparent opacity-50"></div>

            {/* Header */}
            <div className="flex justify-between items-center mb-8">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-[var(--color-brand-blue)]/10 border border-[var(--color-brand-blue)]/30 flex items-center justify-center">
                  <FiShield className="text-[var(--color-brand-blue)]" />
                </div>
                <h2 className="text-xl font-bold tracking-tight text-[var(--text-primary)]">
                  Course Registration
                </h2>
              </div>
              {!isSubmitting && !success && (
                <button 
                  onClick={onClose}
                  className="text-[var(--text-secondary)] hover:text-white transition-colors p-2"
                >
                  <FiX className="text-xl" />
                </button>
              )}
            </div>

            {success ? (
              <div className="py-12 flex flex-col items-center text-center animate-fade-in">
                <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mb-6">
                  <FiCheck className="text-3xl text-emerald-500" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Request Submitted</h3>
                <p className="text-[var(--text-secondary)] text-sm max-w-[250px]">
                  Your registration is now pending review. You will be notified once approved.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col gap-6">
                
                {/* Course Details (Read-only) */}
                <div className="bg-[var(--glass-bg)] border border-[var(--glass-border)] rounded-lg p-4">
                  <label className="text-[10px] font-mono tracking-widest uppercase text-[var(--text-secondary)] block mb-1">
                    Selected Course
                  </label>
                  <div className="font-bold text-[var(--text-primary)]">
                    {courseName}
                  </div>
                </div>

                {/* Email Field (Auto-populated, disabled) */}
                <div>
                  <label className="text-[10px] font-mono tracking-widest uppercase text-[var(--text-secondary)] block mb-2 pl-1">
                    Linked Account Email
                  </label>
                  <input 
                    type="email" 
                    value={userEmail}
                    disabled
                    className="w-full bg-black/20 border border-[var(--glass-border)] rounded-lg px-4 py-3 text-sm text-[var(--text-secondary)] cursor-not-allowed opacity-70"
                  />
                  <p className="text-[10px] text-[var(--text-secondary)] mt-2 pl-1">
                    Registrations are bound to your active authenticated account.
                  </p>
                </div>

                {/* Coupon Code Field */}
                <div>
                  <label className="text-[10px] font-mono tracking-widest uppercase text-[var(--text-secondary)] block mb-2 pl-1">
                    Discount / Access Code
                  </label>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <FiTag className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-secondary)]" />
                      <input 
                        type="text" 
                        placeholder="Enter coupon code"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                        disabled={couponApplied || isSubmitting}
                        className="w-full bg-[var(--bg-primary)] border border-[var(--glass-border)] rounded-lg py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-[var(--color-brand-blue)] focus:ring-1 focus:ring-[var(--color-brand-blue)] transition-all placeholder-[var(--text-secondary)] text-[var(--text-primary)] disabled:opacity-50 font-mono"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={handleApplyCoupon}
                      disabled={!couponCode || couponApplied || isSubmitting || isValidatingCoupon}
                      className={`px-4 py-2 rounded-lg text-xs font-bold tracking-widest uppercase transition-all ${
                        couponApplied 
                          ? 'bg-emerald-500/20 text-emerald-500 border border-emerald-500/30' 
                          : 'bg-[var(--glass-bg)] hover:bg-[var(--glass-bg-hover)] text-[var(--text-primary)] border border-[var(--glass-border)]'
                      }`}
                    >
                      {isValidatingCoupon ? 'Validating...' : (couponApplied ? 'Applied' : 'Apply')}
                    </button>
                  </div>
                  {couponApplied && (
                    <p className="text-[10px] text-emerald-400 mt-2 pl-1 font-mono">
                      Valid code applied. Discount will be calculated on review.
                    </p>
                  )}
                  {couponError && (
                    <p className="text-[10px] text-red-400 mt-2 pl-1 font-mono">
                      {couponError}
                    </p>
                  )}
                </div>

                {error && (
                  <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-red-400 text-xs">
                    {error}
                  </div>
                )}

                {referralCode && (
                  <div className="bg-[var(--color-icy-cyan)]/10 border border-[var(--color-icy-cyan)]/30 rounded-lg p-3">
                    <p className="text-[10px] font-mono tracking-widest uppercase text-[var(--text-secondary)] mb-1">
                      Referral Applied
                    </p>
                    <p className="text-xs text-[var(--color-icy-cyan)] font-mono">
                      Code: {referralCode}
                    </p>
                  </div>
                )}

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full relative group overflow-hidden rounded-lg mt-4"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-[var(--color-icy-cyan)] to-[var(--color-brand-blue)] opacity-80 group-hover:opacity-100 transition-opacity"></div>
                  <div className="relative flex items-center justify-center gap-3 px-6 py-4">
                    {isSubmitting ? (
                      <>
                        <FiLoader className="text-lg animate-spin text-white" />
                        <span className="text-sm font-bold tracking-widest uppercase text-white">Processing...</span>
                      </>
                    ) : (
                      <>
                        <span className="text-sm font-bold tracking-widest uppercase text-white">Submit Request</span>
                        <FiSend className="text-lg text-white group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                      </>
                    )}
                  </div>
                </button>
                
              </form>
            )}
            
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseRegistrationModal;
