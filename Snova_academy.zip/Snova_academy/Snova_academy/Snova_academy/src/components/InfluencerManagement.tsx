import { useState, useEffect, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  FiPlus,
  FiEdit2,
  FiTrash2,
  FiSearch,
  FiX,
  FiCheck,
  FiCopy,
  FiEye,
  FiEyeOff,
  FiUsers,
  FiTrendingUp,
  FiCheckCircle,
  FiDollarSign,
  FiInfo,
  FiInstagram,
  FiYoutube,
  FiLinkedin,
  FiMail,
  FiPhone,
  FiUser
} from 'react-icons/fi';
import type { AppDispatch, RootState } from '../store';
import {
  fetchInfluencers,
  fetchAnalytics,
  createInfluencer,
  updateInfluencer,
  updateInfluencerStatus,
  deleteInfluencer,
  type Influencer,
} from '../store/influencerSlice';

const InfluencerManagement = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { influencers, analytics, loading, error } = useSelector((state: RootState) => state.influencer);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedInfluencer, setSelectedInfluencerLocal] = useState<Influencer | null>(null);
  const [copiedLink, setCopiedLink] = useState<string | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    username: '',
    password: '',
    status: 'active' as 'active' | 'inactive',
    tier: 'Bronze',
    commission: '10',
    instagram: '',
    youtube: '',
    linkedin: '',
    notes: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    dispatch(fetchInfluencers({ status: statusFilter === 'all' ? undefined : statusFilter }));
    dispatch(fetchAnalytics());
  }, [dispatch, statusFilter]);

  const filteredInfluencers = useMemo(() => {
    return influencers.filter(
      (inf) =>
        inf.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        inf.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        inf.referralCode.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [influencers, searchQuery]);

  const handleCopyLink = (link: string, id: string) => {
    navigator.clipboard.writeText(link);
    setCopiedLink(id);
    setTimeout(() => setCopiedLink(null), 2000);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      username: '',
      password: '',
      status: 'active',
      tier: 'Bronze',
      commission: '10',
      instagram: '',
      youtube: '',
      linkedin: '',
      notes: '',
    });
    setFormErrors({});
    setShowPassword(false);
  };

  const validateForm = (isEdit = false): boolean => {
    const errors: Record<string, string> = {};

    if (!formData.name.trim()) errors.name = 'Name is required';
    if (!formData.email.trim()) errors.email = 'Email is required';
    if (!formData.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) errors.email = 'Invalid email format';
    if (!formData.phone.trim()) errors.phone = 'Phone is required';
    if (!formData.username.trim()) errors.username = 'Username is required';
    if (!isEdit && !formData.password.trim()) errors.password = 'Password is required';
    if (!isEdit && formData.password.length < 6) errors.password = 'Password must be at least 6 characters';

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleAddInfluencer = async () => {
    if (!validateForm()) return;

    try {
      const payload = {
        name: formData.name.trim(),
        email: formData.email.trim(),
        phone: formData.phone.trim(),
        username: formData.username.trim(),
        password: formData.password,
        status: formData.status,
      };
      await dispatch(createInfluencer(payload)).unwrap();
      setShowAddModal(false);
      resetForm();
      dispatch(fetchAnalytics());
    } catch (err: any) {
      setFormErrors({ submit: err.message || 'Failed to create influencer' });
    }
  };

  const handleEditInfluencer = async () => {
    if (!selectedInfluencer || !validateForm(true)) return;

    try {
      const updates = {
        name: formData.name.trim(),
        email: formData.email.trim(),
        phone: formData.phone.trim(),
        status: formData.status,
      };

      await dispatch(updateInfluencer({ id: selectedInfluencer.id, updates })).unwrap();
      setShowEditModal(false);
      setSelectedInfluencerLocal(null);
      resetForm();
      dispatch(fetchAnalytics());
    } catch (err: any) {
      setFormErrors({ submit: err.message || 'Failed to update influencer' });
    }
  };

  const handleToggleStatus = async (influencer: Influencer) => {
    const newStatus = influencer.status === 'active' ? 'inactive' : 'active';
    try {
      await dispatch(updateInfluencerStatus({ id: influencer.id, status: newStatus })).unwrap();
      dispatch(fetchAnalytics());
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  };

  const handleDeleteInfluencer = async () => {
    if (!selectedInfluencer) return;

    try {
      await dispatch(deleteInfluencer(selectedInfluencer.id)).unwrap();
      setShowDeleteModal(false);
      setSelectedInfluencerLocal(null);
      dispatch(fetchAnalytics());
    } catch (err) {
      console.error('Failed to delete influencer:', err);
    }
  };

  const openEditModal = (influencer: Influencer) => {
    setSelectedInfluencerLocal(influencer);
    let assignedTier = 'Bronze';
    if (influencer.confirmedLeads >= 20) assignedTier = 'Gold';
    else if (influencer.confirmedLeads >= 5) assignedTier = 'Silver';

    setFormData({
      name: influencer.name,
      email: influencer.email,
      phone: influencer.phone,
      username: influencer.username,
      password: '',
      status: influencer.status as 'active' | 'inactive',
      tier: assignedTier,
      commission: '10',
      instagram: influencer.username ? `${influencer.username}.codes` : '',
      youtube: '',
      linkedin: '',
      notes: 'Active influencer in tech space.',
    });
    setShowEditModal(true);
  };

  const openDeleteModal = (influencer: Influencer) => {
    setSelectedInfluencerLocal(influencer);
    setShowDeleteModal(true);
  };

  const getTierDetails = (confirmedLeads: number) => {
    if (confirmedLeads >= 20) {
      return {
        label: 'Gold Tier',
        styles: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
        dot: 'bg-amber-400'
      };
    } else if (confirmedLeads >= 5) {
      return {
        label: 'Silver Tier',
        styles: 'bg-slate-500/10 text-slate-300 border-slate-500/20',
        dot: 'bg-slate-400'
      };
    } else {
      return {
        label: 'Bronze Tier',
        styles: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
        dot: 'bg-orange-400'
      };
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const stats = useMemo(() => {
    const totalCount = influencers.length;
    const activeCount = influencers.filter(i => i.status === 'active').length;
    const totalLeadsCount = influencers.reduce((sum, i) => sum + (i.totalLeads || 0), 0);
    const totalRev = influencers.reduce((sum, i) => sum + (i.revenueGenerated || 0), 0);

    return {
      totalInfluencers: analytics?.totalInfluencers || totalCount,
      activeInfluencers: activeCount,
      totalReferrals: analytics?.totalLeads || totalLeadsCount,
      totalEarnings: analytics?.totalRevenue || totalRev
    };
  }, [influencers, analytics]);

  return (
    <div className="space-y-6 text-slate-200 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-lg font-black text-white uppercase tracking-tight">Influencer Hub</h1>
          <p className="text-xs text-slate-400 font-medium mt-0.5">
            Manage your partner community, monitor referral conversions, and adjust payout tiers.
          </p>
        </div>

        <button
          onClick={() => {
            resetForm();
            setShowAddModal(true);
          }}
          className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[var(--color-brand-blue-alt)] to-[var(--color-brand-blue)] px-4 py-2.5 text-xs font-bold text-white uppercase tracking-wider transition-colors cursor-pointer shadow-md shadow-blue-500/10"
        >
          <FiPlus className="text-sm" /> Add Influencer
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <StatSummaryCard
          icon={<FiUsers className="text-indigo-400" />}
          iconBg="bg-indigo-500/10 border-indigo-500/20"
          label="Total Partners"
          value={stats.totalInfluencers.toString()}
          subtitle="Onboarded users"
        />
        <StatSummaryCard
          icon={<FiCheckCircle className="text-emerald-400" />}
          iconBg="bg-emerald-500/10 border-emerald-500/20"
          label="Active Partners"
          value={stats.activeInfluencers.toString()}
          subtitle="Status active"
        />
        <StatSummaryCard
          icon={<FiTrendingUp className="text-purple-400" />}
          iconBg="bg-purple-500/10 border-purple-500/20"
          label="Total Referrals"
          value={stats.totalReferrals.toString()}
          subtitle="All-time leads"
        />
        <StatSummaryCard
          icon={<FiDollarSign className="text-blue-400" />}
          iconBg="bg-blue-500/10 border-blue-500/20"
          label="Total Revenue"
          value={formatCurrency(stats.totalEarnings)}
          subtitle="Generated"
        />
      </div>

      {/* Filter toolbar & list table */}
      <div className="rounded-2xl border border-white/5 bg-[#090909] p-6 shadow-xl">
        <div className="flex flex-col gap-4 md:flex-row md:items-center justify-between mb-6">
          <div className="relative flex-1 md:max-w-md">
            <FiSearch className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm" />
            <input
              type="text"
              placeholder="Search partners by name, email, or code..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-xl border border-white/5 bg-white/2 pl-9 pr-4 py-2 text-xs outline-none text-white focus:border-white/10 placeholder:text-slate-500"
            />
          </div>

          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="rounded-xl border border-white/5 bg-[#121212] px-3.5 py-2 text-xs outline-none text-slate-300 focus:border-white/10"
            >
              <option value="all">All Status</option>
              <option value="active">Active Only</option>
              <option value="inactive">Inactive Only</option>
            </select>
          </div>
        </div>

        {error && (
          <div className="bg-rose-500/10 border border-rose-500/20 rounded-xl p-4 mb-6 text-rose-400 text-xs">
            {error}
          </div>
        )}

        {loading && influencers.length === 0 ? (
          <div className="flex justify-center items-center py-20">
            <div className="w-8 h-8 border-2 border-[var(--color-brand-blue)] border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[950px]">
              <thead>
                <tr className="border-b border-white/5 bg-white/1 text-[9px] font-bold uppercase tracking-widest text-slate-500 font-mono">
                  <th className="p-4">Partner Profile</th>
                  <th className="p-4">Contact Info</th>
                  <th className="p-4">Referral Code</th>
                  <th className="p-4">Leads Stats</th>
                  <th className="p-4">Partner Tier</th>
                  <th className="p-4">Revenue Generated</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/3">
                {filteredInfluencers.length > 0 ? (
                  filteredInfluencers.map((influencer) => {
                    const tier = getTierDetails(influencer.confirmedLeads || 0);
                    return (
                      <tr key={influencer.id} className="hover:bg-white/1 transition-colors text-xs text-slate-300">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[var(--color-brand-blue-alt)] to-[var(--color-icy-cyan)] flex items-center justify-center font-bold text-white text-xs shadow-md shadow-black">
                              {influencer.name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <div className="font-bold text-white">{influencer.name}</div>
                              <div className="text-[9px] text-slate-500 font-mono mt-0.5">@{influencer.username}</div>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-1.5 text-slate-300">
                            <FiMail className="text-slate-500 flex-shrink-0" />
                            <span>{influencer.email}</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-slate-500 mt-1 text-[11px]">
                            <FiPhone className="text-slate-500 flex-shrink-0" />
                            <span>{influencer.phone}</span>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-1.5">
                            <code className="px-2.5 py-0.5 bg-[#121212] border border-white/5 rounded text-xs font-mono font-bold text-[var(--color-icy-cyan)] shadow-inner">
                              {influencer.referralCode}
                            </code>
                            <button
                              onClick={() => handleCopyLink(influencer.referralLink, influencer.id)}
                              className="p-1.5 hover:bg-white/5 border border-transparent rounded transition-colors text-slate-500 hover:text-white cursor-pointer"
                              title="Copy Referral Link"
                            >
                              {copiedLink === influencer.id ? (
                                <FiCheck className="text-emerald-400 text-xs" />
                              ) : (
                                <FiCopy className="text-xs" />
                              )}
                            </button>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="space-y-0.5 font-mono text-[11px]">
                            <div className="flex justify-between w-20">
                              <span className="text-slate-500">Total:</span>
                              <span className="text-white font-bold">{influencer.totalLeads}</span>
                            </div>
                            <div className="flex justify-between w-20">
                              <span className="text-slate-500">Paid:</span>
                              <span className="text-emerald-400 font-bold">{influencer.confirmedLeads}</span>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[9px] font-bold border ${tier.styles}`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${tier.dot}`}></span>
                            {tier.label}
                          </span>
                        </td>
                        <td className="p-4 font-bold text-white font-mono">
                          {formatCurrency(influencer.revenueGenerated || 0)}
                        </td>
                        <td className="p-4">
                          <button
                            onClick={() => handleToggleStatus(influencer)}
                            className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[9px] font-bold border transition-colors cursor-pointer ${
                              influencer.status === 'active'
                                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/20'
                                : 'bg-white/2 text-slate-500 border-white/5 hover:bg-white/5'
                            }`}
                          >
                            <span className={`w-1.5 h-1.5 rounded-full ${influencer.status === 'active' ? 'bg-emerald-500' : 'bg-slate-655'}`}></span>
                            {influencer.status === 'active' ? 'Active' : 'Inactive'}
                          </button>
                        </td>
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              onClick={() => openEditModal(influencer)}
                              className="p-1.5 hover:bg-white/5 border border-white/5 rounded-lg transition-colors text-slate-400 hover:text-white cursor-pointer"
                              title="Edit Details"
                            >
                              <FiEdit2 className="text-xs" />
                            </button>
                            <button
                              onClick={() => openDeleteModal(influencer)}
                              className="p-1.5 hover:bg-rose-500/10 border border-white/5 rounded-lg transition-colors text-rose-400 hover:text-rose-300 cursor-pointer"
                              title="Delete Partner"
                            >
                              <FiTrash2 className="text-xs" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={8} className="p-12 text-center text-slate-500 text-xs border border-dashed border-white/5 rounded-2xl">
                      No influencers found matching your query.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Split Add/Edit Influencer Dialog */}
      {(showAddModal || showEditModal) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => {
            setShowAddModal(false);
            setShowEditModal(false);
            resetForm();
          }}></div>
          <div className="relative w-full max-w-4xl border border-white/5 bg-[#0a0a0a] rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/5 bg-[#0c0c0c] p-5">
              <div>
                <h3 className="text-xs font-black text-white uppercase tracking-widest font-mono">{showAddModal ? "Onboard New Partner" : "Edit Partner Profile"}</h3>
                <p className="text-[10px] text-slate-400 font-medium mt-0.5">Fill out credentials and preview card layout in real-time.</p>
              </div>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setShowEditModal(false);
                  resetForm();
                }}
                className="p-1.5 hover:bg-white/5 rounded-lg transition-colors text-slate-400 hover:text-white cursor-pointer"
              >
                <FiX className="text-base" />
              </button>
            </div>

            {/* Split Workspace Body */}
            <div className="overflow-y-auto p-6 flex-1 bg-[#090909]">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Left Form Editor */}
                <div className="lg:col-span-7 space-y-5 bg-[#0c0c0c] border border-white/5 rounded-xl p-5 shadow-inner">
                  <div className="space-y-4">
                    
                    {/* Section 1: Credentials */}
                    <div>
                      <h4 className="text-[10px] font-bold text-white uppercase tracking-wider border-b border-white/5 pb-2 mb-3 font-mono">
                        Basic Information
                      </h4>
                      <div className="space-y-3">
                        <InputField
                          label="Full Name"
                          value={formData.name}
                          onChange={(val) => setFormData({ ...formData, name: val })}
                          error={formErrors.name}
                          placeholder="e.g. Rohit Sharma"
                          required
                        />

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <InputField
                            label="Email Address"
                            type="email"
                            value={formData.email}
                            onChange={(val) => setFormData({ ...formData, email: val })}
                            error={formErrors.email}
                            placeholder="rohit@codes.com"
                            required
                          />
                          <InputField
                            label="Phone Number"
                            value={formData.phone}
                            onChange={(val) => setFormData({ ...formData, phone: val })}
                            error={formErrors.phone}
                            placeholder="🇮🇳 +91 9876543210"
                            required
                          />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <InputField
                            label="Username Handle"
                            value={formData.username}
                            onChange={(val) => setFormData({ ...formData, username: val.toLowerCase().replace(/[^a-z0-9._]/g, '') })}
                            error={formErrors.username}
                            placeholder="rohit.codes"
                            disabled={showEditModal}
                            required
                          />
                          
                          {showAddModal && (
                            <div className="relative">
                              <InputField
                                label="Access Password"
                                type={showPassword ? 'text' : 'password'}
                                value={formData.password}
                                onChange={(val) => setFormData({ ...formData, password: val })}
                                error={formErrors.password}
                                placeholder="••••••"
                                required
                              />
                              <button
                                type="button"
                                onClick={() => setShowPassword(!showPassword)}
                                className="absolute right-3.5 top-9 text-slate-500 hover:text-slate-300 cursor-pointer"
                              >
                                {showPassword ? <FiEyeOff className="text-sm" /> : <FiEye className="text-sm" />}
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Section 2: Visual Tiering Configuration */}
                    <div>
                      <h4 className="text-[10px] font-bold text-white uppercase tracking-wider border-b border-white/5 pb-2 mb-3 font-mono">
                        Partner Tiers & Commissions
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">
                            Partner Tier
                          </label>
                          <select
                            value={formData.tier}
                            onChange={(e) => setFormData({ ...formData, tier: e.target.value })}
                            className="w-full rounded-xl border border-white/5 bg-[#121212] px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10"
                          >
                            <option value="Bronze">Bronze Tier (0 - 4 paid conversions)</option>
                            <option value="Silver">Silver Tier (5 - 19 paid conversions)</option>
                            <option value="Gold">Gold Tier (20+ paid conversions)</option>
                          </select>
                        </div>

                        <div>
                          <InputField
                            label="Referral Commission (%)"
                            type="number"
                            value={formData.commission}
                            onChange={(val) => setFormData({ ...formData, commission: val })}
                            placeholder="10"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Section 3: Social & Bios */}
                    <div>
                      <h4 className="text-[10px] font-bold text-white uppercase tracking-wider border-b border-white/5 pb-2 mb-3 font-mono">
                        Social Handles & Notes
                      </h4>
                      <div className="space-y-3">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                          <div>
                            <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 flex items-center gap-1 font-mono">
                              <FiInstagram /> Instagram
                            </label>
                            <input
                              type="text"
                              value={formData.instagram}
                              onChange={(e) => setFormData({ ...formData, instagram: e.target.value })}
                              placeholder="@username"
                              className="w-full rounded-xl border border-white/5 bg-[#121212] px-3.5 py-2 text-xs outline-none text-white focus:border-white/10"
                            />
                          </div>
                          <div>
                            <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 flex items-center gap-1 font-mono">
                              <FiYoutube /> YouTube
                            </label>
                            <input
                              type="text"
                              value={formData.youtube}
                              onChange={(e) => setFormData({ ...formData, youtube: e.target.value })}
                              placeholder="Channel name"
                              className="w-full rounded-xl border border-white/5 bg-[#121212] px-3.5 py-2 text-xs outline-none text-white focus:border-white/10"
                            />
                          </div>
                          <div>
                            <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 flex items-center gap-1 font-mono">
                              <FiLinkedin /> LinkedIn
                            </label>
                            <input
                              type="text"
                              value={formData.linkedin}
                              onChange={(e) => setFormData({ ...formData, linkedin: e.target.value })}
                              placeholder="Profile url"
                              className="w-full rounded-xl border border-white/5 bg-[#121212] px-3.5 py-2 text-xs outline-none text-white focus:border-white/10"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">
                            Private Admin Notes
                          </label>
                          <textarea
                            value={formData.notes}
                            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                            rows={2}
                            placeholder="Add brief background context on this referral partnership..."
                            className="w-full rounded-xl border border-white/5 bg-[#121212] px-3.5 py-2.5 text-xs outline-none text-white focus:border-white/10 resize-none placeholder:text-slate-550"
                          />
                        </div>
                      </div>
                    </div>

                  </div>

                  {formErrors.submit && (
                    <div className="bg-rose-500/10 border border-rose-500/20 rounded-xl p-3 text-rose-400 text-xs">
                      {formErrors.submit}
                    </div>
                  )}
                </div>

                {/* Right Visual Card Live Preview */}
                <div className="lg:col-span-5 space-y-4 flex flex-col">
                  
                  <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1 font-mono">
                    Dynamic Card Preview
                  </div>

                  {/* High Fidelity Card Container */}
                  <div className="border border-white/5 bg-[#0c0c0c] rounded-xl shadow-xl overflow-hidden relative flex flex-col">
                    <div className="h-24 bg-gradient-to-tr from-[#121212] to-[#1e1e1e] relative border-b border-white/5">
                      <div className="absolute top-3 right-3">
                        <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[9px] font-bold uppercase border ${
                          formData.status === 'active'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                            : 'bg-white/3 text-slate-500 border-white/5'
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${formData.status === 'active' ? 'bg-emerald-500 animate-pulse' : 'bg-slate-600'}`}></span>
                          {formData.status}
                        </span>
                      </div>
                    </div>

                    <div className="px-5 pb-5 -mt-10 flex-1 flex flex-col items-center text-center">
                      <div className="w-16 h-16 rounded-full border-4 border-[#0c0c0c] bg-gradient-to-tr from-[var(--color-brand-blue-alt)] to-[var(--color-icy-cyan)] flex items-center justify-center text-lg font-black text-white shadow-lg mb-3">
                        {formData.name ? formData.name.charAt(0).toUpperCase() : <FiUser />}
                      </div>

                      <h4 className="font-extrabold text-sm text-white">
                        {formData.name || 'Jane Doe'}
                      </h4>
                      <p className="text-[10px] text-slate-500 font-mono mt-0.5">
                        @{formData.username || 'handle'}
                      </p>

                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[9px] font-bold border mt-3 ${
                        formData.tier === 'Gold'
                          ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                          : formData.tier === 'Silver'
                          ? 'bg-white/4 text-slate-300 border-white/5'
                          : 'bg-orange-500/10 text-orange-400 border-orange-500/20'
                      }`}>
                        <span className={`w-1 h-1 rounded-full ${
                          formData.tier === 'Gold' ? 'bg-amber-500' : formData.tier === 'Silver' ? 'bg-slate-400' : 'bg-orange-500'
                        }`}></span>
                        {formData.tier} Member
                      </span>

                      <div className="w-full border-t border-white/5 my-4"></div>

                      <div className="grid grid-cols-2 gap-4 w-full text-left">
                        <div>
                          <div className="text-[9px] text-slate-500 font-bold uppercase tracking-wider font-mono">Referral Code</div>
                          <div className="text-xs font-mono font-bold text-[var(--color-icy-cyan)] mt-0.5">
                            {formData.username ? formData.username.toUpperCase() : 'CODE'}10
                          </div>
                        </div>
                        <div>
                          <div className="text-[9px] text-slate-500 font-bold uppercase tracking-wider font-mono">Commission</div>
                          <div className="text-xs font-bold text-white mt-0.5">
                            {formData.commission || '10'}% per sale
                          </div>
                        </div>
                        <div>
                          <div className="text-[9px] text-slate-500 font-bold uppercase tracking-wider font-mono">Total leads</div>
                          <div className="text-xs font-bold text-white mt-0.5">
                            {selectedInfluencer ? selectedInfluencer.totalLeads : 0} leads
                          </div>
                        </div>
                        <div>
                          <div className="text-[9px] text-slate-500 font-bold uppercase tracking-wider font-mono font-mono">Earned Revenue</div>
                          <div className="text-xs font-bold text-emerald-400 mt-0.5 font-mono">
                            {selectedInfluencer ? formatCurrency(selectedInfluencer.revenueGenerated || 0) : '₹0'}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Tips Card */}
                  <div className="bg-white/2 border border-white/5 rounded-xl p-4 text-[10px] text-slate-400 space-y-2.5">
                    <div className="font-bold text-slate-300 flex items-center gap-1.5 font-mono">
                      <FiInfo className="text-xs text-[var(--color-brand-blue)]" /> ONBOARDING GUIDELINES
                    </div>
                    <ul className="list-disc pl-4 space-y-1">
                      <li>Ensure phone number starts with country code prefix.</li>
                      <li>Referral code will be generated as <strong>USERNAME10</strong>.</li>
                      <li>Adjust partner tiers manually here or let system metrics auto-promote them.</li>
                    </ul>
                  </div>

                </div>

              </div>
            </div>

            {/* Modal Actions Footer */}
            <div className="border-t border-white/5 bg-[#0c0c0c] p-5 flex gap-3">
              <button
                type="button"
                onClick={() => {
                  setShowAddModal(false);
                  setShowEditModal(false);
                  resetForm();
                }}
                className="flex-1 px-4 py-2.5 bg-white/2 hover:bg-white/5 border border-white/5 text-slate-300 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={showAddModal ? handleAddInfluencer : handleEditInfluencer}
                disabled={!formData.name || !formData.email || !formData.phone || !formData.username}
                className="flex-1 px-4 py-2.5 bg-gradient-to-r from-[var(--color-brand-blue-alt)] to-[var(--color-brand-blue)] text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-colors disabled:opacity-30 cursor-pointer shadow-md shadow-blue-500/10"
              >
                {showAddModal ? "Create Partner" : "Save Settings"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteModal && selectedInfluencer && (
        <Modal
          title="Delete Partner Account"
          onClose={() => {
            setShowDeleteModal(false);
            setSelectedInfluencerLocal(null);
          }}
        >
          <div className="space-y-4">
            <p className="text-xs text-slate-400 leading-relaxed">
              Are you sure you want to delete <strong className="text-white">{selectedInfluencer.name}</strong>? 
              This will permanently revoke access, pause their active referral code (<strong>{selectedInfluencer.referralCode}</strong>), and archive their tracking history.
            </p>
            
            <div className="flex gap-3 pt-2 border-t border-white/5">
              <button
                onClick={() => {
                  setShowDeleteModal(false);
                  setSelectedInfluencerLocal(null);
                }}
                className="flex-1 px-4 py-2.5 bg-white/2 hover:bg-white/5 border border-white/5 text-slate-300 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteInfluencer}
                className="flex-1 px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
              >
                Delete Partner
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

// Stat Summary Helper Card
const StatSummaryCard = ({
  icon,
  iconBg,
  label,
  value,
  subtitle,
}: {
  icon: React.ReactNode;
  iconBg: string;
  label: string;
  value: string;
  subtitle: string;
}) => (
  <div className="bg-[#090909] border border-white/5 rounded-2xl p-5 shadow-xl hover:border-white/10 transition-all flex items-center gap-4">
    <div className={`w-10 h-10 rounded-xl ${iconBg} flex items-center justify-center text-lg flex-shrink-0 border shadow-md`}>
      {icon}
    </div>
    <div>
      <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono">{label}</div>
      <div className="text-lg font-black text-white mt-1 leading-none tracking-tight">{value}</div>
      <div className="text-[10px] text-slate-400 mt-1 font-medium">{subtitle}</div>
    </div>
  </div>
);

// Modal Overlay Component
const Modal = ({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative w-full max-w-md border border-white/5 bg-[#0a0a0a] rounded-2xl shadow-2xl p-6">
        <div className="flex items-center justify-between mb-5 border-b border-white/5 pb-3">
          <h3 className="text-xs font-black text-white uppercase tracking-widest font-mono">{title}</h3>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/5 rounded transition-colors text-slate-400 hover:text-white cursor-pointer"
          >
            <FiX />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
};

// Input Field Component
const InputField = ({
  label,
  type = 'text',
  value,
  onChange,
  error,
  placeholder,
  required = false,
  disabled = false,
}: {
  label: string;
  type?: string;
  value: string;
  onChange: (value: string) => void;
  error?: string;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
}) => {
  return (
    <div>
      <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 pl-0.5 mb-1.5 font-mono">
        {label} {required && <span className="text-rose-450">*</span>}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        disabled={disabled}
        className={`w-full rounded-xl border bg-[#121212] px-3.5 py-2.5 text-xs outline-none transition-all placeholder:text-slate-550 text-white ${
          disabled ? 'opacity-30 cursor-not-allowed' : ''
        } ${
          error
            ? 'border-rose-500 focus:border-rose-500'
            : 'border-white/5 focus:border-white/10'
        }`}
        required={required}
      />
      {error && <p className="text-[10px] text-rose-450 mt-1 pl-0.5 font-medium">{error}</p>}
    </div>
  );
};

export default InfluencerManagement;
