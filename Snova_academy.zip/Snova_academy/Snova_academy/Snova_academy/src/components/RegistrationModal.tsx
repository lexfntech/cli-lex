import { useState, useEffect, useRef } from 'react';
import { auth } from '../firebase';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import type { User } from 'firebase/auth';
import gsap from 'gsap';
import { FcGoogle } from 'react-icons/fc';
import { FiX } from 'react-icons/fi';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const RegistrationModal = ({ isOpen, onClose }: ModalProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [name, setName] = useState('');
  const [coupon, setCoupon] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  
  const modalRef = useRef<HTMLDivElement>(null);
  const backdropRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (u) => {
      setUser(u);
      if (u) {
        if (u.displayName) setName(u.displayName);
        
        // Check user profile from Firestore to determine role
        try {
          const token = await u.getIdToken();
          const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
          const response = await fetch(`${apiUrl}/api/auth/profile`, {
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });

          if (response.ok) {
            const data = await response.json();
            const userProfile = data.data;
            
            // User exists - check role and redirect
            if (userProfile.role === 'admin') {
              onClose();
              window.location.href = '/management-dashboard-x92f-snova';
            } else if (userProfile.role === 'student') {
              onClose();
              window.location.href = '/dashboard';
            } else if (userProfile.role === 'influencer') {
              onClose();
              window.location.href = '/dashboard'; // Future: influencer dashboard
            }
          }
          // If 404, user doesn't exist - modal will show for registration
        } catch (error) {
          console.error('Error checking user profile:', error);
        }
      }
    });
    return () => unsubscribe();
  }, [onClose]);

  // Professional Entrance Animation
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      
      gsap.fromTo(backdropRef.current, 
        { opacity: 0, backdropFilter: 'blur(0px)' }, 
        { opacity: 1, backdropFilter: 'blur(12px)', duration: 0.4, ease: 'power2.out' }
      );
      
      gsap.fromTo(modalRef.current,
        { opacity: 0, y: 20, scale: 0.98 },
        { opacity: 1, y: 0, scale: 1, duration: 0.5, ease: 'power3.out' }
      );
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const handleClose = () => {
    gsap.to(modalRef.current, {
      opacity: 0,
      y: 15,
      scale: 0.98,
      duration: 0.3,
      ease: 'power2.in'
    });
    gsap.to(backdropRef.current, {
      opacity: 0,
      backdropFilter: 'blur(0px)',
      duration: 0.3,
      ease: 'power2.in',
      onComplete: onClose
    });
  };

  if (!isOpen) return null;

  const handleGoogleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    if (!user) return;

    try {
      const token = await user.getIdToken();
      const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
      const response = await fetch(`${apiUrl}/api/auth/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          uid: user.uid,
          name,
          email: user.email,
          coupon
        })
      });

      if (!response.ok) throw new Error('Registration failed');

      setSuccess(true);
      gsap.fromTo('.success-check path', 
        { strokeDashoffset: 100 }, 
        { strokeDashoffset: 0, duration: 0.8, ease: 'power2.out', delay: 0.1 }
      );
      
      // Check if user is admin and redirect accordingly
      setTimeout(async () => {
        if (user) {
          const tokenResult = await user.getIdTokenResult();
          if (tokenResult.claims.admin) {
            window.location.href = '/management-dashboard-x92f-snova';
          } else {
            window.location.href = '/dashboard';
          }
        }
      }, 1500);
    } catch (err: any) {
      setError(err.message || 'Submission error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        ref={backdropRef}
        className="absolute inset-0 bg-[var(--bg-primary)]/80"
        onClick={handleClose}
      ></div>

      {/* Ambient Modal Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-[var(--color-brand-blue)]/5 rounded-full blur-[80px] pointer-events-none theme-blend-glow"></div>

      {/* Modal Container */}
      <div 
        ref={modalRef}
        className="bezel-outer w-full max-w-md relative z-10"
      >
        <div className="bezel-inner p-8 relative overflow-hidden">
          
          {/* Professional Close Button */}
          <button 
            onClick={handleClose}
            className="absolute top-5 right-5 w-8 h-8 flex items-center justify-center rounded bg-[var(--glass-bg)] border border-transparent text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:border-[var(--glass-border)] transition-all z-20"
            aria-label="Close"
          >
            <FiX className="w-5 h-5" />
          </button>

          {/* Logo element */}
          <div className="w-12 h-12 mx-auto mb-6 relative">
            <div className="absolute inset-0 bg-[var(--color-brand-blue)] rounded blur-md opacity-20"></div>
            <div className="w-full h-full relative bg-[var(--bg-secondary)] border border-[var(--color-brand-blue)] rounded flex items-center justify-center shadow-sm">
              <span className="text-[var(--color-brand-blue-alt)] font-bold font-mono text-lg">S</span>
            </div>
          </div>
          
          {success ? (
            <div className="text-center py-4 relative z-10">
              <div className="w-16 h-16 mx-auto mb-5 relative">
                <div className="absolute inset-0 bg-green-500/10 rounded-full blur-md"></div>
                <div className="w-full h-full rounded-full border border-green-500/30 flex items-center justify-center bg-[var(--bg-secondary)] relative z-10">
                  <svg className="success-check w-6 h-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" style={{ strokeDasharray: 100, strokeDashoffset: 100 }} />
                  </svg>
                </div>
              </div>
              <h2 className="text-2xl font-bold mb-2 font-sans text-[var(--text-primary)]">Registration Successful</h2>
              <p className="text-[var(--text-secondary)] text-sm mb-8">Your account has been provisioned successfully.</p>
              
              <button 
                onClick={handleClose}
                className="w-full py-3 bg-[var(--color-brand-blue)] text-white font-medium text-sm rounded hover:bg-[var(--color-brand-blue-alt)] transition-colors relative z-10"
              >
                Continue to Dashboard
              </button>
            </div>
          ) : !user ? (
            <div className="relative z-10">
              <h2 className="text-2xl font-bold mb-2 font-sans text-center text-[var(--text-primary)]">Sign In</h2>
              <p className="text-[var(--text-secondary)] mb-8 text-sm text-center">Authenticate to access the Snova curriculum.</p>
              
              <button 
                onClick={handleGoogleLogin}
                className="w-full flex items-center justify-center gap-3 rounded border border-[var(--glass-border)] bg-[var(--bg-secondary)] p-3 transition-colors hover:bg-[rgba(255,255,255,0.05)] active:scale-[0.99]"
              >
                <FcGoogle className="w-5 h-5" />
                <span className="font-medium text-sm text-[var(--text-primary)]">Continue with Google</span>
              </button>
              {error && <p className="text-red-400 mt-4 text-xs text-center p-2 rounded bg-red-400/10 border border-red-400/20">{error}</p>}
            </div>
          ) : (
            <div className="relative z-10">
              <h2 className="text-2xl font-bold mb-2 font-sans text-center text-[var(--text-primary)]">Complete Registration</h2>
              <p className="text-[var(--text-secondary)] mb-6 text-sm text-center">Please confirm your details to proceed.</p>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                
                <div>
                  <label className="block text-xs font-medium text-[var(--text-secondary)] mb-1.5">Email Address</label>
                  <input 
                    type="email" 
                    value={user.email || ''} 
                    disabled 
                    className="w-full px-4 py-2.5 text-sm text-[var(--text-primary)] bg-[var(--bg-primary)] border border-[var(--glass-border)] rounded opacity-60 cursor-not-allowed"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[var(--text-secondary)] mb-1.5">Full Name</label>
                  <input 
                    type="text" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    className="w-full px-4 py-2.5 text-sm text-[var(--text-primary)] bg-[var(--bg-secondary)] border border-[var(--glass-border)] rounded focus:outline-none focus:border-[var(--color-brand-blue)] transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[var(--text-secondary)] mb-1.5">Coupon Code (Optional)</label>
                  <input 
                    type="text" 
                    value={coupon}
                    onChange={(e) => setCoupon(e.target.value)}
                    className="w-full px-4 py-2.5 text-sm text-[var(--text-primary)] bg-[var(--bg-secondary)] border border-[var(--glass-border)] rounded focus:outline-none focus:border-[var(--color-brand-blue)] transition-colors uppercase font-mono"
                    placeholder="e.g. SNOVA-100"
                  />
                </div>

                {error && <p className="text-red-400 text-xs mt-1">{error}</p>}
                
                <div className="pt-2">
                  <button 
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 bg-[var(--color-brand-blue)] hover:bg-[var(--color-brand-blue-alt)] text-white font-medium text-sm rounded transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <span className="flex items-center gap-2">
                        <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Processing
                      </span>
                    ) : 'Complete Registration'}
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RegistrationModal;
