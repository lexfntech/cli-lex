import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  FiSearch,
  FiCheck,
  FiX,
  FiCalendar,
  FiUser,
  FiMail,
  FiPhone,
  FiTag,
  FiTrendingUp,
  FiUsers,
} from "react-icons/fi";
import type { AppDispatch, RootState } from "../store";
import {
  fetchRegistrations,
  approveRegistration,
  rejectRegistration,
  type Registration,
} from "../store/registrationSlice";
import { fetchInfluencers } from "../store/influencerSlice";

type StatusFilter = "all" | "pending" | "approved" | "rejected";

interface RegistrationManagementProps {
  initialStatusFilter?: StatusFilter;
  title?: string;
  subtitle?: string;
  hideStatusTabs?: boolean;
}

const RegistrationManagement = ({
  initialStatusFilter = "pending",
  title = "Registration Management",
  subtitle = "Review and process course registration requests",
  hideStatusTabs = false,
}: RegistrationManagementProps) => {
  const dispatch = useDispatch<AppDispatch>();
  const { registrations, loading, error } = useSelector(
    (state: RootState) => state.registration,
  );
  const { influencers } = useSelector((state: RootState) => state.influencer);

  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] =
    useState<StatusFilter>(initialStatusFilter);
  const [selectedReg, setSelectedReg] = useState<Registration | null>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showApproveModal, setShowApproveModal] = useState(false);
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [revenueAmount, setRevenueAmount] = useState("");
  const [rejectionReason, setRejectionReason] = useState("");

  useEffect(() => {
    setStatusFilter(initialStatusFilter);
  }, [initialStatusFilter]);

  useEffect(() => {
    dispatch(
      fetchRegistrations({
        status: statusFilter === "all" ? undefined : statusFilter,
      }),
    );
    dispatch(fetchInfluencers({}));
  }, [dispatch, statusFilter]);

  const filteredRegistrations = registrations.filter(
    (reg) =>
      reg.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      reg.userEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
      reg.courseName.toLowerCase().includes(searchQuery.toLowerCase()),
  );

  const getInfluencerById = (id: string | null) => {
    if (!id) return null;
    return influencers.find((inf) => inf.id === id);
  };

  const handleApprove = async () => {
    if (!selectedReg) return;

    try {
      const revenue = revenueAmount ? parseFloat(revenueAmount) : 0;
      await dispatch(
        approveRegistration({ id: selectedReg.id, revenueAmount: revenue }),
      ).unwrap();
      setShowApproveModal(false);
      setSelectedReg(null);
      setRevenueAmount("");
    } catch (err) {
      console.error("Failed to approve registration:", err);
    }
  };

  const handleReject = async () => {
    if (!selectedReg) return;

    try {
      await dispatch(
        rejectRegistration({ id: selectedReg.id, reason: rejectionReason }),
      ).unwrap();
      setShowRejectModal(false);
      setSelectedReg(null);
      setRejectionReason("");
    } catch (err) {
      console.error("Failed to reject registration:", err);
    }
  };

  const openDetailsModal = (registration: Registration) => {
    setSelectedReg(registration);
    setShowDetailsModal(true);
  };

  const openApproveModal = (registration: Registration) => {
    setSelectedReg(registration);
    setRevenueAmount(registration.coursePrice?.toString() || "0");
    setShowApproveModal(true);
  };

  const openRejectModal = (registration: Registration) => {
    setSelectedReg(registration);
    setShowRejectModal(true);
  };

  return (
    <div className="text-slate-200">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-lg font-black tracking-tight mb-1 text-white uppercase">{title}</h2>
          <p className="text-slate-400 text-xs font-medium">{subtitle}</p>
        </div>
      </div>

      {!hideStatusTabs ? (
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search registrations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/2 border border-white/5 rounded-xl py-2.5 pl-11 pr-4 text-xs text-white focus:outline-none focus:border-white/10 transition-all placeholder:text-slate-500"
            />
          </div>

          <div className="flex gap-2 flex-wrap">
            {(["all", "pending", "approved", "rejected"] as StatusFilter[]).map(
              (status) => (
                <button
                  key={status}
                  onClick={() => setStatusFilter(status)}
                  className={`px-4 py-2 rounded-xl text-[10px] font-bold tracking-widest uppercase transition-colors cursor-pointer ${
                    statusFilter === status
                      ? "bg-white text-black border border-white"
                      : "bg-white/2 border border-white/5 text-slate-400 hover:bg-white/4"
                  }`}
                >
                  {status}
                </button>
              ),
            )}
          </div>
        </div>
      ) : (
        <div className="mb-6">
          <div className="relative w-full md:w-96">
            <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search registrations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/2 border border-white/5 rounded-xl py-2.5 pl-11 pr-4 text-xs text-white focus:outline-none focus:border-white/10 transition-all placeholder:text-slate-500"
            />
          </div>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="bg-rose-500/10 border border-rose-500/20 rounded-xl p-4 mb-6 text-rose-400 text-xs">
          {error}
        </div>
      )}

      {/* Loading State */}
      {loading && (
        <div className="flex justify-center items-center py-12">
          <div className="w-8 h-8 border-2 border-[var(--color-brand-blue)] border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}

      {/* Registration Cards */}
      {!loading && (
        <div className="space-y-4">
          {filteredRegistrations.length > 0 ? (
            filteredRegistrations.map((reg) => {
              const influencer = getInfluencerById(reg.influencerId);
              return (
                <div key={reg.id} className="border border-white/5 bg-[#0c0c0c] rounded-xl p-5 hover:border-white/10 transition-colors">
                  <div className="flex flex-col md:flex-row gap-6">
                    {/* Main Info */}
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[9px] font-bold tracking-wider uppercase border ${
                            reg.status === "pending"
                              ? "bg-amber-500/10 text-amber-400 border-amber-500/20"
                              : reg.status === "approved"
                                ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                                : "bg-rose-500/10 text-rose-400 border-rose-500/20"
                          }`}
                        >
                          {reg.status}
                        </span>
                        <span className="text-[9px] font-mono text-slate-500 flex items-center gap-2">
                          <FiCalendar />{" "}
                          {new Date(reg.registeredAt).toLocaleDateString()}
                        </span>
                      </div>

                      <h3 className="text-sm font-bold text-white mb-2">
                        {reg.courseName}
                      </h3>

                      <div className="space-y-1.5 text-xs text-slate-400">
                        <div className="flex items-center gap-2">
                          <FiUser className="text-slate-500" />
                          <span className="font-bold text-slate-200 text-xs">
                            {reg.userName}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[11px]">
                          <FiMail className="text-slate-500" />
                          <span>{reg.userEmail}</span>
                        </div>
                        {reg.userPhone && (
                          <div className="flex items-center gap-2 text-[11px]">
                            <FiPhone className="text-slate-500" />
                            <span>{reg.userPhone}</span>
                          </div>
                        )}
                      </div>

                      {influencer && (
                        <div className="mt-3 p-3 bg-white/2 border border-white/5 rounded-xl">
                          <div className="flex items-center gap-2 text-[11px]">
                            <FiTrendingUp className="text-[var(--color-icy-cyan)]" />
                            <span className="text-slate-400">
                              Referred by:
                            </span>
                            <span className="font-bold text-slate-200">
                              {influencer.name}
                            </span>
                            <code className="ml-auto px-2 py-0.5 bg-[#121212] border border-white/5 rounded text-[10px] font-mono text-[var(--color-icy-cyan)] font-bold">
                              {reg.referralCode}
                            </code>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Coupon & Actions */}
                    <div className="flex flex-col justify-between items-end gap-4">
                      {reg.couponUsed && (
                        <div className="bg-white/2 p-3 rounded-xl border border-white/5 min-w-36 text-right">
                          <p className="text-[8px] font-mono uppercase tracking-widest text-slate-500 mb-0.5">
                            Promo Key
                          </p>
                          <div className="flex items-center justify-end gap-1">
                            <FiTag className="text-[var(--color-icy-cyan)] text-xs" />
                            <span className="text-xs font-bold font-mono text-white">
                              {reg.couponUsed}
                            </span>
                          </div>
                        </div>
                      )}

                      <div className="flex flex-col sm:flex-row gap-2 mt-auto">
                        <button
                          onClick={() => openDetailsModal(reg)}
                          className="px-3.5 py-2 bg-white/2 hover:bg-white/5 border border-white/5 text-slate-300 rounded-xl text-[10px] font-bold tracking-wider uppercase transition-colors cursor-pointer"
                        >
                          Details
                        </button>

                        {reg.status === "pending" && (
                          <>
                            <button
                              onClick={() => openApproveModal(reg)}
                              className="flex items-center justify-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-[10px] font-bold tracking-wider uppercase transition-colors shadow-md shadow-emerald-500/10 cursor-pointer"
                            >
                              <FiCheck /> Approve
                            </button>
                            <button
                              onClick={() => openRejectModal(reg)}
                              className="flex items-center justify-center gap-1.5 px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-[10px] font-bold tracking-wider uppercase transition-colors shadow-md shadow-rose-500/10 cursor-pointer"
                            >
                              <FiX /> Reject
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="border border-white/5 bg-[#0c0c0c] rounded-xl py-16 text-center">
              <FiUsers className="text-3xl text-slate-600 mb-3 mx-auto opacity-55" />
              <p className="text-slate-500 text-xs font-medium">
                No registration requests found in database.
              </p>
            </div>
          )}
        </div>
      )}

      {/* Details Modal */}
      {showDetailsModal && selectedReg && (
        <Modal
          title="Registration Details"
          onClose={() => {
            setShowDetailsModal(false);
            setSelectedReg(null);
          }}
        >
          <div className="space-y-3">
            <DetailRow label="Student Name" value={selectedReg.userName} />
            <DetailRow label="Email Address" value={selectedReg.userEmail} />
            {selectedReg.userPhone && (
              <DetailRow label="Phone Number" value={selectedReg.userPhone} />
            )}
            <DetailRow label="Learning Path" value={selectedReg.courseName} />
            {selectedReg.coursePrice > 0 && (
              <DetailRow
                label="Path Price"
                value={`₹${selectedReg.coursePrice}`}
              />
            )}
            {selectedReg.couponUsed && (
              <DetailRow label="Coupon Code" value={selectedReg.couponUsed} />
            )}
            {selectedReg.referralCode && (
              <DetailRow
                label="Referral Code"
                value={selectedReg.referralCode}
              />
            )}
            {selectedReg.influencerId &&
              (() => {
                const inf = getInfluencerById(selectedReg.influencerId);
                return inf ? (
                  <DetailRow label="Influencer" value={inf.name} />
                ) : null;
              })()}
            <DetailRow label="Status" value={selectedReg.status} />
            <DetailRow
              label="Registered At"
              value={new Date(selectedReg.registeredAt).toLocaleString()}
            />
            {selectedReg.approvedAt && (
              <DetailRow
                label="Approved At"
                value={new Date(selectedReg.approvedAt).toLocaleString()}
              />
            )}
            {selectedReg.rejectedAt && (
              <DetailRow
                label="Rejected At"
                value={new Date(selectedReg.rejectedAt).toLocaleString()}
              />
            )}
            {selectedReg.rejectionReason && (
              <DetailRow
                label="Rejection Reason"
                value={selectedReg.rejectionReason}
              />
            )}
          </div>
        </Modal>
      )}

      {/* Approve Modal */}
      {showApproveModal && selectedReg && (
        <Modal
          title="Approve Registration"
          onClose={() => {
            setShowApproveModal(false);
            setSelectedReg(null);
            setRevenueAmount("");
          }}
        >
          <div className="space-y-4">
            <p className="text-xs text-slate-400">
              Approve access credentials for student{" "}
              <strong className="text-white">
                {selectedReg.userName}
              </strong>
              ?
            </p>

            {selectedReg.influencerId && (
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-505 mb-2 font-mono">
                  Settle Earning Amount (for influencer logs)
                </label>
                <input
                  type="number"
                  step="1"
                  min="0"
                  value={revenueAmount}
                  onChange={(e) => setRevenueAmount(e.target.value)}
                  className="w-full bg-[#121212] border border-white/5 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-white/10"
                  placeholder="0"
                />
              </div>
            )}

            <div className="flex gap-3 pt-4 border-t border-white/5">
              <button
                onClick={() => {
                  setShowApproveModal(false);
                  setSelectedReg(null);
                  setRevenueAmount("");
                }}
                className="flex-1 px-4 py-2.5 bg-white/2 hover:bg-white/5 border border-white/5 text-slate-300 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleApprove}
                className="flex-1 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
              >
                Approve Student
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Reject Modal */}
      {showRejectModal && selectedReg && (
        <Modal
          title="Reject Registration"
          onClose={() => {
            setShowRejectModal(false);
            setSelectedReg(null);
            setRejectionReason("");
          }}
        >
          <div className="space-y-4">
            <p className="text-xs text-slate-400">
              Decline access credentials for student{" "}
              <strong className="text-white">
                {selectedReg.userName}
              </strong>
              ?
            </p>

            <div>
              <label className="block text-[9px] font-bold uppercase tracking-wider text-slate-500 mb-2 font-mono">
                Rejection Reason (Log details)
              </label>
              <textarea
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                rows={3}
                className="w-full bg-[#121212] border border-white/5 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-white/10 resize-none placeholder:text-slate-500"
                placeholder="Provide details for log reports..."
              />
            </div>

            <div className="flex gap-3 pt-4 border-t border-white/5">
              <button
                onClick={() => {
                  setShowRejectModal(false);
                  setSelectedReg(null);
                  setRejectionReason("");
                }}
                className="flex-1 px-4 py-2.5 bg-white/2 hover:bg-white/5 border border-white/5 text-slate-300 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleReject}
                className="flex-1 px-4 py-2.5 bg-red-650 hover:bg-red-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
              >
                Reject Request
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

// Modal Component
const Modal = ({
  title,
  children,
  onClose,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      ></div>
      <div className="relative w-full max-w-md border border-white/5 bg-[#0a0a0a] rounded-2xl shadow-2xl p-6">
        <div className="flex items-center justify-between mb-5 border-b border-white/5 pb-3">
          <h3 className="text-xs font-black text-white uppercase tracking-widest font-mono">{title}</h3>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/5 rounded transition-colors text-slate-400 hover:text-white cursor-pointer"
          >
            <FiX className="text-base" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
};

// Detail Row Component
const DetailRow = ({ label, value }: { label: string; value: string }) => {
  return (
    <div className="flex justify-between items-start gap-4 py-2.5 border-b border-white/3 text-xs">
      <span className="text-[8px] font-bold text-slate-500 uppercase tracking-widest font-mono">
        {label}
      </span>
      <span className="text-xs text-slate-200 font-semibold text-right">
        {value}
      </span>
    </div>
  );
};

export default RegistrationManagement;
