import React from 'react';

interface SecuritySectionProps {
  onAccessClick: () => void;
  onScrollTo: (id: string) => void;
}

export const SecuritySection: React.FC<SecuritySectionProps> = ({
  onAccessClick,
  onScrollTo,
}) => {
  return (
    <section id="labs" className="relative min-h-[600px] py-16 sm:py-24 w-full overflow-hidden bg-black flex flex-col items-center justify-center border-t border-white/5 cyber-grid">
      {/* Background Video */}
      <video 
        src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260421_072418_508a7d2e-396d-4f6f-9d42-ec920fcf7755.mp4"
        autoPlay 
        loop 
        muted 
        playsInline 
        className="absolute inset-0 w-full h-full object-cover opacity-[0.25] pointer-events-none z-0"
      />

      {/* Top/Bottom Fade */}
      <div className="pointer-events-none absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-black to-transparent z-10" />
      <div className="pointer-events-none absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent z-10" />

      {/* Inner Content Wrapper */}
      <div className="relative h-full w-full max-w-[1320px] mx-auto z-10 px-4 sm:px-6 md:px-10 flex flex-col items-center">
        
        {/* Floating center pill (HUD Controller Widget) */}
        <div className="mb-16 bg-neutral-900/80 backdrop-blur rounded-full p-2 sm:p-2.5 flex items-center gap-2 border border-white/5 shadow-2xl shadow-black">
          <button 
            onClick={onAccessClick}
            className="text-white/80 hover:text-white text-xs px-4 sm:px-6 py-2 sm:py-2.5 rounded-full hover:bg-white/5 transition-all font-mono uppercase tracking-wider"
          >
            confirm identity
          </button>
          <button 
            onClick={() => onScrollTo('programs')}
            className="text-black text-xs px-4 sm:px-6 py-2 sm:py-2.5 rounded-full font-semibold transition-all hover:scale-105 active:scale-95 uppercase tracking-wider font-mono"
            style={{ background: 'linear-gradient(90deg, #FA8453 0%, #F8C9B2 100%)' }}
          >
            run free lab
          </button>
        </div>

        {/* Structured 2-Column Console Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch w-full">
          
          {/* Left Column: Mock Security Operations Center (SOC) Terminal */}
          <div className="lg:col-span-5 bezel-outer bg-neutral-950/40 backdrop-blur-md">
            <div className="bezel-inner p-6 h-full flex flex-col justify-between bg-black/60 border border-white/5 scanlines min-h-[300px]">
              
              {/* Terminal Titlebar */}
              <div className="flex justify-between items-center border-b border-white/10 pb-3 font-mono text-[10px] text-neutral-500">
                <span>[ TERMINAL // SCANNER_LOGS ]</span>
                <span className="flex items-center gap-1.5 text-green-500">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                  ONLINE
                </span>
              </div>

              {/* Terminal Code Outputs */}
              <div className="flex-1 font-mono text-[11px] text-green-400 py-4 flex flex-col gap-2 select-none leading-relaxed">
                <div>&gt;&gt; initializing port vulnerability scan...</div>
                <div>&gt;&gt; target gateway: <span className="text-white">198.51.100.83</span></div>
                <div>&gt;&gt; detecting exposed services...</div>
                <div className="text-amber-500 animate-pulse">&gt;&gt; [!] alert: port 8080 open - CVE-2026-1029</div>
                <div>&gt;&gt; injecting active payload barriers...</div>
                <div>&gt;&gt; obfuscation protocols: <span className="text-[#70D0FF]">ACTIVE</span></div>
                <div>&gt;&gt; local defensive shield: <span className="text-[#FA8453]">ENGAGED</span></div>
              </div>

              {/* Terminal Footing */}
              <div className="border-t border-white/5 pt-3 flex justify-between font-mono text-[9px] text-neutral-500">
                <span>SYS_VOL: 100%</span>
                <span>SEC_GRADE: A+</span>
              </div>

            </div>
          </div>

          {/* Right Column: Briefing Copy Panel */}
          <div className="lg:col-span-7 flex flex-col justify-center gap-6">
            <div className="flex items-center gap-3 select-none">
              <span className="h-px w-8 bg-[#FA8453]"></span>
              <span className="text-xs font-mono text-[#FA8453] uppercase tracking-[0.2em] font-semibold">Security Briefing</span>
            </div>
            
            <h3 className="text-2xl sm:text-4xl font-bold tracking-tight text-white leading-tight">
              Shielding users info with premier tech, granting them with safety in all place.
            </h3>

            <p className="text-neutral-400 text-sm sm:text-base leading-relaxed font-light font-sans">
              By teaming up with a defender service, a business can dramatically improve the safeguard of its important info. This covers applying strong obfuscation protocols, gateway barriers, and observation engines to shield against unauthorized entries, info escapes, and malicious cyberhacks.
            </p>
          </div>

        </div>

      </div>
    </section>
  );
};
