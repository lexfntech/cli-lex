import React from 'react';
import type { Course } from '../store/courseSlice';
import { FiArrowRight, FiArrowUpRight, FiTerminal } from 'react-icons/fi';

interface ProgramsSectionProps {
  user: any;
  course: Course | null;
  selectedCourse: string | null;
  setSelectedCourse: React.Dispatch<React.SetStateAction<string | null>>;
  onAccessClick: () => void;
  onCourseRegisterClick: () => void;
  onModuleClick: (moduleId: string) => void;
}

// Custom mock difficulty levels & tools mapping to make the syllabus look highly specific and professional
const MODULE_TACTICAL_META: Record<string, { diff: string, color: string, tools: string[] }> = {
  'mod_1': { diff: 'INTRO', color: 'text-green-400 border-green-500/20 bg-green-500/5', tools: ['CLI', 'SSH', 'Linux'] },
  'mod_2': { diff: 'EASY', color: 'text-green-400 border-green-500/20 bg-green-500/5', tools: ['Nmap', 'Wireshark'] },
  'mod_3': { diff: 'MEDIUM', color: 'text-cyan-400 border-cyan-500/20 bg-cyan-500/5', tools: ['Burp Suite', 'OWASP'] },
  'mod_4': { diff: 'MEDIUM', color: 'text-cyan-400 border-cyan-500/20 bg-cyan-500/5', tools: ['Metasploit', 'Payloads'] },
  'mod_5': { diff: 'HARD', color: 'text-amber-500 border-amber-500/20 bg-amber-500/5', tools: ['GDB', 'Buffer Overflow'] },
  'mod_6': { diff: 'EXPERT', color: 'text-[#FA8453] border-[#FA8453]/20 bg-[#FA8453]/5', tools: ['Active Directory', 'BloodHound'] },
  'mod_7': { diff: 'HARD', color: 'text-amber-500 border-amber-500/20 bg-amber-500/5', tools: ['SQLi', 'XSS', 'IDOR'] },
  'mod_8': { diff: 'EXPERT', color: 'text-[#FA8453] border-[#FA8453]/20 bg-[#FA8453]/5', tools: ['Cobalt Strike', 'C2'] },
  'mod_9': { diff: 'HARD', color: 'text-amber-500 border-amber-500/20 bg-amber-500/5', tools: ['PE Format', 'IDA Pro'] },
  'mod_10': { diff: 'EXPERT', color: 'text-[#FA8453] border-[#FA8453]/20 bg-[#FA8453]/5', tools: ['YARA', 'Wireshark', 'Sysmon'] },
  'mod_11': { diff: 'MEDIUM', color: 'text-cyan-400 border-cyan-500/20 bg-cyan-500/5', tools: ['Cryptography', 'Ciphers'] },
  'mod_12': { diff: 'EXPERT', color: 'text-[#FA8453] border-[#FA8453]/20 bg-[#FA8453]/5', tools: ['Pentest Report', 'SLA'] },
};

export const ProgramsSection: React.FC<ProgramsSectionProps> = ({
  user,
  course,
  selectedCourse,
  setSelectedCourse,
  onAccessClick,
  onCourseRegisterClick,
  onModuleClick,
}) => {
  return (
    <section id="programs" className="relative w-full bg-black px-4 sm:px-6 md:px-10 py-16 sm:py-24 border-t border-white/5 cyber-grid">
      <div className="max-w-[1320px] mx-auto">
        
        {/* Section Heading Tag */}
        <div className="flex flex-col items-center text-center mb-16 sm:mb-20 select-none">
          <div className="text-[10px] font-mono tracking-[0.2em] uppercase text-[#FA8453] mb-3">TRAINING ARCHITECTURE</div>
          <h2 className="text-4xl md:text-6xl font-bold tracking-tighter text-white">Available Sectors</h2>
        </div>

        {/* Grid utilizing items-stretch for equal heights */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          
          {/* Flagship Program Command Box */}
          <div className="lg:col-span-2 bezel-outer bg-neutral-950/60 shadow-xl shadow-black relative overflow-hidden group hover:border-[#FA8453]/20 transition-all duration-500 h-full">
            
            <div className="bezel-inner p-8 sm:p-10 bg-neutral-950/60 border border-white/5 flex flex-col justify-between h-full cyber-grid scanlines scanline-sweep relative">
              <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-[#FA8453]/5 rounded-full blur-[80px] pointer-events-none" />
              
              <div className="relative z-10 flex flex-col h-full justify-between">
                <div>
                  <div className="flex justify-between items-center mb-6 font-mono text-[9px] sm:text-[10px] select-none text-neutral-500">
                    <div className="text-[#FA8453] font-bold tracking-[0.15em] uppercase flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#FA8453] animate-pulse"></span>
                      [ SECTOR // FLAGSHIP ]
                    </div>
                    <div className="flex items-center gap-3">
                      <span>[ LEVEL: BEG_TO_PRO ]</span>
                      <span>[ DURATION: 12_WEEKS ]</span>
                    </div>
                  </div>

                  <h3 className="text-3xl sm:text-4xl font-bold leading-[1.1] tracking-tight text-white mb-4">
                    Cyber Security Mastery
                  </h3>
                  <p className="text-neutral-400 text-sm sm:text-base max-w-xl mb-8 leading-relaxed font-sans font-light">
                    From basic networking protocols to advanced active directory exploitation. A complete, hand-on, lab-driven journey. Register to access detailed syllabus and interactive challenges.
                  </p>

                  <div className="flex items-center gap-4 flex-wrap pb-6 border-b border-white/5 mb-6">
                    <button
                      onClick={() => setSelectedCourse(prev => prev === 'course_1' ? null : 'course_1')}
                      className="px-6 py-2.5 rounded-full border border-white/10 hover:border-white/30 text-white text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-2 transition-all hover:bg-white/5 active:scale-95"
                    >
                      {selectedCourse === 'course_1' ? '[ CLOSE DATA DRAWER ]' : '[ DECRYPT SYLLABUS ]'}
                      <FiArrowRight className={`text-sm transition-transform duration-300 ${selectedCourse === 'course_1' ? 'rotate-90' : ''}`} />
                    </button>

                    {user && (
                      <button
                        onClick={onCourseRegisterClick}
                        className="px-6 py-2.5 rounded-full bg-white hover:bg-neutral-200 text-black text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-2 transition-all active:scale-95 shadow-lg shadow-white/5"
                      >
                        [ ENROLL IN SECTOR ]
                      </button>
                    )}
                  </div>
                </div>

                {/* Modules Expandable Drawer (Roadmap list styled as missions) */}
                {selectedCourse === 'course_1' && (
                  <div className="mt-4 transition-all duration-700">
                    {course ? (
                      <div className="flex flex-col gap-4 relative z-10">
                        {course.modules.map((mod) => {
                          const [modLabel, modTitle] = mod.title.split('—');
                          const meta = MODULE_TACTICAL_META[mod.id] || { diff: 'N/A', color: 'text-neutral-400 border-white/10 bg-neutral-900/40', tools: [] };
                          
                          return (
                            <div
                              key={mod.id}
                              onClick={() => onModuleClick(mod.id)}
                              className="group/mod p-5 border border-white/5 bg-neutral-900/30 hover:bg-neutral-900/80 rounded-xl transition-all cursor-pointer flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:border-[#FA8453]/30"
                            >
                              <div className="flex items-start gap-4">
                                {/* Mission Label */}
                                <div className="hidden sm:block text-[9px] font-mono tracking-widest text-[#FA8453] uppercase bg-[#FA8453]/5 border border-[#FA8453]/20 px-2.5 py-1 rounded">
                                  {modLabel.trim()}
                                </div>
                                <div>
                                  <h4 className="text-base font-bold text-white group-hover/mod:text-[#FA8453] transition-colors leading-tight mb-2">
                                    {modTitle ? modTitle.trim() : mod.title}
                                  </h4>
                                  
                                  {/* Tools Badges */}
                                  <div className="flex items-center gap-2 flex-wrap select-none">
                                    {meta.tools.map((t) => (
                                      <span key={t} className="text-[9px] font-mono text-neutral-500 bg-neutral-950 px-2 py-0.5 rounded border border-white/5">
                                        #{t.toLowerCase()}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              </div>
                              
                              <div className="flex items-center gap-3 self-stretch md:self-auto justify-between border-t border-white/5 pt-3 md:pt-0 md:border-0 select-none">
                                {/* Difficulty Tag */}
                                <span className={`text-[8px] font-mono px-2 py-0.5 border rounded uppercase ${meta.color}`}>
                                  {meta.diff}
                                </span>
                                <FiArrowUpRight className="text-lg text-neutral-500 group-hover/mod:text-white transform group-hover/mod:translate-x-0.5 group-hover/mod:-translate-y-0.5 transition-all" />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="text-neutral-500 font-mono text-xs tracking-widest uppercase text-center py-6">
                        Initializing diagnostic syllabus...
                      </div>
                    )}
                    
                    {!user && (
                      <div className="mt-8 flex justify-center border-t border-white/5 pt-8">
                        <button 
                          onClick={onAccessClick}
                          className="flex items-center gap-2 px-6 py-3 bg-white hover:bg-neutral-200 text-black text-xs font-mono font-bold uppercase tracking-widest rounded-full transition-all active:scale-95 shadow-lg shadow-white/5"
                        >
                          [ unlock full operations console ] <FiTerminal />
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

          </div>

          {/* Secondary Program Command Box (Stretched to match heights) */}
          <div className="bezel-outer bg-neutral-950/60 shadow-xl shadow-black relative overflow-hidden group hover:border-[#70D0FF]/20 transition-all duration-500 h-full">
            <div className="bezel-inner p-8 sm:p-10 bg-neutral-950/60 border border-white/5 flex flex-col justify-between h-full cyber-grid relative">
              <div className="absolute bottom-0 right-0 w-[250px] h-[250px] bg-[#70D0FF]/5 rounded-full blur-[70px] pointer-events-none" />
              
              <div className="relative z-10 flex flex-col h-full justify-between gap-6">
                <div>
                  <div className="flex justify-between items-center mb-6 font-mono text-[9px] sm:text-[10px] select-none text-neutral-500">
                    <span>[ SECTOR // RESEARCH ]</span>
                    <span className="flex items-center gap-1.5 text-red-500 font-bold">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500"></span>
                      [ LOCKED ]
                    </span>
                  </div>

                  <h3 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-4">
                    Advanced Pentesting
                  </h3>
                  <p className="text-neutral-500 text-sm leading-relaxed mb-6 font-sans font-light">
                    Deep dive into zero-day research, exploit development, kernel exploitation, and high-security enterprise directory bypasses.
                  </p>
                </div>
                
                {/* Immersive encrypted clearance notice */}
                <div className="border-t border-white/5 pt-6 mt-6 select-none relative z-10 text-center font-mono">
                  <div className="text-[#FA8453]/60 text-[9px] sm:text-[10px] tracking-wider uppercase bg-[#FA8453]/5 border border-[#FA8453]/20 py-2.5 px-4 rounded-xl">
                    [ ACCESS_STATUS: ENCRYPTED // REQUIRES SECTOR_1_CLEARANCE ]
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
