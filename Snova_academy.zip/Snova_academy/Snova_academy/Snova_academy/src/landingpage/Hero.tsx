import React from 'react';

interface HeroProps {
  user: any;
  onAccessClick: () => void;
  onScrollTo: (id: string) => void;
  onDashboardClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  user,
  onAccessClick,
  onScrollTo,
  onDashboardClick,
}) => {
  return (
    <section className="relative min-h-screen w-full bg-black overflow-hidden flex items-center justify-center pt-24 pb-12 cyber-grid">
      {/* Background Video */}
      <video 
        src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260421_074215_f4339e1c-0b1a-4f60-98b2-90e3d7840cb7.mp4"
        autoPlay 
        loop 
        muted 
        playsInline 
        className="absolute inset-0 w-full h-full object-cover opacity-[0.25] pointer-events-none z-0"
      />

      {/* Outlined Background Typography (Framing bounds) */}
      <div className="absolute inset-0 w-full h-full z-0 overflow-hidden select-none pointer-events-none">
        <span className="hero-title text-outline absolute left-[3%] top-[16%] text-white opacity-[0.03] font-medium text-[16vw] uppercase tracking-tighter">
          train
        </span>
        <span className="hero-title text-outline absolute right-[3%] top-[45%] text-white opacity-[0.03] font-medium text-[16vw] uppercase tracking-tighter">
          secure
        </span>
        <span className="hero-title text-outline absolute left-[12%] bottom-[8%] text-white opacity-[0.03] font-medium text-[16vw] uppercase tracking-tighter">
          master
        </span>
      </div>

      {/* Operations Command Card (Double-Bezel Instrument Container) */}
      <div className="relative z-10 w-[95%] sm:w-[90%] max-w-4xl mx-auto bezel-outer bg-neutral-950/20 shadow-2xl shadow-black/80">
        <div className="bezel-inner p-6 sm:p-12 md:p-16 bg-neutral-950/60 backdrop-blur-xl border border-white/5 flex flex-col items-center scanlines scanline-sweep">
          
          {/* Diagnostic status tag */}
          <div className="mb-6 px-4 py-1.5 rounded bg-neutral-900/95 border border-[#70D0FF]/20 text-[#70D0FF] text-[9px] sm:text-[10px] font-mono tracking-[0.25em] uppercase flex items-center gap-2 select-none shadow-inner shadow-black">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
            [ sec_operations // sys_active ]
          </div>

          {/* Headline */}
          <h1 className="text-3xl sm:text-5xl md:text-6xl font-bold tracking-tight text-white mb-6 leading-[1.15] text-center max-w-3xl font-sans">
            Train Like a <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FA8453] via-[#F8C9B2] to-white font-mono font-extrabold">[Security Professional]</span>
          </h1>

          {/* Subheadline */}
          <p className="text-neutral-200 text-xs sm:text-sm md:text-base leading-relaxed max-w-2xl text-center mb-4 font-light font-sans">
            Master cyber security through practical learning, real-world attack simulations, and structured training programs designed for aspiring security analysts, ethical hackers, and bug bounty hunters.
          </p>

          {/* Description */}
          <p className="text-neutral-500 text-[11px] sm:text-xs leading-relaxed max-w-xl text-center mb-10 font-light font-sans">
            From foundational concepts to advanced vulnerability assessment techniques, Snova Academy provides a focused learning environment where students gain practical experience instead of just theoretical knowledge.
          </p>

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto mb-10 relative z-20">
            {user ? (
              <button
                onClick={onDashboardClick}
                className="w-full sm:w-auto bg-white hover:bg-neutral-200 text-black text-xs font-mono font-semibold uppercase tracking-wider px-8 py-3.5 rounded-full transition-all hover:shadow-[0_0_20px_rgba(255,255,255,0.25)] hover:scale-[1.02] active:scale-[0.98]"
              >
                [ GO TO DASHBOARD ]
              </button>
            ) : (
              <div 
                onClick={onAccessClick}
                className="relative rounded-full p-[1.5px] cursor-pointer group hover:scale-[1.02] active:scale-[0.98] transition-all w-full sm:w-auto shadow-[0_0_15px_rgba(250,132,83,0.06)] hover:shadow-[0_0_25px_rgba(250,132,83,0.18)]"
                style={{ background: 'linear-gradient(90deg, #FA8453 0%, #F8C9B2 100%)' }}
              >
                <div className="rounded-full bg-black px-8 py-3.5 text-white text-xs font-mono tracking-widest uppercase font-semibold text-center transition-colors hover:bg-neutral-900">
                  [ start learning ]
                </div>
              </div>
            )}
            
            <button
              onClick={() => onScrollTo('programs')}
              className="w-full sm:w-auto bg-transparent border border-white/10 hover:border-white/30 hover:bg-white/5 text-white text-xs font-mono font-semibold uppercase tracking-wider px-8 py-3.5 rounded-full transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              [ Browse Courses ]
            </button>
          </div>

          {/* Stats HUD Readout Row */}
          <div className="grid grid-cols-3 gap-2 sm:gap-6 border-t border-white/5 pt-8 w-full text-center select-none font-mono">
            <div className="flex flex-col items-center border-r border-white/5">
              <span className="text-lg sm:text-2xl text-[#70D0FF] font-medium">+2.7b</span>
              <span className="text-[8px] sm:text-[9px] text-neutral-500 uppercase tracking-widest mt-1">concealed info</span>
            </div>
            <div className="flex flex-col items-center border-r border-white/5">
              <span className="text-lg sm:text-2xl text-white font-medium">+90k</span>
              <span className="text-[8px] sm:text-[9px] text-neutral-500 uppercase tracking-widest mt-1">ventures run</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-lg sm:text-2xl text-[#FA8453] font-medium">+450k</span>
              <span className="text-[8px] sm:text-[9px] text-neutral-500 uppercase tracking-widest mt-1">transfers</span>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
