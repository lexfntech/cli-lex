import React, { useState } from 'react';
import { type User } from 'firebase/auth';
import { FiLogOut, FiMenu, FiX } from 'react-icons/fi';

const LogoMark = () => (
  <svg viewBox="0 0 256 256" className="h-4 w-4 fill-current text-[#70D0FF]" xmlns="http://www.w3.org/2000/svg">
    <path d="M 128 192 L 128 256 L 64.5 256 L 32 223 L 0 192 L 0 128 L 64 128 Z M 256 192 L 256 256 L 192.5 256 L 160 223 L 128 192 L 128 128 L 192 128 Z M 128 64 L 128 128 L 64.5 128 L 32 95 L 0 64 L 0 0 L 64 0 Z M 256 64 L 256 128 L 192.5 128 L 160 95 L 128 64 L 128 0 L 192 0 Z" />
  </svg>
);

interface NavbarProps {
  user: User | null;
  onAccessClick: () => void;
  onScrollTo: (id: string) => void;
  onSignOut: () => void;
  onDashboardClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  onAccessClick,
  onScrollTo,
  onSignOut,
  onDashboardClick,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (id: string) => {
    onScrollTo(id);
    setMobileMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 px-4 sm:px-6 md:px-10 pt-4 sm:pt-6">
      <div className="max-w-[1320px] mx-auto flex items-center justify-between">
        {/* Left Pill (Branding HUD) */}
        <div 
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="bg-black/60 backdrop-blur rounded-full pl-3 pr-4 sm:pl-4 sm:pr-6 py-2 sm:py-2.5 flex items-center gap-2.5 cursor-pointer border border-[#70D0FF]/20 hover:border-[#70D0FF]/40 shadow-[0_0_15px_rgba(112,208,255,0.08)] hover:shadow-[0_0_20px_rgba(112,208,255,0.15)] transition-all group"
        >
          <div className="w-6 h-6 rounded-full bg-neutral-900 border border-white/10 flex items-center justify-center group-hover:rotate-90 transition-transform duration-500">
            <LogoMark />
          </div>
          <span className="text-[#70D0FF] text-[10px] sm:text-xs font-bold tracking-[0.2em] uppercase font-mono">snova // lab</span>
        </div>

        {/* Center Pill (HUD Navigation) */}
        <div className="hidden md:flex bg-neutral-950/80 backdrop-blur rounded-full px-2 py-1.5 border border-white/5 shadow-lg shadow-black/80">
          {['programs', 'labs', 'mission', 'contact'].map((item) => (
            <button
              key={item}
              onClick={() => handleNavClick(item)}
              className="text-neutral-400 hover:text-white text-xs font-mono font-medium px-4 py-2 rounded-full transition-all relative group"
            >
              <span className="opacity-0 group-hover:opacity-100 text-[#70D0FF] mr-1 transition-opacity duration-300 font-mono">[</span>
              <span className="group-hover:text-white transition-colors">{item}</span>
              <span className="opacity-0 group-hover:opacity-100 text-[#70D0FF] ml-1 transition-opacity duration-300 font-mono">]</span>
            </button>
          ))}
        </div>

        {/* Right Button (Precision CTA) */}
        <div className="flex items-center gap-3">
          {user ? (
            <div className="flex items-center gap-2">
              <button
                onClick={onDashboardClick}
                className="bg-neutral-900/90 hover:bg-neutral-800 text-white text-xs sm:text-sm rounded-full px-5 py-2.5 border border-white/10 hover:border-white/20 transition-all font-mono uppercase tracking-wider"
              >
                Dashboard
              </button>
              <button
                onClick={onSignOut}
                className="bg-red-950/25 hover:bg-red-900/40 text-red-400 text-xs sm:text-sm rounded-full p-2.5 sm:p-3 border border-red-500/10 hover:border-red-500/20 transition-all"
                title="Sign Out"
              >
                <FiLogOut className="text-base" />
              </button>
            </div>
          ) : (
            <div 
              onClick={onAccessClick}
              className="relative rounded-full p-[1.5px] cursor-pointer group hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_15px_rgba(250,132,83,0.06)] hover:shadow-[0_0_25px_rgba(250,132,83,0.18)]"
              style={{ background: 'linear-gradient(90deg, #FA8453 0%, #F8C9B2 100%)' }}
            >
              <div className="rounded-full bg-black hover:bg-neutral-900 px-5 sm:px-7 py-2 sm:py-2.5 text-white text-xs font-mono tracking-widest uppercase font-semibold transition-colors">
                [ access platform ]
              </div>
            </div>
          )}

          {/* Mobile Menu Toggle */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden bg-neutral-900/90 p-2 sm:p-2.5 rounded-full border border-white/5 text-white"
          >
            {mobileMenuOpen ? <FiX className="text-base" /> : <FiMenu className="text-base" />}
          </button>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden mt-3 mx-auto max-w-[1320px] bg-neutral-950/95 border border-white/5 rounded-2xl p-4 flex flex-col gap-1.5 backdrop-blur-md shadow-2xl shadow-black">
          {['programs', 'labs', 'mission', 'contact'].map((item) => (
            <button
              key={item}
              onClick={() => handleNavClick(item)}
              className="text-neutral-400 hover:text-white text-left text-xs py-3 px-4 rounded-xl hover:bg-white/5 transition-all font-mono"
            >
              &gt;&gt; {item.toUpperCase()}
            </button>
          ))}
        </div>
      )}
    </nav>
  );
};
