import React from 'react';

const LogoMark = () => (
  <svg viewBox="0 0 256 256" className="h-5 w-5 fill-current text-[#70D0FF]" xmlns="http://www.w3.org/2000/svg">
    <path d="M 128 192 L 128 256 L 64.5 256 L 32 223 L 0 192 L 0 128 L 64 128 Z M 256 192 L 256 256 L 192.5 256 L 160 223 L 128 192 L 128 128 L 192 128 Z M 128 64 L 128 128 L 64.5 128 L 32 95 L 0 64 L 0 0 L 64 0 Z M 256 64 L 256 128 L 192.5 128 L 160 95 L 128 64 L 128 0 L 192 0 Z" />
  </svg>
);

interface FooterProps {
  onScrollTo?: (id: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onScrollTo }) => {
  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    if (onScrollTo) {
      onScrollTo(id);
    } else {
      const el = document.getElementById(id);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer id="contact" className="w-full bg-black pt-16 pb-8 border-t border-white/5 mt-20 relative overflow-hidden select-none">
      
      {/* Subtle Background Glow */}
      <div className="absolute -bottom-48 left-1/2 -translate-x-1/2 w-[700px] h-[300px] bg-[#1e3a8a]/5 rounded-full blur-[120px] pointer-events-none z-0"></div>

      {/* Top Diagnostics Status Ribbon (Spans full width) */}
      <div className="w-full border-t border-b border-white/5 bg-neutral-950/40 py-4 px-6 md:px-10 flex flex-col md:flex-row items-center justify-between gap-4 font-mono text-[9px] sm:text-[10px] text-neutral-500 select-none mb-16 relative z-10">
        <div className="flex items-center gap-2 text-green-500 font-bold">
          <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
          SYS_STATUS: [ ALL LABS OPERATIONAL ]
        </div>
        <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-1">
          <span>SYS_LATENCY: 14MS</span>
          <span className="text-white/10">|</span>
          <span>STABILITY: 99.98%</span>
          <span className="text-white/10">|</span>
          <span>UPTIME: 99.9%</span>
          <span className="text-white/10">|</span>
          <span>FIREWALLS: ACTIVE</span>
        </div>
        <div className="text-neutral-500">
          SEC_SYS_V3.2 // COMPLIANCE_SECURED
        </div>
      </div>

      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 md:px-10 relative z-10 flex flex-col gap-16">
        
        {/* Structured 3-Column Footer Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 text-left">
          
          {/* Column 1: Branding and description */}
          <div className="md:col-span-6 flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-neutral-950 border border-white/15 flex items-center justify-center shadow-[0_0_15px_rgba(112,208,255,0.08)]">
                <LogoMark />
              </div>
              <span className="text-white text-sm font-bold tracking-widest uppercase font-mono">snova lab</span>
            </div>
            
            <p className="max-w-md text-neutral-400 text-xs sm:text-sm leading-relaxed font-sans font-light">
              Offensive cyber security training. Snova Academy provides a focused lab environment engineered for operators, malware researchers, and ethical hackers.
            </p>
          </div>

          {/* Column 2: Navigation Directory */}
          <div className="md:col-span-3 flex flex-col gap-4">
            <span className="text-[10px] font-mono text-[#FA8453] uppercase tracking-widest font-semibold">// Directory</span>
            <div className="flex flex-col gap-2.5 font-mono text-[11px] text-neutral-400">
              <a href="#programs" onClick={(e) => handleLinkClick(e, 'programs')} className="hover:text-white transition-colors w-max">
                [ programs ]
              </a>
              <a href="#labs" onClick={(e) => handleLinkClick(e, 'labs')} className="hover:text-white transition-colors w-max">
                [ labs ]
              </a>
              <a href="#mission" onClick={(e) => handleLinkClick(e, 'mission')} className="hover:text-white transition-colors w-max">
                [ mission ]
              </a>
              <a href="#contact" onClick={(e) => handleLinkClick(e, 'contact')} className="hover:text-white transition-colors w-max">
                [ contact ]
              </a>
            </div>
          </div>

          {/* Column 3: Legal Protocols */}
          <div className="md:col-span-3 flex flex-col gap-4">
            <span className="text-[10px] font-mono text-[#70D0FF] uppercase tracking-widest font-semibold">// Protocols</span>
            <div className="flex flex-col gap-2.5 font-mono text-[11px] text-neutral-400">
              <a href="#" className="hover:text-white transition-colors w-max">
                [ security report ]
              </a>
              <a href="#" className="hover:text-white transition-colors w-max">
                [ terms of use ]
              </a>
              <a href="#" className="hover:text-white transition-colors w-max">
                [ legal labs ]
              </a>
            </div>
          </div>

        </div>

        {/* Bottom Signature Line */}
        <div className="border-t border-white/5 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 font-mono text-[9px] text-neutral-600 select-none uppercase">
          <span>&copy; {new Date().getFullYear()} SNOVA TECH. ALL RIGHTS RESERVED.</span>
          <span>encryption strength: aes_256_gcm // security_level: 4</span>
        </div>

      </div>
    </footer>
  );
};
