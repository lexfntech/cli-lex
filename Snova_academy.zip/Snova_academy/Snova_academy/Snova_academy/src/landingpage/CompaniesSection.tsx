import React from 'react';

interface CompaniesSectionProps {
  onScrollTo: (id: string) => void;
}

export const CompaniesSection: React.FC<CompaniesSectionProps> = ({
  onScrollTo,
}) => {
  return (
    <section id="mission" className="relative w-full bg-black px-4 sm:px-6 md:px-10 py-16 sm:py-24 border-t border-white/5 cyber-grid">
      <div className="max-w-[1320px] mx-auto flex flex-col items-center">
        
        {/* Section Heading Tag */}
        <div className="flex items-center gap-3 select-none mb-12">
          <span className="h-px w-6 bg-[#70D0FF]"></span>
          <span className="text-[10px] font-mono text-[#70D0FF] uppercase tracking-[0.2em] font-semibold">trusted network nodes</span>
          <span className="h-px w-6 bg-[#70D0FF]"></span>
        </div>

        {/* Grid of Partners */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full mb-16 sm:mb-24">
          
          {/* Card 1: Apex */}
          <div className="relative h-24 sm:h-32 md:h-36 rounded-2xl bg-neutral-950/80 overflow-hidden flex items-center justify-center border border-white/5 group transition-all duration-300 hover:border-[#70D0FF]/30 glow-border-cyan">
            <div className="absolute -top-24 -left-24 h-40 w-40 rounded-full blur-3xl bg-[#1e3a8a] opacity-30 group-hover:opacity-40 group-hover:scale-115 transition-all duration-700"></div>
            <div className="relative z-10 flex items-center gap-2 select-none">
              <svg className="h-5 w-5 sm:h-6 sm:w-6 fill-current text-white/70 group-hover:text-white transition-colors" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2l2.39 4.84L20 8l-4 3.9L17.28 18 12 15.27 6.72 18 8 11.9 4 8l5.61-1.16L12 2z" />
              </svg>
              <span className="text-white/80 group-hover:text-white text-lg sm:text-2xl font-bold tracking-tight font-sans transition-colors">Apex</span>
            </div>
          </div>

          {/* Card 2: Forge */}
          <div className="relative h-24 sm:h-32 md:h-36 rounded-2xl bg-neutral-950/80 overflow-hidden flex items-center justify-center border border-white/5 group transition-all duration-300 hover:border-[#FA8453]/30 glow-border-orange">
            <div className="absolute -top-24 -left-24 h-40 w-40 rounded-full blur-3xl bg-[#FA8453] opacity-20 group-hover:opacity-30 group-hover:scale-115 transition-all duration-700"></div>
            <div className="absolute -bottom-24 -right-24 h-40 w-40 rounded-full blur-3xl bg-[#F5D547] opacity-15 group-hover:opacity-25 group-hover:scale-115 transition-all duration-700"></div>
            <div className="relative z-10 flex items-center gap-2 select-none">
              <svg className="h-5 w-5 sm:h-6 sm:w-6 fill-current text-white/70 group-hover:text-white transition-colors" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M20.63 8.46l-4.73-2.73-.53.31 5.1 2.94v5.88l-5.1 2.94.53.3 4.73-2.72V8.46zM8.1 6.04l.53.3L3.53 9.28v5.88L8.63 18.1l-.53.3-4.73-2.72V8.46L8.1 6.04zM16.05 14.3v-4.6L12 7.4 7.95 9.7v4.6L12 16.6l4.05-2.3zm-.53-.3L12 16.02l-3.52-2.02v-4.02L12 7.96l3.52 2.02v4.02z" />
              </svg>
              <span className="text-white/80 group-hover:text-white text-lg sm:text-2xl font-bold tracking-tight font-sans transition-colors">forge</span>
            </div>
          </div>

          {/* Card 3: Eastern Delta */}
          <div className="relative h-24 sm:h-32 md:h-36 rounded-2xl bg-neutral-950/80 overflow-hidden flex items-center justify-center border border-white/5 group transition-all duration-300 hover:border-[#70D0FF]/30 glow-border-cyan">
            <div className="absolute -bottom-24 -left-24 h-40 w-40 rounded-full blur-3xl bg-[#F5D547] opacity-20 group-hover:opacity-30 group-hover:scale-115 transition-all duration-700"></div>
            <div className="relative z-10 flex items-center gap-2 select-none">
              <svg className="h-5 w-5 sm:h-6 sm:w-6 fill-current text-white/70 group-hover:text-white transition-colors" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M2 4l3 16h3l2-10 2 10h3l3-16h-3l-1.5 10L12 4h-2L8.5 14 7 4H2z" />
              </svg>
              <div className="flex flex-col leading-none">
                <span className="text-white/50 group-hover:text-white/80 text-[8px] sm:text-[9px] font-semibold tracking-wider uppercase font-mono transition-colors">Eastern</span>
                <span className="text-white/80 group-hover:text-white text-base sm:text-xl font-bold tracking-tight font-sans transition-colors">Delta</span>
              </div>
            </div>
          </div>

          {/* Card 4: Skybank */}
          <div className="relative h-24 sm:h-32 md:h-36 rounded-2xl bg-neutral-950/80 overflow-hidden flex items-center justify-center border border-white/5 group transition-all duration-300 hover:border-[#1e3a8a]/40 glow-border-cyan">
            <div className="absolute top-1/2 -translate-y-1/2 -right-28 h-48 w-48 rounded-full blur-3xl bg-[#1e3a8a] opacity-30 group-hover:opacity-40 group-hover:scale-115 transition-all duration-700"></div>
            <div className="relative z-10 flex items-center gap-2 select-none">
              <svg className="h-5 w-5 sm:h-6 sm:w-6 fill-current text-white/70 group-hover:text-white transition-colors" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M6 2l6 3.75L6 9.5 0 5.75 6 2zm12 0l6 3.75L18 9.5l-6-3.75L18 2zM0 13.25L6 9.5l6 3.75L6 17l-6-3.75zm18-3.75l6 3.75L18 17l-6-3.75 6-3.75zM6 18.25L12 14.5l6 3.75L12 22l-6-3.75z" />
              </svg>
              <span className="text-white/80 group-hover:text-white text-lg sm:text-2xl font-bold tracking-tight font-sans transition-colors">Skybank</span>
            </div>
          </div>

        </div>

        {/* Below Grid: Secure transmission console card */}
        <div className="w-full bg-neutral-950/60 border border-white/5 rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row justify-between items-center gap-6 shadow-xl shadow-black relative overflow-hidden scanlines">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-transparent via-[#70D0FF]/5 to-transparent pointer-events-none opacity-20"></div>
          
          <div className="flex flex-col gap-2 relative z-10">
            <span className="text-[10px] font-mono text-[#FA8453] uppercase tracking-[0.2em] font-semibold">[ secure communication established ]</span>
            <p className="max-w-xl text-neutral-300 text-sm sm:text-base leading-relaxed font-sans font-light">
              shielding users info with premier tech, granting them with safety in all place.
            </p>
          </div>

          {/* Gradient-border button */}
          <div 
            onClick={() => onScrollTo('programs')}
            className="relative rounded-full p-[1.5px] cursor-pointer group hover:scale-[1.02] active:scale-[0.98] transition-all relative z-10 shadow-[0_0_15px_rgba(250,132,83,0.06)] hover:shadow-[0_0_25px_rgba(250,132,83,0.18)]"
            style={{ background: 'linear-gradient(90deg, #FA8453 0%, #F8C9B2 100%)' }}
          >
            <div className="rounded-full bg-black hover:bg-neutral-900 px-8 py-3 text-white text-xs font-mono tracking-widest uppercase font-semibold transition-colors">
              [ run demo ]
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
