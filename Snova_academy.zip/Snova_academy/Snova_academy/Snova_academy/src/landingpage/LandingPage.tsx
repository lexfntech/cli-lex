import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import type { AppDispatch, RootState } from '../store';
import { auth } from '../firebase';
import { onAuthStateChanged, signOut, type User } from 'firebase/auth';
import RegistrationModal from '../components/RegistrationModal';
import CourseRegistrationModal from '../components/CourseRegistrationModal';
import { fetchCourses } from '../store/courseSlice';

// Import modular sections
import { Navbar } from './Navbar';
import { Hero } from './Hero';
import { SecuritySection } from './SecuritySection';
import { CompaniesSection } from './CompaniesSection';
import { BenefitsSection } from './BenefitsSection';
import { ProgramsSection } from './ProgramsSection';
import { Footer } from './Footer';

const LandingPage = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCourseRegistrationOpen, setIsCourseRegistrationOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null);

  const dispatch = useDispatch<AppDispatch>();
  const course = useSelector((state: RootState) => state.course.currentCourse);
  const navigate = useNavigate();

  useEffect(() => {
    // Set theme to dark to match the black background design
    document.documentElement.setAttribute('data-theme', 'dark');
    dispatch(fetchCourses());
  }, [dispatch]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      
      if (currentUser) {
        try {
          const token = await currentUser.getIdToken();
          const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
          const response = await fetch(`${apiUrl}/api/auth/profile`, {
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });

          if (response.ok) {
            const data = await response.json();
            const userProfile = data.data;
            
            if (userProfile.role === 'admin') {
              navigate('/management-dashboard-x92f-snova');
            } else if (userProfile.role === 'student') {
              setIsModalOpen(false);
            }
          } else if (response.status === 404) {
            setIsModalOpen(true);
          }
        } catch (error) {
          console.error('Error checking user profile:', error);
        }
      }
    });
    return () => unsubscribe();
  }, [navigate]);

  const handleModuleClick = (moduleId: string) => {
    if (auth.currentUser) {
      navigate(`/curriculum/${moduleId}`);
    } else {
      setIsModalOpen(true);
    }
  };

  const handleScrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSignOut = async () => {
    await signOut(auth);
    navigate('/');
  };

  const handleDashboardClick = () => {
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center overflow-x-hidden w-full font-sans">
      
      {/* Navbar Overlay */}
      <Navbar 
        user={user}
        onAccessClick={() => setIsModalOpen(true)}
        onScrollTo={handleScrollTo}
        onSignOut={handleSignOut}
        onDashboardClick={handleDashboardClick}
      />

      {/* Hero Section */}
      <Hero 
        user={user}
        onAccessClick={() => setIsModalOpen(true)}
        onScrollTo={handleScrollTo}
        onDashboardClick={handleDashboardClick}
      />

      {/* Container wrapper for content sections */}
      <div className="w-full max-w-[1400px] flex flex-col items-center">
        
        {/* Security Section */}
        <SecuritySection 
          onAccessClick={() => setIsModalOpen(true)}
          onScrollTo={handleScrollTo}
        />

        {/* Companies Section */}
        <CompaniesSection 
          onScrollTo={handleScrollTo}
        />

        {/* Benefits Section */}
        <BenefitsSection />

        {/* Programs / Course Curriculum Section */}
        <ProgramsSection 
          user={user}
          course={course}
          selectedCourse={selectedCourse}
          setSelectedCourse={setSelectedCourse}
          onAccessClick={() => setIsModalOpen(true)}
          onCourseRegisterClick={() => setIsCourseRegistrationOpen(true)}
          onModuleClick={handleModuleClick}
        />

        {/* Footer */}
        <Footer onScrollTo={handleScrollTo} />

      </div>

      {/* Auth Modals */}
      <RegistrationModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
      <CourseRegistrationModal 
        isOpen={isCourseRegistrationOpen} 
        onClose={() => setIsCourseRegistrationOpen(false)} 
        courseId={course?.id || "course_cybersecurity_001"}
        courseName={course?.title || "Cyber Security Mastery"}
      />

    </div>
  );
};

export default LandingPage;
