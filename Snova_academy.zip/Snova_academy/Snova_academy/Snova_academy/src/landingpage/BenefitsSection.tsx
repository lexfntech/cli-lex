import React from 'react';

export const BenefitsSection: React.FC = () => {
  return (
    <section className="relative w-full bg-black px-4 sm:px-6 md:px-10 py-16 sm:py-24 border-t border-white/5 cyber-grid">
      <div className="max-w-[1320px] mx-auto">
        
        {/* Section Heading HUD */}
        <div className="flex flex-col items-center mb-16 sm:mb-24 select-none">
          <div className="text-[10px] font-mono tracking-[0.2em] uppercase text-[#70D0FF] mb-3">platform capabilities</div>
          <h2 className="text-white text-3xl sm:text-4xl md:text-5xl font-light text-center tracking-[-0.04em]">
            Key Benefits
          </h2>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Card 1: Diagnostic Report Panel */}
          <div className="relative h-[380px] sm:h-[460px] rounded-2xl bg-neutral-950/80 overflow-hidden p-6 sm:p-8 flex flex-col justify-between border border-white/5 group hover:border-[#70D0FF]/20 transition-all duration-500 shadow-lg shadow-black">
            {/* Ambient Blob */}
            <div className="absolute top-1/2 -translate-y-1/2 -left-[420px] h-[460px] w-[460px] rounded-full bg-[#1e3a8a] blur-3xl opacity-30 pointer-events-none group-hover:scale-105 transition-transform duration-700"></div>
            
            {/* Top diagnostic metadata */}
            <div className="flex justify-between items-center border-b border-white/5 pb-4 font-mono text-[9px] text-neutral-500 relative z-10 select-none">
              <span>[ REPORT // CAPABILITY_01 ]</span>
              <span className="flex items-center gap-1.5 text-[#70D0FF]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#70D0FF] animate-pulse"></span>
                MONITORING_ACTIVE
              </span>
            </div>

            <div className="my-auto relative z-10">
              <h3 className="text-xl sm:text-2xl font-bold leading-tight text-white mb-6">
                Preemptive Risks <br /> Scouting and Reactions
              </h3>
              <p className="text-[13px] sm:text-[14px] leading-relaxed text-neutral-400 font-light font-sans">
                Defense platforms constantly observe bandwidth streams, record files, and machine behaviors to uncover unusual patterns or outliers that could signal a defensive failure.
              </p>
            </div>

            {/* Bottom diagnostic metadata */}
            <div className="border-t border-white/5 pt-4 font-mono text-[9px] text-neutral-600 relative z-10 select-none">
              <span>CAP_UUID: 8F7E-90X2</span>
            </div>
          </div>

          {/* Card 2: Sectoral Awareness Panel */}
          <div className="relative h-[380px] sm:h-[460px] rounded-2xl bg-neutral-950/80 overflow-hidden p-6 sm:p-8 flex flex-col justify-between border border-white/5 group hover:border-[#FA8453]/20 transition-all duration-500 shadow-lg shadow-black">
            {/* Ambient Blob */}
            <div className="absolute top-1/2 -translate-y-1/2 -left-[420px] h-[460px] w-[460px] rounded-full bg-[#FA8453] blur-3xl opacity-[0.15] pointer-events-none group-hover:scale-105 transition-transform duration-700"></div>
            
            {/* Top diagnostic metadata */}
            <div className="flex justify-between items-center border-b border-white/5 pb-4 font-mono text-[9px] text-neutral-500 relative z-10 select-none">
              <span>[ REPORT // CAPABILITY_02 ]</span>
              <span className="flex items-center gap-1.5 text-[#FA8453]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#FA8453] animate-pulse"></span>
                THREAT_INTEL_ACTIVE
              </span>
            </div>

            <div className="my-auto relative z-10">
              <h3 className="text-xl sm:text-2xl font-bold leading-tight text-white mb-6">
                Know-how and Sectoral <br /> Awareness
              </h3>
              <p className="text-[13px] sm:text-[14px] leading-relaxed text-neutral-400 font-light font-sans">
                Continuous intelligence gathering and sector threat analysis feed operational radars, allowing security teams to anticipate emerging threat actor campaigns and mitigate potential breaches.
              </p>
            </div>

            {/* Bottom diagnostic metadata */}
            <div className="border-t border-white/5 pt-4 font-mono text-[9px] text-neutral-600 relative z-10 select-none">
              <span>CAP_UUID: 9A3X-77Z1</span>
            </div>
          </div>

          {/* Card 3: Vulnerability Defeat Panel */}
          <div className="relative h-[380px] sm:h-[460px] rounded-2xl bg-neutral-950/80 overflow-hidden p-6 sm:p-8 flex flex-col justify-between border border-white/5 group hover:border-[#70D0FF]/20 transition-all duration-500 shadow-lg shadow-black">
            {/* Ambient Blob */}
            <div className="absolute top-1/2 -translate-y-1/2 -left-[420px] h-[460px] w-[460px] rounded-full bg-[#1e3a8a] blur-3xl opacity-30 pointer-events-none group-hover:scale-105 transition-transform duration-700"></div>
            
            {/* Top diagnostic metadata */}
            <div className="flex justify-between items-center border-b border-white/5 pb-4 font-mono text-[9px] text-neutral-500 relative z-10 select-none">
              <span>[ REPORT // CAPABILITY_03 ]</span>
              <span className="flex items-center gap-1.5 text-[#70D0FF]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#70D0FF] animate-pulse"></span>
                DEFEAT_VULNERABILITY
              </span>
            </div>

            <div className="my-auto relative z-10">
              <h3 className="text-xl sm:text-2xl font-bold leading-tight text-white mb-6">
                Preemptive Risks <br /> Scouting and Reactions
              </h3>
              <p className="text-[13px] sm:text-[14px] leading-relaxed text-neutral-400 font-light font-sans">
                Defense platforms constantly observe bandwidth streams, record files, and machine behaviors to uncover unusual patterns or outliers that could signal a defensive failure.
              </p>
            </div>

            {/* Bottom diagnostic metadata */}
            <div className="border-t border-white/5 pt-4 font-mono text-[9px] text-neutral-600 relative z-10 select-none">
              <span>CAP_UUID: 4B1E-02L9</span>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
