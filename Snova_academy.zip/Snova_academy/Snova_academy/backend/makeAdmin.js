require('dotenv').config();
const { auth } = require('./src/config/firebase');

async function makeAdmin(email) {
  try {
    console.log(`Looking up user: ${email}...`);
    const user = await auth.getUserByEmail(email);
    
    console.log(`Setting admin claims for UID: ${user.uid}...`);
    await auth.setCustomUserClaims(user.uid, { admin: true });
    
    console.log(`\n SUCCESS! ${email} is now an admin.`);
    console.log(' IMPORTANT: You MUST sign out and sign back in on the website for the new token to take effect.');
    process.exit(0);
  } catch (error) {
    console.error(`\nFailed to make ${email} an admin:`, error.message);
    process.exit(1);
  }
}

const email = process.argv[2];
if (!email) {
  console.log('Usage: node makeAdmin.js <user-email>');
  process.exit(1);
}

makeAdmin(email);
