const authRepository = require('../repositories/auth.repository');

/**
 * Middleware to verify admin role from Firestore
 */
const verifyAdmin = async (req, res, next) => {
  try {
    // req.user should already be set by auth middleware
    if (!req.user) {
      return res.status(401).json({ 
        success: false, 
        error: 'Unauthorized: No user authenticated' 
      });
    }

    // Get user from Firestore to check role
    try {
      const user = await authRepository.findUserById(req.user.uid);
      
      if (!user) {
        return res.status(403).json({ 
          success: false, 
          error: 'Forbidden: User not found in database' 
        });
      }

      if (user.role !== 'admin') {
        return res.status(403).json({ 
          success: false, 
          error: 'Forbidden: Admin access required' 
        });
      }

      // User is admin, continue
      next();
    } catch (error) {
      console.error('Error checking admin role:', error);
      return res.status(500).json({ 
        success: false, 
        error: 'Internal server error' 
      });
    }
  } catch (error) {
    console.error('Error in admin middleware:', error);
    return res.status(500).json({ 
      success: false, 
      error: 'Internal server error' 
    });
  }
};

/**
 * Middleware to verify influencer role from Firestore
 */
const verifyInfluencer = async (req, res, next) => {
  try {
    if (!req.user) {
      return res.status(401).json({ 
        success: false, 
        error: 'Unauthorized: No user authenticated' 
      });
    }

    // Get user from Firestore to check role
    try {
      const user = await authRepository.findUserById(req.user.uid);
      
      if (!user) {
        return res.status(403).json({ 
          success: false, 
          error: 'Forbidden: User not found in database' 
        });
      }

      if (user.role !== 'influencer' && user.role !== 'admin') {
        return res.status(403).json({ 
          success: false, 
          error: 'Forbidden: Influencer access required' 
        });
      }

      // User is influencer or admin, continue
      next();
    } catch (error) {
      console.error('Error checking influencer role:', error);
      return res.status(500).json({ 
        success: false, 
        error: 'Internal server error' 
      });
    }
  } catch (error) {
    console.error('Error in influencer middleware:', error);
    return res.status(500).json({ 
      success: false, 
      error: 'Internal server error' 
    });
  }
};

module.exports = { verifyAdmin, verifyInfluencer };
