const express = require('express');
const router = express.Router();
const courseController = require('../controllers/course.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { verifyAdmin } = require('../middleware/admin.middleware');

// Public/Authenticated course endpoints (students can view courses)
router.get('/', (req, res) => courseController.getAll(req, res));
router.get('/:id', (req, res) => courseController.getById(req, res));

// Admin-protected CRUD endpoints
router.use(verifyToken);
router.use(verifyAdmin);

router.post('/', (req, res) => courseController.create(req, res));
router.put('/:id', (req, res) => courseController.update(req, res));
router.delete('/:id', (req, res) => courseController.delete(req, res));

module.exports = router;
