const express = require('express');
const router = express.Router();

const studentController = require('../controllers/student.controller');
const { verifyToken } = require('../middleware/auth.middleware');

// 🔐 Protect all student routes (must be logged in)
router.use(verifyToken);

//
// 📊 Student Dashboard Data
//
router.get('/dashboard', (req, res) =>
  studentController.getDashboard(req, res)
);

//
// 📚 Get all courses student is enrolled in
//
router.get('/courses', (req, res) =>
  studentController.getMyCourses(req, res)
);

//
// 📝 Get all registrations (pending / approved / rejected)
//
router.get('/registrations', (req, res) =>
  studentController.getRegistrations(req, res)
);

//
// 🎯 Register for a course
//
router.post('/register', (req, res) =>
  studentController.registerCourse(req, res)
);

//
// ❌ Cancel / withdraw registration
//
router.delete('/register/:id', (req, res) =>
  studentController.cancelRegistration(req, res)
);

//
// 👤 Get student profile info
//
router.get('/profile', (req, res) =>
  studentController.getProfile(req, res)
);

//
// 📈 Progress tracking (optional future feature)
//
router.get('/progress', (req, res) =>
  studentController.getProgress(req, res)
);

module.exports = router;