const express = require('express');
const router = express.Router();
const couponController = require('../controllers/coupon.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { verifyAdmin } = require('../middleware/admin.middleware');

// Public validation endpoint (for students during checkout)
router.get('/validate/:code', verifyToken, (req, res) => couponController.validateCode(req, res));

// Admin management endpoints
router.use(verifyToken);
router.use(verifyAdmin);

router.get('/', (req, res) => couponController.getAll(req, res));
router.post('/', (req, res) => couponController.create(req, res));
router.patch('/:id/status', (req, res) => couponController.toggleStatus(req, res));
router.delete('/:id', (req, res) => couponController.delete(req, res));

module.exports = router;
