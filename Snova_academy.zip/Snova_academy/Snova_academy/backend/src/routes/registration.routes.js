const express = require('express');
const router = express.Router();
const registrationController = require('../controllers/registration.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { verifyAdmin } = require('../middleware/admin.middleware');

// Public route to verify referral code
router.get('/verify-referral/:code', verifyToken, (req, res) => {
  // This will be handled by influencer controller
  res.status(200).json({ success: true, valid: true });
});

// Create registration (authenticated users)
router.post('/', verifyToken, (req, res) => registrationController.create(req, res));

// Get user's own registrations
router.get('/my-registrations', verifyToken, (req, res) => registrationController.getByUser(req, res));

// Admin-only routes
router.use(verifyToken);
router.use(verifyAdmin);

// Get all registrations with filters
router.get('/', (req, res) => registrationController.getAll(req, res));

// Get statistics
router.get('/stats', (req, res) => registrationController.getStats(req, res));

// Get registration by ID
router.get('/:id', (req, res) => registrationController.getById(req, res));

// Get registrations by influencer
router.get('/influencer/:influencerId', (req, res) => registrationController.getByInfluencer(req, res));

// Approve registration
router.post('/:id/approve', (req, res) => registrationController.approve(req, res));

// Reject registration
router.post('/:id/reject', (req, res) => registrationController.reject(req, res));

// Update progress
router.patch('/:id/progress', (req, res) => registrationController.updateProgress(req, res));

// Delete registration
router.delete('/:id', (req, res) => registrationController.delete(req, res));

module.exports = router;
