const express = require('express');
const router = express.Router();
const influencerController = require('../controllers/influencer.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { verifyAdmin } = require('../middleware/admin.middleware');

// All influencer routes require authentication and admin access
router.use(verifyToken);
router.use(verifyAdmin);

// Create influencer
router.post('/', (req, res) => influencerController.create(req, res));

// Get all influencers with optional filters
router.get('/', (req, res) => influencerController.getAll(req, res));

// Get analytics
router.get('/analytics', (req, res) => influencerController.getAnalytics(req, res));

// Get influencer by referral code
router.get('/referral/:code', (req, res) => influencerController.getByReferralCode(req, res));

// Get influencer by ID
router.get('/:id', (req, res) => influencerController.getById(req, res));

// Update influencer
router.put('/:id', (req, res) => influencerController.update(req, res));

// Update influencer status
router.patch('/:id/status', (req, res) => influencerController.updateStatus(req, res));

// Delete influencer
router.delete('/:id', (req, res) => influencerController.delete(req, res));

module.exports = router;
