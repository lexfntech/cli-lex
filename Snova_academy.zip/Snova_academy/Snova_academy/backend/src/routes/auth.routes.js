const express = require('express');
const router = express.Router();

const authController = require('../controllers/auth.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { verifyAdmin } = require('../middleware/admin.middleware');

// Routes
router.post('/register', verifyToken, (req, res) => authController.register(req, res));
router.get('/profile', verifyToken, (req, res) => authController.getProfile(req, res));
router.get('/users', verifyToken, verifyAdmin, (req, res) => authController.getAllUsers(req, res));

module.exports = router;
