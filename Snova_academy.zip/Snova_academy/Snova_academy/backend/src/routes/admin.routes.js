const express = require("express");
const router = express.Router();
const adminController = require("../controllers/admin.controller");
const { verifyToken } = require("../middleware/auth.middleware");
const { verifyAdmin } = require("../middleware/admin.middleware");

// All admin routes require authentication and admin role
router.use(verifyToken);
router.use(verifyAdmin);

/**
 * @route   GET /api/admin/dashboard-stats
 * @desc    Get dashboard statistics (KPIs, top influencers, recent registrations)
 * @access  Admin only
 */
router.get("/dashboard-stats", (req, res) =>
  adminController.getDashboardStats(req, res),
);

module.exports = router;
