const admin = require('firebase-admin');

// Ensure firebase is only initialized once
if (!admin.apps.length) {
  // If no env variables are set, this might fail or initialize a mock
  // We use try-catch to allow the server to start without crashing if keys are missing
  try {
    admin.initializeApp({
      credential: admin.credential.cert({
        projectId: process.env.FIREBASE_PROJECT_ID,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        // Replace escaped newlines from env
        privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
      }),
    });
    console.log('Firebase Admin initialized successfully.');
  } catch (error) {
    console.error('Firebase Admin initialization error. Check your .env credentials.', error.message);
    // Fallback for local dev without credentials
    admin.initializeApp();
  }
}

const db = admin.firestore();
const auth = admin.auth();

module.exports = { admin, db, auth };
