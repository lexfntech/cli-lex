const { db } = require('../config/firebase');

class RegistrationRepository {
  constructor() {
    this.registrationsCollection = db.collection('registrations');
  }

  /**
   * Create a new registration
   */
  async create(registrationData) {
    const docRef = await this.registrationsCollection.add({
      ...registrationData,
      registeredAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    return { id: docRef.id, ...registrationData };
  }

  /**
   * Find registration by ID
   */
  async findById(id) {
    const doc = await this.registrationsCollection.doc(id).get();
    if (!doc.exists) return null;
    return { id: doc.id, ...doc.data() };
  }

  /**
   * Find registrations by user ID
   */
  async findByUserId(userId) {
    const snapshot = await this.registrationsCollection
      .where('userId', '==', userId)
      .orderBy('registeredAt', 'desc')
      .get();
    
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  }

  /**
   * Find registrations by influencer ID
   */
  async findByInfluencerId(influencerId) {
    const snapshot = await this.registrationsCollection
      .where('influencerId', '==', influencerId)
      .orderBy('registeredAt', 'desc')
      .get();
    
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  }

  /**
   * Get all registrations with optional filters
   */
  async findAll(filters = {}) {
    let query = this.registrationsCollection;

    if (filters.status) {
      query = query.where('status', '==', filters.status);
    }

    if (filters.courseId) {
      query = query.where('courseId', '==', filters.courseId);
    }

    query = query.orderBy('registeredAt', 'desc');

    if (filters.limit) {
      query = query.limit(filters.limit);
    }

    const snapshot = await query.get();
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  }

  /**
   * Update registration
   */
  async update(id, updateData) {
    await this.registrationsCollection.doc(id).update({
      ...updateData,
      updatedAt: new Date().toISOString()
    });
    return this.findById(id);
  }

  /**
   * Approve registration
   */
  async approve(id, adminId) {
    await this.registrationsCollection.doc(id).update({
      status: 'approved',
      approvedAt: new Date().toISOString(),
      approvedBy: adminId,
      updatedAt: new Date().toISOString()
    });
    return this.findById(id);
  }

  /**
   * Reject registration
   */
  async reject(id, adminId, reason = null) {
    const updates = {
      status: 'rejected',
      rejectedAt: new Date().toISOString(),
      rejectedBy: adminId,
      updatedAt: new Date().toISOString()
    };

    if (reason) {
      updates.rejectionReason = reason;
    }

    await this.registrationsCollection.doc(id).update(updates);
    return this.findById(id);
  }

  /**
   * Update progress
   */
  async updateProgress(id, completedModules) {
    await this.registrationsCollection.doc(id).update({
      'progress.completedModules': completedModules,
      updatedAt: new Date().toISOString()
    });
    return this.findById(id);
  }

  /**
   * Check if user is registered for a course
   */
  async isUserRegistered(userId, courseId) {
    const snapshot = await this.registrationsCollection
      .where('userId', '==', userId)
      .where('courseId', '==', courseId)
      .limit(1)
      .get();
    
    return !snapshot.empty;
  }

  /**
   * Get registration statistics
   */
  async getStats() {
    const allSnapshot = await this.registrationsCollection.get();
    const pendingSnapshot = await this.registrationsCollection
      .where('status', '==', 'pending')
      .get();
    const approvedSnapshot = await this.registrationsCollection
      .where('status', '==', 'approved')
      .get();
    const rejectedSnapshot = await this.registrationsCollection
      .where('status', '==', 'rejected')
      .get();

    return {
      total: allSnapshot.size,
      pending: pendingSnapshot.size,
      approved: approvedSnapshot.size,
      rejected: rejectedSnapshot.size
    };
  }

  /**
   * Delete registration
   */
  async delete(id) {
    await this.registrationsCollection.doc(id).delete();
    return { id, deleted: true };
  }
}

module.exports = new RegistrationRepository();
