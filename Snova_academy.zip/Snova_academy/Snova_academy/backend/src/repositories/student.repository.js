const { db } = require('../config/firebase');

class StudentRepository {
  constructor() {
    this.usersCollection = db.collection('users'); // students stored here
    this.registrationsCollection = db.collection('registrations');
  }

  /**
   * Find student by ID
   */
  async findById(id) {
    const doc = await this.usersCollection.doc(id).get();
    if (!doc.exists) return null;
    return { id: doc.id, ...doc.data() };
  }

  /**
   * Get all registrations for a student
   */
  async findRegistrationsByUserId(userId) {
    const snapshot = await this.registrationsCollection
      .where('userId', '==', userId)
      .orderBy('registeredAt', 'desc')
      .get();

    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  }

  /**
   * Get approved courses for student
   */
  async findApprovedCourses(userId) {
    const snapshot = await this.registrationsCollection
      .where('userId', '==', userId)
      .where('status', '==', 'approved')
      .orderBy('registeredAt', 'desc')
      .get();

    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
  }

  /**
   * Create student (if needed)
   */
  async createStudent(data) {
    const docRef = await this.usersCollection.add({
      ...data,
      role: 'student',
      createdAt: new Date().toISOString()
    });

    return { id: docRef.id, ...data };
  }

  /**
   * Update student profile
   */
  async updateStudent(id, updateData) {
    await this.usersCollection.doc(id).update({
      ...updateData,
      updatedAt: new Date().toISOString()
    });

    return this.findById(id);
  }

  /**
   * Get student stats (dashboard helper)
   */
  async getStudentStats(userId) {
    const all = await this.findRegistrationsByUserId(userId);

    return {
      totalCourses: all.length,
      pending: all.filter(r => r.status === 'pending').length,
      approved: all.filter(r => r.status === 'approved').length,
      rejected: all.filter(r => r.status === 'rejected').length
    };
  }
}

module.exports = new StudentRepository();