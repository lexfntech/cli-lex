const { db } = require('../config/firebase');

class CourseRepository {
  constructor() {
    this.coursesCollection = db.collection('courses');
  }

  /**
   * Create a new course
   */
  async create(courseData) {
    const id = courseData.id || `course_${Date.now()}`;
    const docRef = this.coursesCollection.doc(id);

    const courseToSave = {
      ...courseData,
      id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await docRef.set(courseToSave);
    return { id, ...courseToSave };
  }

  /**
   * Find course by ID
   */
  async findById(id) {
    const doc = await this.coursesCollection.doc(id).get();
    if (!doc.exists) return null;
    return { id: doc.id, ...doc.data() };
  }

  /**
   * Get all courses
   */
  async findAll() {
    const snapshot = await this.coursesCollection.get();
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  }

  /**
   * Update course
   */
  async update(id, updateData) {
    const docRef = this.coursesCollection.doc(id);
    await docRef.update({
      ...updateData,
      updatedAt: new Date().toISOString()
    });
    return this.findById(id);
  }

  /**
   * Delete course
   */
  async delete(id) {
    await this.coursesCollection.doc(id).delete();
    return { id, deleted: true };
  }
}

module.exports = new CourseRepository();
