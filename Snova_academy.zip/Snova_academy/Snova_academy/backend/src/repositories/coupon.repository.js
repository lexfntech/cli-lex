const { db } = require('../config/firebase');

class CouponRepository {
  constructor() {
    this.couponsCollection = db.collection('coupons');
  }

  /**
   * Create a new coupon
   */
  async create(couponData) {
    const code = couponData.code.toUpperCase();
    const docRef = this.couponsCollection.doc(code);
    
    const couponToSave = {
      ...couponData,
      code,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await docRef.set(couponToSave);
    return { id: code, ...couponToSave };
  }

  /**
   * Find coupon by ID (which is code in uppercase)
   */
  async findById(id) {
    const doc = await this.couponsCollection.doc(id.toUpperCase()).get();
    if (!doc.exists) return null;
    return { id: doc.id, ...doc.data() };
  }

  /**
   * Find coupon by code
   */
  async findByCode(code) {
    return this.findById(code);
  }

  /**
   * Get all coupons
   */
  async findAll() {
    const snapshot = await this.couponsCollection.orderBy('createdAt', 'desc').get();
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  }

  /**
   * Update coupon
   */
  async update(id, updateData) {
    const docRef = this.couponsCollection.doc(id.toUpperCase());
    await docRef.update({
      ...updateData,
      updatedAt: new Date().toISOString()
    });
    return this.findById(id);
  }

  /**
   * Delete coupon
   */
  async delete(id) {
    await this.couponsCollection.doc(id.toUpperCase()).delete();
    return { id, deleted: true };
  }
}

module.exports = new CouponRepository();
