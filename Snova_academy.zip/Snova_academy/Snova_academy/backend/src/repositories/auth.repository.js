const { db } = require('../config/firebase');

class AuthRepository {
  constructor() {
    this.usersCollection = db.collection('users');
  }

  async findUserById(uid) {
    const doc = await this.usersCollection.doc(uid).get();
    if (!doc.exists) return null;
    return { id: doc.id, ...doc.data() };
  }

  async createUser(uid, userData) {
    await this.usersCollection.doc(uid).set({
      ...userData,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    return { id: uid, ...userData };
  }

  async updateUser(uid, updateData) {
    await this.usersCollection.doc(uid).update({
      ...updateData,
      updatedAt: new Date().toISOString()
    });
    return this.findUserById(uid);
  }

  async getAllUsers() {
    try {
      const snapshot = await this.usersCollection.get();
      const users = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      // Sort by createdAt in JavaScript instead of Firestore query
      return users.sort((a, b) => {
        const dateA = new Date(a.createdAt || 0);
        const dateB = new Date(b.createdAt || 0);
        return dateB.getTime() - dateA.getTime();
      });
    } catch (error) {
      console.error('Error getting all users:', error);
      throw error;
    }
  }
}

module.exports = new AuthRepository();
