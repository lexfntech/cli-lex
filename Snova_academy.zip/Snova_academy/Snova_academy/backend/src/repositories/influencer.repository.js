const { db } = require('../config/firebase');

class InfluencerRepository {
  constructor() {
    this.influencersCollection = db.collection('influencers');
  }

  /**
   * Create a new influencer
   */
  async create(influencerData) {
    const docRef = await this.influencersCollection.add({
      ...influencerData,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    return { id: docRef.id, ...influencerData };
  }

  /**
   * Find influencer by ID
   */
  async findById(id) {
    const doc = await this.influencersCollection.doc(id).get();
    if (!doc.exists) return null;
    return { id: doc.id, ...doc.data() };
  }

  /**
   * Find influencer by referral code
   */
  async findByReferralCode(referralCode) {
    const snapshot = await this.influencersCollection
      .where('referralCode', '==', referralCode)
      .limit(1)
      .get();
    
    if (snapshot.empty) return null;
    const doc = snapshot.docs[0];
    return { id: doc.id, ...doc.data() };
  }

  /**
   * Find influencer by email
   */
  async findByEmail(email) {
    const snapshot = await this.influencersCollection
      .where('email', '==', email)
      .limit(1)
      .get();
    
    if (snapshot.empty) return null;
    const doc = snapshot.docs[0];
    return { id: doc.id, ...doc.data() };
  }

  /**
   * Find influencer by username
   */
  async findByUsername(username) {
    const snapshot = await this.influencersCollection
      .where('username', '==', username)
      .limit(1)
      .get();
    
    if (snapshot.empty) return null;
    const doc = snapshot.docs[0];
    return { id: doc.id, ...doc.data() };
  }

  /**
   * Get all influencers with optional filters
   */
  async findAll(filters = {}) {
    let query = this.influencersCollection;

    if (filters.status) {
      query = query.where('status', '==', filters.status);
    }

    if (filters.sortBy === 'name') {
      query = query.orderBy('name', 'asc');
    } else {
      query = query.orderBy('createdAt', 'desc');
    }

    const snapshot = await query.get();
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  }

  /**
   * Update influencer
   */
  async update(id, updateData) {
    await this.influencersCollection.doc(id).update({
      ...updateData,
      updatedAt: new Date().toISOString()
    });
    return this.findById(id);
  }

  /**
   * Update influencer statistics
   */
  async updateStats(id, stats) {
    const influencer = await this.findById(id);
    if (!influencer) return null;

    const updatedStats = {
      totalLeads: stats.totalLeads ?? influencer.totalLeads ?? 0,
      confirmedLeads: stats.confirmedLeads ?? influencer.confirmedLeads ?? 0,
      revenueGenerated: stats.revenueGenerated ?? influencer.revenueGenerated ?? 0,
      updatedAt: new Date().toISOString()
    };

    await this.influencersCollection.doc(id).update(updatedStats);
    return this.findById(id);
  }

  /**
   * Increment influencer leads
   */
  async incrementLeads(id, confirmed = false) {
    const influencer = await this.findById(id);
    if (!influencer) return null;

    const updates = {
      totalLeads: (influencer.totalLeads || 0) + 1,
      updatedAt: new Date().toISOString()
    };

    if (confirmed) {
      updates.confirmedLeads = (influencer.confirmedLeads || 0) + 1;
    }

    await this.influencersCollection.doc(id).update(updates);
    return this.findById(id);
  }

  /**
   * Soft delete influencer
   */
  async softDelete(id) {
    await this.influencersCollection.doc(id).update({
      status: 'deleted',
      updatedAt: new Date().toISOString()
    });
    return this.findById(id);
  }

  /**
   * Hard delete influencer
   */
  async delete(id) {
    await this.influencersCollection.doc(id).delete();
    return { id, deleted: true };
  }

  /**
   * Get analytics data
   */
  async getAnalytics() {
    const snapshot = await this.influencersCollection
      .where('status', '==', 'active')
      .get();
    
    const influencers = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    
    const totalInfluencers = influencers.length;
    const totalLeads = influencers.reduce((sum, inf) => sum + (inf.totalLeads || 0), 0);
    const confirmedLeads = influencers.reduce((sum, inf) => sum + (inf.confirmedLeads || 0), 0);
    const totalRevenue = influencers.reduce((sum, inf) => sum + (inf.revenueGenerated || 0), 0);

    const topInfluencers = influencers
      .sort((a, b) => (b.confirmedLeads || 0) - (a.confirmedLeads || 0))
      .slice(0, 10);

    return {
      totalInfluencers,
      totalLeads,
      confirmedLeads,
      totalRevenue,
      topInfluencers
    };
  }
}

module.exports = new InfluencerRepository();
