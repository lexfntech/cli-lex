const { db } = require('../config/firebase');

class AdminRepository {
  constructor() {
    this.coursesCollection = db.collection('courses');
    this.registrationsCollection = db.collection('registrations');
    this.influencersCollection = db.collection('influencers');
  }

  /**
   * Get total number of courses
   */
  async getTotalCourses() {
    try {
      const snapshot = await this.coursesCollection.get();
      return snapshot.size;
    } catch (error) {
      console.error('Error getting total courses:', error);
      return 0;
    }
  }

  /**
   * Get registration statistics
   */
  async getRegistrationStats() {
    try {
      const snapshot = await this.registrationsCollection.get();
      
      let total = 0;
      let pending = 0;
      let confirmed = 0;
      let cancelled = 0;
      let totalRevenue = 0;
      
      const courseRevenueMap = {};
      const dateRevenueMap = {};

      snapshot.forEach((doc) => {
        const data = doc.data();
        total++;

        switch (data.status) {
          case 'pending':
            pending++;
            break;
          case 'approved': {
            confirmed++;
            const rev = Number(data.revenueAmount || data.coursePrice || 0);
            totalRevenue += rev;
            
            const cName = data.courseName || 'Flagship Course';
            courseRevenueMap[cName] = (courseRevenueMap[cName] || 0) + rev;
            
            const dateStr = data.registeredAt || data.approvedAt;
            if (dateStr) {
              try {
                const dateObj = new Date(dateStr);
                const options = { month: 'short', day: 'numeric' };
                const formattedDate = dateObj.toLocaleDateString('en-US', options);
                dateRevenueMap[formattedDate] = (dateRevenueMap[formattedDate] || 0) + rev;
              } catch (err) {
                console.error('Failed to parse date:', dateStr, err);
              }
            }
            break;
          }
          case 'rejected':
            cancelled++;
            break;
        }
      });

      const colors = ['#3B82F6', '#8B5CF6', '#EC4899', '#F59E0B', '#10B981', '#6B7280'];
      const revenueBreakdown = Object.keys(courseRevenueMap).map((courseName, index) => ({
        course: courseName,
        revenue: courseRevenueMap[courseName],
        color: colors[index % colors.length]
      }));

      const revenueTrendTemp = Object.keys(dateRevenueMap).map(dateStr => {
        const dateVal = Date.parse(dateStr + ', 2026') || 0;
        return { date: dateStr, revenue: dateRevenueMap[dateStr], timestamp: dateVal };
      });
      revenueTrendTemp.sort((a, b) => a.timestamp - b.timestamp);

      const revenueTrend = revenueTrendTemp.map(t => ({ date: t.date, revenue: t.revenue }));

      return {
        total,
        pending,
        confirmed,
        cancelled,
        totalRevenue,
        revenueBreakdown,
        revenueTrend
      };
    } catch (error) {
      console.error('Error getting registration stats:', error);
      return {
        total: 0,
        pending: 0,
        confirmed: 0,
        cancelled: 0,
        totalRevenue: 0,
        revenueBreakdown: [],
        revenueTrend: []
      };
    }
  }

  /**
   * Get total number of influencers
   */
  async getTotalInfluencers() {
    try {
      const snapshot = await this.influencersCollection
        .where('status', '==', 'active')
        .get();
      return snapshot.size;
    } catch (error) {
      console.error('Error getting total influencers:', error);
      return 0;
    }
  }

  /**
   * Get top performing influencers
   */
  async getTopInfluencers(limit = 5) {
    try {
      const snapshot = await this.influencersCollection
        .where('status', '==', 'active')
        .get();

      const influencers = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        const totalLeads = data.totalLeads || 0;
        const confirmedLeads = data.confirmedLeads || 0;
        const conversionRate = totalLeads > 0 ? (confirmedLeads / totalLeads) * 100 : 0;

        influencers.push({
          id: doc.id,
          name: data.name,
          revenue: data.revenueGenerated || 0,
          confirmedLeads,
          conversionRate,
        });
      });

      // Sort by revenue descending
      influencers.sort((a, b) => b.revenue - a.revenue);

      return influencers.slice(0, limit);
    } catch (error) {
      console.error('Error getting top influencers:', error);
      return [];
    }
  }

  /**
   * Get recent registration requests
   */
  async getRecentRegistrations(limit = 5) {
    try {
      const snapshot = await this.registrationsCollection
        .orderBy('registeredAt', 'desc')
        .limit(limit)
        .get();

      const registrations = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        registrations.push({
          id: doc.id,
          userName: data.userName,
          courseName: data.courseName,
          amount: data.coursePrice || 0,
          status: data.status,
          registeredAt: data.registeredAt,
        });
      });

      return registrations;
    } catch (error) {
      console.error('Error getting recent registrations:', error);
      return [];
    }
  }
}

module.exports = new AdminRepository();
