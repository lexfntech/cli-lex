const BaseController = require('./base.controller');
const adminService = require('../services/admin.service');

class AdminController extends BaseController {
  /**
   * Get dashboard statistics
   * GET /api/admin/dashboard-stats
   */
  async getDashboardStats(req, res) {
    try {
      const stats = await adminService.getDashboardStats();
      this.handleSuccess(res, stats, 200);
    } catch (error) {
      this.handleError(error, res, 'AdminController.getDashboardStats');
    }
  }
}

module.exports = new AdminController();
