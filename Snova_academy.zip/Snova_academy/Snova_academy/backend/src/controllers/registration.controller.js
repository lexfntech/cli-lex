const BaseController = require('./base.controller');
const registrationService = require('../services/registration.service');

class RegistrationController extends BaseController {
  
  /**
   * Create a new registration
   */
  async create(req, res) {
    try {
      const registration = await registrationService.createRegistration(req.body);
      this.handleSuccess(res, registration, 201);
    } catch (error) {
      this.handleError(error, res, 'RegistrationController.create');
    }
  }

  /**
   * Get all registrations
   */
  async getAll(req, res) {
    try {
      const { status, courseId, limit } = req.query;
      const filters = {};
      
      if (status) filters.status = status;
      if (courseId) filters.courseId = courseId;
      if (limit) filters.limit = parseInt(limit);

      const registrations = await registrationService.getAllRegistrations(filters);
      this.handleSuccess(res, registrations, 200);
    } catch (error) {
      this.handleError(error, res, 'RegistrationController.getAll');
    }
  }

  /**
   * Get registration by ID
   */
  async getById(req, res) {
    try {
      const { id } = req.params;
      const registration = await registrationService.getRegistrationById(id);
      this.handleSuccess(res, registration, 200);
    } catch (error) {
      this.handleError(error, res, 'RegistrationController.getById');
    }
  }

  /**
   * Get registrations by user
   */
  async getByUser(req, res) {
    try {
      const userId = req.user.uid; // From auth middleware
      const registrations = await registrationService.getRegistrationsByUser(userId);
      this.handleSuccess(res, registrations, 200);
    } catch (error) {
      this.handleError(error, res, 'RegistrationController.getByUser');
    }
  }

  /**
   * Get registrations by influencer
   */
  async getByInfluencer(req, res) {
    try {
      const { influencerId } = req.params;
      const registrations = await registrationService.getRegistrationsByInfluencer(influencerId);
      this.handleSuccess(res, registrations, 200);
    } catch (error) {
      this.handleError(error, res, 'RegistrationController.getByInfluencer');
    }
  }

  /**
   * Approve registration
   */
  async approve(req, res) {
    try {
      const { id } = req.params;
      const adminId = req.user.uid;
      const { revenueAmount } = req.body;
      
      const registration = await registrationService.approveRegistration(id, adminId, revenueAmount);
      this.handleSuccess(res, registration, 200);
    } catch (error) {
      this.handleError(error, res, 'RegistrationController.approve');
    }
  }

  /**
   * Reject registration
   */
  async reject(req, res) {
    try {
      const { id } = req.params;
      const adminId = req.user.uid;
      const { reason } = req.body;
      
      const registration = await registrationService.rejectRegistration(id, adminId, reason);
      this.handleSuccess(res, registration, 200);
    } catch (error) {
      this.handleError(error, res, 'RegistrationController.reject');
    }
  }

  /**
   * Update progress
   */
  async updateProgress(req, res) {
    try {
      const { id } = req.params;
      const { completedModules } = req.body;
      
      const registration = await registrationService.updateProgress(id, completedModules);
      this.handleSuccess(res, registration, 200);
    } catch (error) {
      this.handleError(error, res, 'RegistrationController.updateProgress');
    }
  }

  /**
   * Get statistics
   */
  async getStats(req, res) {
    try {
      const stats = await registrationService.getStats();
      this.handleSuccess(res, stats, 200);
    } catch (error) {
      this.handleError(error, res, 'RegistrationController.getStats');
    }
  }

  /**
   * Delete registration
   */
  async delete(req, res) {
    try {
      const { id } = req.params;
      const result = await registrationService.deleteRegistration(id);
      this.handleSuccess(res, result, 200);
    } catch (error) {
      this.handleError(error, res, 'RegistrationController.delete');
    }
  }
}

module.exports = new RegistrationController();
