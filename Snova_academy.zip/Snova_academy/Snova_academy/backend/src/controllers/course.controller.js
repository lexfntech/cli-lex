const BaseController = require('./base.controller');
const courseService = require('../services/course.service');

class CourseController extends BaseController {
  /**
   * Get all courses
   */
  async getAll(req, res) {
    try {
      const courses = await courseService.getAllCourses();
      this.handleSuccess(res, courses, 200);
    } catch (error) {
      this.handleError(error, res, 'CourseController.getAll');
    }
  }

  /**
   * Get course by ID
   */
  async getById(req, res) {
    try {
      const { id } = req.params;
      const course = await courseService.getCourseById(id);
      this.handleSuccess(res, course, 200);
    } catch (error) {
      this.handleError(error, res, 'CourseController.getById');
    }
  }

  /**
   * Create a new course
   */
  async create(req, res) {
    try {
      const course = await courseService.createCourse(req.body);
      this.handleSuccess(res, course, 201);
    } catch (error) {
      this.handleError(error, res, 'CourseController.create');
    }
  }

  /**
   * Update course
   */
  async update(req, res) {
    try {
      const { id } = req.params;
      const updated = await courseService.updateCourse(id, req.body);
      this.handleSuccess(res, updated, 200);
    } catch (error) {
      this.handleError(error, res, 'CourseController.update');
    }
  }

  /**
   * Delete course
   */
  async delete(req, res) {
    try {
      const { id } = req.params;
      const result = await courseService.deleteCourse(id);
      this.handleSuccess(res, result, 200);
    } catch (error) {
      this.handleError(error, res, 'CourseController.delete');
    }
  }
}

module.exports = new CourseController();
