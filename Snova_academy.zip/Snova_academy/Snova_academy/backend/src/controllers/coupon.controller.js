const BaseController = require('./base.controller');
const couponService = require('../services/coupon.service');

class CouponController extends BaseController {
  /**
   * Get all coupons
   */
  async getAll(req, res) {
    try {
      const coupons = await couponService.getAllCoupons();
      this.handleSuccess(res, coupons, 200);
    } catch (error) {
      this.handleError(error, res, 'CouponController.getAll');
    }
  }

  /**
   * Create a new coupon
   */
  async create(req, res) {
    try {
      const coupon = await couponService.createCoupon(req.body);
      this.handleSuccess(res, coupon, 201);
    } catch (error) {
      this.handleError(error, res, 'CouponController.create');
    }
  }

  /**
   * Toggle coupon active status
   */
  async toggleStatus(req, res) {
    try {
      const { id } = req.params;
      const { is_active } = req.body;
      const updated = await couponService.toggleCouponStatus(id, is_active);
      this.handleSuccess(res, updated, 200);
    } catch (error) {
      this.handleError(error, res, 'CouponController.toggleStatus');
    }
  }

  /**
   * Delete coupon
   */
  async delete(req, res) {
    try {
      const { id } = req.params;
      const result = await couponService.deleteCoupon(id);
      this.handleSuccess(res, result, 200);
    } catch (error) {
      this.handleError(error, res, 'CouponController.delete');
    }
  }

  /**
   * Validate coupon code for checkout
   */
  async validateCode(req, res) {
    try {
      const { code } = req.params;
      const validation = await couponService.validateCoupon(code);
      this.handleSuccess(res, validation, 200);
    } catch (error) {
      this.handleError(error, res, 'CouponController.validateCode');
    }
  }
}

module.exports = new CouponController();
