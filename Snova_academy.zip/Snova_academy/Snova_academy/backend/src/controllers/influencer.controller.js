const BaseController = require('./base.controller');
const influencerService = require('../services/influencer.service');

class InfluencerController extends BaseController {
  
  /**
   * Create a new influencer
   */
  async create(req, res) {
    try {
      const influencer = await influencerService.createInfluencer(req.body);
      this.handleSuccess(res, influencer, 201);
    } catch (error) {
      this.handleError(error, res, 'InfluencerController.create');
    }
  }

  /**
   * Get all influencers
   */
  async getAll(req, res) {
    try {
      const { status, sortBy } = req.query;
      const filters = {};
      
      if (status) filters.status = status;
      if (sortBy) filters.sortBy = sortBy;

      const influencers = await influencerService.getAllInfluencers(filters);
      this.handleSuccess(res, influencers, 200);
    } catch (error) {
      this.handleError(error, res, 'InfluencerController.getAll');
    }
  }

  /**
   * Get influencer by ID
   */
  async getById(req, res) {
    try {
      const { id } = req.params;
      const influencer = await influencerService.getInfluencerById(id);
      this.handleSuccess(res, influencer, 200);
    } catch (error) {
      this.handleError(error, res, 'InfluencerController.getById');
    }
  }

  /**
   * Get influencer by referral code
   */
  async getByReferralCode(req, res) {
    try {
      const { code } = req.params;
      const influencer = await influencerService.getInfluencerByReferralCode(code);
      this.handleSuccess(res, influencer, 200);
    } catch (error) {
      this.handleError(error, res, 'InfluencerController.getByReferralCode');
    }
  }

  /**
   * Update influencer
   */
  async update(req, res) {
    try {
      const { id } = req.params;
      const influencer = await influencerService.updateInfluencer(id, req.body);
      this.handleSuccess(res, influencer, 200);
    } catch (error) {
      this.handleError(error, res, 'InfluencerController.update');
    }
  }

  /**
   * Update influencer status
   */
  async updateStatus(req, res) {
    try {
      const { id } = req.params;
      const { status } = req.body;
      const influencer = await influencerService.updateStatus(id, status);
      this.handleSuccess(res, influencer, 200);
    } catch (error) {
      this.handleError(error, res, 'InfluencerController.updateStatus');
    }
  }

  /**
   * Delete influencer
   */
  async delete(req, res) {
    try {
      const { id } = req.params;
      const result = await influencerService.deleteInfluencer(id);
      this.handleSuccess(res, result, 200);
    } catch (error) {
      this.handleError(error, res, 'InfluencerController.delete');
    }
  }

  /**
   * Get analytics
   */
  async getAnalytics(req, res) {
    try {
      const analytics = await influencerService.getAnalytics();
      this.handleSuccess(res, analytics, 200);
    } catch (error) {
      this.handleError(error, res, 'InfluencerController.getAnalytics');
    }
  }
}

module.exports = new InfluencerController();
