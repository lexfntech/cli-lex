const BaseController = require('./base.controller');
const studentService = require('../services/student.service');

class StudentController extends BaseController {

  /**
   * Student Dashboard summary
   */
  async getDashboard(req, res) {
    try {
      const userId = req.user.uid;

      const dashboard = await studentService.getDashboard(userId);
      this.handleSuccess(res, dashboard, 200);
    } catch (error) {
      this.handleError(error, res, 'StudentController.getDashboard');
    }
  }

  /**
   * Get all courses student is enrolled in
   */
  async getMyCourses(req, res) {
    try {
      const userId = req.user.uid;

      const courses = await studentService.getMyCourses(userId);
      this.handleSuccess(res, courses, 200);
    } catch (error) {
      this.handleError(error, res, 'StudentController.getMyCourses');
    }
  }

  /**
   * Get all registrations (pending / approved / rejected)
   */
  async getRegistrations(req, res) {
    try {
      const userId = req.user.uid;

      const registrations = await studentService.getRegistrations(userId);
      this.handleSuccess(res, registrations, 200);
    } catch (error) {
      this.handleError(error, res, 'StudentController.getRegistrations');
    }
  }

  /**
   * Register for a course
   */
  async registerCourse(req, res) {
    try {
      const userId = req.user.uid;
      const data = req.body;

      const result = await studentService.registerCourse(userId, data);
      this.handleSuccess(res, result, 201);
    } catch (error) {
      this.handleError(error, res, 'StudentController.registerCourse');
    }
  }

  /**
   * Cancel registration
   */
  async cancelRegistration(req, res) {
    try {
      const userId = req.user.uid;
      const { id } = req.params;

      const result = await studentService.cancelRegistration(userId, id);
      this.handleSuccess(res, result, 200);
    } catch (error) {
      this.handleError(error, res, 'StudentController.cancelRegistration');
    }
  }

  /**
   * Get student profile
   */
  async getProfile(req, res) {
    try {
      const userId = req.user.uid;

      const profile = await studentService.getProfile(userId);
      this.handleSuccess(res, profile, 200);
    } catch (error) {
      this.handleError(error, res, 'StudentController.getProfile');
    }
  }

  /**
   * Get progress tracking (future feature)
   */
  async getProgress(req, res) {
    try {
      const userId = req.user.uid;

      const progress = await studentService.getProgress(userId);
      this.handleSuccess(res, progress, 200);
    } catch (error) {
      this.handleError(error, res, 'StudentController.getProgress');
    }
  }
}

module.exports = new StudentController();