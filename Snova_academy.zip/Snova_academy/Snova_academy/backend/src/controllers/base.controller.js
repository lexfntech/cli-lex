class BaseController {
  /**
   * Standardized success response
   */
  handleSuccess(res, data, statusCode = 200) {
    return res.status(statusCode).json({
      success: true,
      data,
    });
  }

  /**
   * Standardized error response
   */
  handleError(error, res, context = 'BaseController') {
    console.error(`[${context}] Error:`, error);
    // Ideally log to Sentry here: Sentry.captureException(error);

    const statusCode = error.statusCode || 500;
    const message = error.message || 'Internal Server Error';

    return res.status(statusCode).json({
      success: false,
      error: message,
    });
  }
}

module.exports = BaseController;
