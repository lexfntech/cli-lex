const BaseController = require('./base.controller');
const authService = require('../services/auth.service');

class AuthController extends BaseController {
  
  /**
   * Handle user registration
   */
  async register(req, res) {
    try {
      const { uid, name, email, coupon } = req.body;
      
      // Basic validation (ideally done with Zod)
      if (!name || !email) {
        const error = new Error('Missing required fields: name, email');
        error.statusCode = 400;
        throw error;
      }

      // Security check: Ensure token UID matches request body UID
      if (req.user.uid !== uid) {
        const error = new Error('Unauthorized payload manipulation');
        error.statusCode = 403;
        throw error;
      }

      const user = await authService.registerUser({ uid, name, email, coupon });
      
      this.handleSuccess(res, user, 201);
    } catch (error) {
      this.handleError(error, res, 'AuthController.register');
    }
  }

  /**
   * Get current user profile
   */
  async getProfile(req, res) {
    try {
      const uid = req.user.uid;
      const user = await authService.getUserProfile(uid);
      
      this.handleSuccess(res, user, 200);
    } catch (error) {
      this.handleError(error, res, 'AuthController.getProfile');
    }
  }

  /**
   * Get all users (admin only)
   */
  async getAllUsers(req, res) {
    try {
      const users = await authService.getAllUsers();
      this.handleSuccess(res, users, 200);
    } catch (error) {
      this.handleError(error, res, 'AuthController.getAllUsers');
    }
  }
}

module.exports = new AuthController();
