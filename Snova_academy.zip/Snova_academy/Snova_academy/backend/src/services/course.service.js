const courseRepository = require('../repositories/course.repository');

class CourseService {
  /**
   * Create a new course
   */
  async createCourse(payload) {
    const { id, title, description, price, level, duration, tags, modules, features, bonusResources, isActive } = payload;

    if (!title || price === undefined) {
      const error = new Error('Course title and price are required');
      error.statusCode = 400;
      throw error;
    }

    const courseId = id || `course_${Date.now()}`;
    const existing = await courseRepository.findById(courseId);
    if (existing) {
      const error = new Error('Course ID already exists');
      error.statusCode = 409;
      throw error;
    }

    const courseData = {
      id: courseId,
      title,
      description: description || '',
      price: Number(price),
      level: level || 'Beginner',
      duration: duration || '',
      tags: Array.isArray(tags) ? tags : [],
      modules: Array.isArray(modules) ? modules : [],
      features: Array.isArray(features) ? features : [],
      bonusResources: Array.isArray(bonusResources) ? bonusResources : [],
      isActive: isActive !== undefined ? !!isActive : true
    };

    return await courseRepository.create(courseData);
  }

  /**
   * Get all courses
   */
  async getAllCourses() {
    return await courseRepository.findAll();
  }

  /**
   * Get course by ID
   */
  async getCourseById(id) {
    const course = await courseRepository.findById(id);
    if (!course) {
      const error = new Error('Course not found');
      error.statusCode = 404;
      throw error;
    }
    return course;
  }

  /**
   * Update course
   */
  async updateCourse(id, payload) {
    const course = await courseRepository.findById(id);
    if (!course) {
      const error = new Error('Course not found');
      error.statusCode = 404;
      throw error;
    }

    const updateData = {};
    if (payload.title !== undefined) updateData.title = payload.title;
    if (payload.description !== undefined) updateData.description = payload.description;
    if (payload.price !== undefined) updateData.price = Number(payload.price);
    if (payload.level !== undefined) updateData.level = payload.level;
    if (payload.duration !== undefined) updateData.duration = payload.duration;
    if (payload.tags !== undefined) updateData.tags = Array.isArray(payload.tags) ? payload.tags : [];
    if (payload.modules !== undefined) updateData.modules = Array.isArray(payload.modules) ? payload.modules : [];
    if (payload.features !== undefined) updateData.features = Array.isArray(payload.features) ? payload.features : [];
    if (payload.bonusResources !== undefined) updateData.bonusResources = Array.isArray(payload.bonusResources) ? payload.bonusResources : [];
    if (payload.isActive !== undefined) updateData.isActive = !!payload.isActive;

    return await courseRepository.update(id, updateData);
  }

  /**
   * Delete course
   */
  async deleteCourse(id) {
    const course = await courseRepository.findById(id);
    if (!course) {
      const error = new Error('Course not found');
      error.statusCode = 404;
      throw error;
    }
    return await courseRepository.delete(id);
  }
}

module.exports = new CourseService();
