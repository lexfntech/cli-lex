const adminRepository = require('../repositories/admin.repository');

class AdminService {
  /**
   * Get comprehensive dashboard statistics
   */
  async getDashboardStats() {
    try {
      const [
        totalCourses,
        registrationStats,
        totalInfluencers,
        topInfluencers,
        recentRegistrations,
      ] = await Promise.all([
        adminRepository.getTotalCourses(),
        adminRepository.getRegistrationStats(),
        adminRepository.getTotalInfluencers(),
        adminRepository.getTopInfluencers(5),
        adminRepository.getRecentRegistrations(5),
      ]);

      return {
        totalCourses,
        totalRegistrations: registrationStats.total,
        pendingRequests: registrationStats.pending,
        confirmedRegistrations: registrationStats.confirmed,
        cancelledRegistrations: registrationStats.cancelled,
        totalRevenue: registrationStats.totalRevenue,
        totalInfluencers,
        topInfluencers,
        recentRegistrations,
        revenueTrend: registrationStats.revenueTrend,
        revenueBreakdown: registrationStats.revenueBreakdown,
      };
    } catch (error) {
      console.error('Error in getDashboardStats:', error);
      throw new Error('Failed to fetch dashboard statistics');
    }
  }
}

module.exports = new AdminService();
