const studentRepository = require('../repositories/student.repository');
const courseRepository = require('../repositories/course.repository');
const registrationRepository = require('../repositories/registration.repository');

class StudentService {

  /**
   * Get student dashboard summary
   */
  async getDashboard(userId) {
    const student = await studentRepository.findById(userId);

    if (!student) {
      const error = new Error('Student not found');
      error.statusCode = 404;
      throw error;
    }

    const registrations = await registrationRepository.findByUserId(userId);

    const totalCourses = registrations.length;
    const approved = registrations.filter(r => r.status === 'approved').length;
    const pending = registrations.filter(r => r.status === 'pending').length;

    const recentRegistrations = registrations
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      .slice(0, 5);

    return {
      student: {
        id: student.id,
        name: student.name,
        email: student.email
      },
      stats: {
        totalCourses,
        approved,
        pending
      },
      recentRegistrations
    };
  }

  /**
   * Get student's enrolled courses
   */
  async getMyCourses(userId) {
    const registrations = await registrationRepository.findByUserId(userId);

    const approved = registrations.filter(r => r.status === 'approved');

    const courseIds = approved.map(r => r.courseId);

    const courses = await courseRepository.findByIds(courseIds);

    return courses;
  }

  /**
   * Get all registrations
   */
  async getRegistrations(userId) {
    return await registrationRepository.findByUserId(userId);
  }

  /**
   * Register for a course
   */
  async registerCourse(userId, data) {
    const { courseId, courseName, coursePrice, couponUsed, referralCode } = data;

    // Validate course exists
    const course = await courseRepository.findById(courseId);
    if (!course) {
      const error = new Error('Course not found');
      error.statusCode = 404;
      throw error;
    }

    // Prevent duplicate registration
    const existing = await registrationRepository.findOne({
      userId,
      courseId
    });

    if (existing) {
      const error = new Error('Already registered for this course');
      error.statusCode = 409;
      throw error;
    }

    // Create registration
    const registration = await registrationRepository.create({
      userId,
      courseId,
      courseName: courseName || course.name,
      coursePrice: coursePrice || course.price,
      couponUsed: couponUsed || null,
      referralCode: referralCode || null,
      status: 'pending',
      createdAt: new Date()
    });

    return {
      message: 'Registration successful',
      registration
    };
  }

  /**
   * Cancel registration
   */
  async cancelRegistration(userId, registrationId) {
    const registration = await registrationRepository.findById(registrationId);

    if (!registration || registration.userId !== userId) {
      const error = new Error('Registration not found');
      error.statusCode = 404;
      throw error;
    }

    await registrationRepository.delete(registrationId);

    return {
      message: 'Registration cancelled successfully'
    };
  }

  /**
   * Get student profile
   */
  async getProfile(userId) {
    const student = await studentRepository.findById(userId);

    if (!student) {
      const error = new Error('Student not found');
      error.statusCode = 404;
      throw error;
    }

    return {
      id: student.id,
      name: student.name,
      email: student.email,
      role: student.role,
      createdAt: student.createdAt
    };
  }

  /**
   * Progress tracking (future feature)
   */
  async getProgress(userId) {
    const registrations = await registrationRepository.findByUserId(userId);

    const total = registrations.length;
    const completed = registrations.filter(r => r.status === 'completed').length;

    return {
      totalCourses: total,
      completedCourses: completed,
      progressPercentage: total === 0 ? 0 : (completed / total) * 100
    };
  }
}

module.exports = new StudentService();