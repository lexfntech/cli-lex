const authRepository = require('../repositories/auth.repository');
const { auth } = require('../config/firebase');

class AuthService {
  /**
   * Register a new user or retrieve existing one
   */
  async registerUser(payload) {
    const { uid, name, email, coupon } = payload;
    
    // Check if user already exists in Firestore
    const existingUser = await authRepository.findUserById(uid);
    if (existingUser) {
      // Could potentially update user if needed, or just return them
      return existingUser;
    }

    // Check if user is admin (via custom claims)
    try {
      const userRecord = await auth.getUser(uid);
      const isAdmin = userRecord.customClaims?.admin === true;
      
      // Default parameters for new user
      const newUserData = {
        name,
        email,
        coupon: coupon || null,
        role: isAdmin ? 'admin' : 'student',
        status: 'active'
      };

      // Create user in Firestore
      const user = await authRepository.createUser(uid, newUserData);
      return user;
    } catch (error) {
      console.error('Error checking admin status:', error);
      
      // Fallback if custom claims check fails
      const newUserData = {
        name,
        email,
        coupon: coupon || null,
        role: 'student',
        status: 'active'
      };

      const user = await authRepository.createUser(uid, newUserData);
      return user;
    }
  }

  /**
   * Get user profile
   */
  async getUserProfile(uid) {
    const user = await authRepository.findUserById(uid);
    if (!user) {
      const error = new Error('User not found');
      error.statusCode = 404;
      throw error;
    }
    return user;
  }

  /**
   * Get all users (admin only)
   */
  async getAllUsers() {
    return await authRepository.getAllUsers();
  }
}

module.exports = new AuthService();
