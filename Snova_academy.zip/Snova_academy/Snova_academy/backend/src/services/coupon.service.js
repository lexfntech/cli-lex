const couponRepository = require('../repositories/coupon.repository');

class CouponService {
  /**
   * Create a new coupon
   */
  async createCoupon(payload) {
    const { code, discount_type, value, max_usage } = payload;

    if (!code || !discount_type || value === undefined) {
      const error = new Error('Missing required coupon fields');
      error.statusCode = 400;
      throw error;
    }

    const existing = await couponRepository.findByCode(code);
    if (existing) {
      const error = new Error('Coupon code already exists');
      error.statusCode = 409;
      throw error;
    }

    const couponData = {
      code: code.toUpperCase(),
      discount_type, // 'percentage' | 'flat'
      value: Number(value),
      max_usage: max_usage ? Number(max_usage) : 999,
      current_usage: 0,
      is_active: true
    };

    return await couponRepository.create(couponData);
  }

  /**
   * Get all coupons
   */
  async getAllCoupons() {
    return await couponRepository.findAll();
  }

  /**
   * Toggle active status of a coupon
   */
  async toggleCouponStatus(code, isActive) {
    const coupon = await couponRepository.findByCode(code);
    if (!coupon) {
      const error = new Error('Coupon not found');
      error.statusCode = 404;
      throw error;
    }

    return await couponRepository.update(code, { is_active: isActive });
  }

  /**
   * Delete coupon
   */
  async deleteCoupon(code) {
    const coupon = await couponRepository.findByCode(code);
    if (!coupon) {
      const error = new Error('Coupon not found');
      error.statusCode = 404;
      throw error;
    }

    return await couponRepository.delete(code);
  }

  /**
   * Validate coupon code
   */
  async validateCoupon(code) {
    if (!code) {
      const error = new Error('Coupon code is required');
      error.statusCode = 400;
      throw error;
    }

    const coupon = await couponRepository.findByCode(code.toUpperCase());
    if (!coupon) {
      const error = new Error('Invalid coupon code');
      error.statusCode = 404;
      throw error;
    }

    if (!coupon.is_active) {
      const error = new Error('Coupon is inactive');
      error.statusCode = 400;
      throw error;
    }

    if (coupon.current_usage >= coupon.max_usage) {
      const error = new Error('Coupon usage limit reached');
      error.statusCode = 400;
      throw error;
    }

    return {
      valid: true,
      code: coupon.code,
      discount_type: coupon.discount_type,
      value: coupon.value
    };
  }

  /**
   * Increment coupon usage count
   */
  async incrementUsage(code) {
    const coupon = await couponRepository.findByCode(code);
    if (coupon) {
      await couponRepository.update(code, {
        current_usage: (coupon.current_usage || 0) + 1
      });
    }
  }
}

module.exports = new CouponService();
