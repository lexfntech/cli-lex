const registrationRepository = require('../repositories/registration.repository');
const influencerService = require('./influencer.service');

class RegistrationService {
  
  /**
   * Create a new course registration
   */
  async createRegistration(payload) {
    const { 
      userId, 
      userName,
      userEmail,
      userPhone,
      courseId, 
      courseName,
      coursePrice,
      couponUsed = null,
      referralCode = null 
    } = payload;

    // Validate required fields
    if (!userId || !courseId || !userName || !userEmail) {
      const error = new Error('Missing required fields');
      error.statusCode = 400;
      throw error;
    }

    // Check if user already registered for this course
    const alreadyRegistered = await registrationRepository.isUserRegistered(userId, courseId);
    if (alreadyRegistered) {
      const error = new Error('Already registered for this course');
      error.statusCode = 409;
      throw error;
    }

    // Prepare registration data
    const registrationData = {
      userId,
      userName,
      userEmail,
      userPhone: userPhone || null,
      courseId,
      courseName,
      coursePrice: coursePrice || 0,
      couponUsed,
      status: 'pending',
      progress: {
        completedModules: []
      },
      referralSource: null,
      influencerId: null,
      referralCode: null
    };

    // Handle referral if provided
    if (referralCode) {
      try {
        const influencer = await influencerService.getInfluencerByReferralCode(referralCode);
        if (influencer && influencer.status === 'active') {
          registrationData.influencerId = influencer.id;
          registrationData.referralCode = referralCode;
          registrationData.referralSource = 'influencer';

          // Increment influencer's total leads
          await influencerService.incrementLeads(influencer.id, false);
        }
      } catch (error) {
        console.error('Invalid referral code, continuing without referral:', error);
      }
    }

    // Create registration
    const registration = await registrationRepository.create(registrationData);
    return registration;
  }

  /**
   * Get all registrations with filters
   */
  async getAllRegistrations(filters = {}) {
    return await registrationRepository.findAll(filters);
  }

  /**
   * Get registration by ID
   */
  async getRegistrationById(id) {
    const registration = await registrationRepository.findById(id);
    if (!registration) {
      const error = new Error('Registration not found');
      error.statusCode = 404;
      throw error;
    }
    return registration;
  }

  /**
   * Get registrations by user
   */
  async getRegistrationsByUser(userId) {
    return await registrationRepository.findByUserId(userId);
  }

  /**
   * Get registrations by influencer
   */
  async getRegistrationsByInfluencer(influencerId) {
    return await registrationRepository.findByInfluencerId(influencerId);
  }

  /**
   * Approve registration
   */
  async approveRegistration(id, adminId, revenueAmount = 0) {
    const registration = await registrationRepository.findById(id);
    if (!registration) {
      const error = new Error('Registration not found');
      error.statusCode = 404;
      throw error;
    }

    if (registration.status !== 'pending') {
      const error = new Error('Only pending registrations can be approved');
      error.statusCode = 400;
      throw error;
    }

    // Approve the registration
    const approved = await registrationRepository.approve(id, adminId);

    // If registration has an influencer, update their stats
    if (registration.influencerId) {
      try {
        // Increment confirmed leads
        await influencerService.incrementLeads(registration.influencerId, true);
        
        // Update revenue if amount provided
        if (revenueAmount > 0) {
          await influencerService.updateRevenue(registration.influencerId, revenueAmount);
        }
      } catch (error) {
        console.error('Failed to update influencer stats:', error);
      }
    }

    return approved;
  }

  /**
   * Reject registration
   */
  async rejectRegistration(id, adminId, reason = null) {
    const registration = await registrationRepository.findById(id);
    if (!registration) {
      const error = new Error('Registration not found');
      error.statusCode = 404;
      throw error;
    }

    if (registration.status !== 'pending') {
      const error = new Error('Only pending registrations can be rejected');
      error.statusCode = 400;
      throw error;
    }

    return await registrationRepository.reject(id, adminId, reason);
  }

  /**
   * Update registration progress
   */
  async updateProgress(id, completedModules) {
    const registration = await registrationRepository.findById(id);
    if (!registration) {
      const error = new Error('Registration not found');
      error.statusCode = 404;
      throw error;
    }

    if (registration.status !== 'approved') {
      const error = new Error('Only approved registrations can have progress updated');
      error.statusCode = 400;
      throw error;
    }

    return await registrationRepository.updateProgress(id, completedModules);
  }

  /**
   * Get registration statistics
   */
  async getStats() {
    return await registrationRepository.getStats();
  }

  /**
   * Delete registration
   */
  async deleteRegistration(id) {
    const registration = await registrationRepository.findById(id);
    if (!registration) {
      const error = new Error('Registration not found');
      error.statusCode = 404;
      throw error;
    }

    await registrationRepository.delete(id);
    return { success: true, message: 'Registration deleted successfully' };
  }
}

module.exports = new RegistrationService();
