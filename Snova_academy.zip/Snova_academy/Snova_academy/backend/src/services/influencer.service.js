const influencerRepository = require('../repositories/influencer.repository');
const { auth } = require('../config/firebase');

class InfluencerService {
  
  /**
   * Generate unique referral code
   */
  generateReferralCode(name) {
    // Extract first part of name and add random number
    const namePart = name.split(' ')[0].toUpperCase().substring(0, 6);
    const randomPart = Math.floor(Math.random() * 99) + 1;
    return `${namePart}${randomPart.toString().padStart(2, '0')}`;
  }

  /**
   * Generate referral link
   */
  generateReferralLink(referralCode) {
    const baseUrl = process.env.FRONTEND_URL || 'http://localhost:5173';
    return `${baseUrl}?ref=${referralCode}`;
  }

  /**
   * Ensure referral code is unique
   */
  async ensureUniqueReferralCode(baseName) {
    let referralCode = this.generateReferralCode(baseName);
    let attempts = 0;
    const maxAttempts = 10;

    while (attempts < maxAttempts) {
      const existing = await influencerRepository.findByReferralCode(referralCode);
      if (!existing) {
        return referralCode;
      }
      // Try again with different random number
      referralCode = this.generateReferralCode(baseName);
      attempts++;
    }

    // Fallback: append timestamp
    const timestamp = Date.now().toString().slice(-4);
    return `${baseName.substring(0, 4).toUpperCase()}${timestamp}`;
  }

  /**
   * Create a new influencer
   */
  async createInfluencer(payload) {
    const { name, email, phone, username, password, status = 'active' } = payload;

    // Validate required fields
    if (!name || !email || !phone || !username || !password) {
      const error = new Error('Missing required fields');
      error.statusCode = 400;
      throw error;
    }

    // Check if email already exists
    const existingEmail = await influencerRepository.findByEmail(email);
    if (existingEmail) {
      const error = new Error('Email already registered');
      error.statusCode = 409;
      throw error;
    }

    // Check if username already exists
    const existingUsername = await influencerRepository.findByUsername(username);
    if (existingUsername) {
      const error = new Error('Username already taken');
      error.statusCode = 409;
      throw error;
    }

    // Generate unique referral code and link
    const referralCode = await this.ensureUniqueReferralCode(name);
    const referralLink = this.generateReferralLink(referralCode);

    // Create Firebase Auth user for the influencer
    let firebaseUid;
    try {
      const userRecord = await auth.createUser({
        email,
        password,
        displayName: name
      });
      firebaseUid = userRecord.uid;

      // Set custom claims for influencer role
      await auth.setCustomUserClaims(firebaseUid, { influencer: true });
    } catch (error) {
      const err = new Error(`Failed to create Firebase user: ${error.message}`);
      err.statusCode = 500;
      throw err;
    }

    // Create influencer document
    const influencerData = {
      firebaseUid,
      name,
      email,
      phone,
      username,
      role: 'influencer',
      referralCode,
      referralLink,
      status,
      totalLeads: 0,
      confirmedLeads: 0,
      revenueGenerated: 0
    };

    const influencer = await influencerRepository.create(influencerData);
    
    // Don't return password or sensitive data
    return influencer;
  }

  /**
   * Get all influencers
   */
  async getAllInfluencers(filters = {}) {
    return await influencerRepository.findAll(filters);
  }

  /**
   * Get influencer by ID
   */
  async getInfluencerById(id) {
    const influencer = await influencerRepository.findById(id);
    if (!influencer) {
      const error = new Error('Influencer not found');
      error.statusCode = 404;
      throw error;
    }
    return influencer;
  }

  /**
   * Get influencer by referral code
   */
  async getInfluencerByReferralCode(referralCode) {
    const influencer = await influencerRepository.findByReferralCode(referralCode);
    if (!influencer) {
      const error = new Error('Invalid referral code');
      error.statusCode = 404;
      throw error;
    }
    return influencer;
  }

  /**
   * Update influencer
   */
  async updateInfluencer(id, updateData) {
    const influencer = await influencerRepository.findById(id);
    if (!influencer) {
      const error = new Error('Influencer not found');
      error.statusCode = 404;
      throw error;
    }

    // Check email uniqueness if being updated
    if (updateData.email && updateData.email !== influencer.email) {
      const existingEmail = await influencerRepository.findByEmail(updateData.email);
      if (existingEmail) {
        const error = new Error('Email already in use');
        error.statusCode = 409;
        throw error;
      }

      // Update Firebase Auth email
      try {
        await auth.updateUser(influencer.firebaseUid, { email: updateData.email });
      } catch (error) {
        console.error('Failed to update Firebase email:', error);
      }
    }

    // Update Firebase Auth display name if name changed
    if (updateData.name && updateData.name !== influencer.name) {
      try {
        await auth.updateUser(influencer.firebaseUid, { displayName: updateData.name });
      } catch (error) {
        console.error('Failed to update Firebase display name:', error);
      }
    }

    return await influencerRepository.update(id, updateData);
  }

  /**
   * Update influencer status
   */
  async updateStatus(id, status) {
    if (!['active', 'inactive'].includes(status)) {
      const error = new Error('Invalid status. Must be active or inactive');
      error.statusCode = 400;
      throw error;
    }

    return await influencerRepository.update(id, { status });
  }

  /**
   * Delete influencer (soft delete)
   */
  async deleteInfluencer(id) {
    const influencer = await influencerRepository.findById(id);
    if (!influencer) {
      const error = new Error('Influencer not found');
      error.statusCode = 404;
      throw error;
    }

    // Soft delete in Firestore
    await influencerRepository.softDelete(id);

    // Disable Firebase Auth user
    try {
      await auth.updateUser(influencer.firebaseUid, { disabled: true });
    } catch (error) {
      console.error('Failed to disable Firebase user:', error);
    }

    return { success: true, message: 'Influencer deleted successfully' };
  }

  /**
   * Increment influencer leads
   */
  async incrementLeads(influencerId, confirmed = false) {
    return await influencerRepository.incrementLeads(influencerId, confirmed);
  }

  /**
   * Update revenue
   */
  async updateRevenue(influencerId, amount) {
    const influencer = await influencerRepository.findById(influencerId);
    if (!influencer) {
      const error = new Error('Influencer not found');
      error.statusCode = 404;
      throw error;
    }

    const newRevenue = (influencer.revenueGenerated || 0) + amount;
    return await influencerRepository.updateStats(influencerId, {
      revenueGenerated: newRevenue
    });
  }

  /**
   * Get analytics
   */
  async getAnalytics() {
    return await influencerRepository.getAnalytics();
  }
}

module.exports = new InfluencerService();
