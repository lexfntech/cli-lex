require('dotenv').config();
const express = require('express');
const cors = require('cors');

// Import routes
const authRoutes = require('./src/routes/auth.routes');
const influencerRoutes = require('./src/routes/influencer.routes');
const registrationRoutes = require('./src/routes/registration.routes');
const adminRoutes = require('./src/routes/admin.routes');
const couponRoutes = require('./src/routes/coupon.routes');
const courseRoutes = require('./src/routes/course.routes');

const app = express();

// Set up CORS using frontend URL from .env
const corsOptions = {
  origin: process.env.FRONTEND_URL || '*',
  optionsSuccessStatus: 200
};
app.use(cors(corsOptions));
app.use(express.json());

// Register API routes
app.use('/api/auth', authRoutes);
app.use('/api/influencers', influencerRoutes);
app.use('/api/registrations', registrationRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/coupons', couponRoutes);
app.use('/api/courses', courseRoutes);


// Health check endpoint
app.get('/api/health', (req, res) => {
  res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Snova Backend Server running on port ${PORT}`);
  console.log(`Allowing CORS from: ${corsOptions.origin}`);
});
