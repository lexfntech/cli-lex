/**
 * Firestore Setup Script
 * 
 * This script helps you:
 * 1. Verify Firestore connection
 * 2. Create sample influencer data (optional)
 * 3. Test the schema
 * 
 * Run: node setupFirestore.js
 */

require('dotenv').config();
const { db, auth } = require('./src/config/firebase');

const SAMPLE_INFLUENCERS = [
  {
    name: 'John Smith',
    email: 'john.influencer@example.com',
    phone: '+1234567890',
    username: 'johnsmith',
    referralCode: 'JOHN01',
    referralLink: `${process.env.FRONTEND_URL || 'http://localhost:5173'}?ref=JOHN01`,
    role: 'influencer',
    status: 'active',
    totalLeads: 0,
    confirmedLeads: 0,
    revenueGenerated: 0,
  },
  {
    name: 'Sarah Johnson',
    email: 'sarah.influencer@example.com',
    phone: '+1234567891',
    username: 'sarahjohnson',
    referralCode: 'SARAH01',
    referralLink: `${process.env.FRONTEND_URL || 'http://localhost:5173'}?ref=SARAH01`,
    role: 'influencer',
    status: 'active',
    totalLeads: 0,
    confirmedLeads: 0,
    revenueGenerated: 0,
  },
];

async function testConnection() {
  console.log('\n🔍 Testing Firestore connection...\n');
  
  try {
    // Try to read from Firestore
    const testDoc = await db.collection('_test').doc('connection').get();
    console.log('✅ Firestore connection successful!\n');
    return true;
  } catch (error) {
    console.error('❌ Firestore connection failed:', error.message);
    return false;
  }
}

async function createSampleInfluencers() {
  console.log('📝 Creating sample influencers...\n');
  
  const influencersRef = db.collection('influencers');
  
  for (const influencer of SAMPLE_INFLUENCERS) {
    try {
      // Check if already exists
      const existing = await influencersRef
        .where('email', '==', influencer.email)
        .limit(1)
        .get();
      
      if (!existing.empty) {
        console.log(`⚠️  Influencer ${influencer.name} already exists, skipping...`);
        continue;
      }
      
      // Create influencer document
      const docRef = await influencersRef.add({
        ...influencer,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      
      console.log(`✅ Created influencer: ${influencer.name} (ID: ${docRef.id})`);
      console.log(`   Referral Code: ${influencer.referralCode}`);
      console.log(`   Referral Link: ${influencer.referralLink}\n`);
      
    } catch (error) {
      console.error(`❌ Failed to create ${influencer.name}:`, error.message);
    }
  }
}

async function displayCollectionStats() {
  console.log('\n📊 Collection Statistics:\n');
  
  try {
    const collections = ['users', 'courses', 'registrations', 'influencers'];
    
    for (const collectionName of collections) {
      const snapshot = await db.collection(collectionName).limit(1000).get();
      console.log(`${collectionName.padEnd(20)}: ${snapshot.size} documents`);
    }
    
    console.log('\n');
  } catch (error) {
    console.error('Error fetching stats:', error.message);
  }
}

async function displayInstructions() {
  console.log('\n' + '='.repeat(70));
  console.log('📚 NEXT STEPS');
  console.log('='.repeat(70));
  console.log('\n1. Deploy Firestore Rules:');
  console.log('   firebase deploy --only firestore:rules\n');
  console.log('2. Deploy Firestore Indexes:');
  console.log('   firebase deploy --only firestore:indexes\n');
  console.log('3. Test the API endpoints:');
  console.log('   - Start backend: cd backend && node server.js');
  console.log('   - Start frontend: cd Snova_academy && npm run dev\n');
  console.log('4. Access Admin Dashboard:');
  console.log('   http://localhost:5173/management-dashboard-x92f-snova\n');
  console.log('5. Test Referral Links:');
  console.log(`   ${process.env.FRONTEND_URL || 'http://localhost:5173'}?ref=JOHN01`);
  console.log(`   ${process.env.FRONTEND_URL || 'http://localhost:5173'}?ref=SARAH01\n`);
  console.log('='.repeat(70) + '\n');
}

async function main() {
  console.log('\n' + '='.repeat(70));
  console.log('🚀 SNOVA ACADEMY - FIRESTORE SETUP');
  console.log('='.repeat(70));
  
  // Test connection
  const connected = await testConnection();
  if (!connected) {
    console.log('\n⚠️  Please check your Firebase configuration in backend/.env\n');
    return;
  }
  
  // Display current stats
  await displayCollectionStats();
  
  // Ask if user wants to create sample data
  console.log('Do you want to create sample influencer data? (y/n)');
  console.log('Type "y" and press Enter, or just press Enter to skip:\n');
  
  const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  readline.question('> ', async (answer) => {
    if (answer.toLowerCase() === 'y' || answer.toLowerCase() === 'yes') {
      await createSampleInfluencers();
      await displayCollectionStats();
    }
    
    await displayInstructions();
    readline.close();
    process.exit(0);
  });
}

// Run the setup
main().catch(error => {
  console.error('\n❌ Setup failed:', error);
  process.exit(1);
});
